export class Usuario{

    constructor(
        public user_name: String,
        public email: string,
        public ci: number,
        public password: string,
        public pais: String,
        public tel_cel: String,
        public google?: boolean,
        public id?: number

    ){}
}