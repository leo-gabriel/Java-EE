import {EArea} from '../enum/EArea';
import {EVeracidad} from '../enum/EVeracidad';
import {EEstado} from '../enum/EEstado'; 

export class Hecho{

	id : Number;	
    link : String;
	fecha : Date;
	medio : String;    	
	veracidad :EVeracidad;
	estado : EEstado;
	area : EArea;
	emailusuario: String;
	usuario: String;
	frase: String;
	autor:String;
	imagen : String;
	titulo : String;
}