import { Component, OnInit } from '@angular/core';
import { element } from '@angular/core/src/render3/instructions';
import { UsuarioService } from '../services/usuario/usuario.service';
import { AuthService } from '../services/auth.service';
import { Route, Router } from '@angular/router';
import { TokenDecoded } from '../clases/token';

import * as jwt_decode from 'jwt-decode';

declare function init_plugins();
declare const gapi: any;


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  auth2: any;
  mensaje: string;
  resultado: boolean;

  constructor(
    public _usuarioService: UsuarioService,private auth:AuthService, private router:Router
  ) { }
  ngOnInit() {
    this.googleInit();
  }

  googleInit(){
    gapi.load('auth2', ()=>{

      this.auth2 = gapi.auth2.init({
        client_id: '730445304978-3qvroous7kln6sjreil1flpe1jcj427i.apps.googleusercontent.com',
        cookiepolicy: 'single_host_origin',
        scope: 'profile email'

      });

      this.attachSignin( document.getElementById('btnGoogle') );


    });
  }


  attachSignin( element ){

    this.auth2.attachClickHandler(element, {}, googleUser => {
      let profile = googleUser.getBasicProfile();
      let token = googleUser.getAuthResponse().id_token;

      console.log(profile);
      console.log(token);

      this._usuarioService.loginGoogle( token )
        .subscribe( resp => {
            let response = resp.JWT;
        let token: TokenDecoded = jwt_decode(response);
        if (token != null) {
          this.auth.setToken(response);
          this.router.navigate(["dashboard"]);
          
        } else {
          this.resultado = false;
          this.mensaje = 'no tienes permisos para ingresar aquí con tu usuario.';
          console.log("entre else");
        }
      },
      (err) => {
        this.resultado = false;
        if (err.status == 401)
          this.mensaje = 'usuario, email o contraseña incorrectos.';
        else
          this.mensaje = 'lo sentimos, parece que hubo un problema de nuestro lado.' +
            'Vuelve a intentarlo luego.';
      }


        );
      
    })
  }
}
