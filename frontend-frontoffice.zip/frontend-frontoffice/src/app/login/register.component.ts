import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { from } from 'rxjs';
import * as swal from 'sweetalert';
import { UsuarioService } from '../services/usuario/usuario.service';
import { Usuario } from '../clases/usuario.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./login.component.css']
})
export class RegisterComponent implements OnInit {

  forma: FormGroup;

  constructor(
    public _usuarioService: UsuarioService
  ) { }

  ngOnInit() {
    this.forma = new FormGroup({
      user_name: new FormControl(null, Validators.required),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, Validators.required),
      tipo: new FormControl(null, Validators.required),
      ci: new FormControl(null, Validators.required),
    });

  }
  registrarUsuario(){
    console.log(this.forma.value);

    let usuario = new Usuario( this.forma.value.user_name, this.forma.value.email, this.forma.value.ci,
      this.forma.value.password,
      this.forma.value.tipo,
      this.forma.value.ci,
      this.forma.value.pais,
      this.forma.value.tel_cel
      );

    this._usuarioService.crearUsuario( usuario )
      .subscribe( resp => {
        console.log( resp );
        
      });

  }
}
