export enum EEstado {

    NUEVO = 1,
    A_COMPROBAR,
    EN_PROCESO,
    VERIFICADO,
    PUBLICADO,
    CANCELADO
	
}