import { Component, OnInit } from '@angular/core';
import { HechosService } from '../../services/hechos.service';
import { Hecho } from '../../clases/Hecho';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styles: []
})
export class DashboardComponent implements OnInit {
  listhechos: Hecho;

  constructor(private hechos:HechosService, private route:Router, private auth:AuthService) { }

  ngOnInit() {
    if(this.auth.getToken() == null){
      this.route.navigate(["login"]);
      }
    
    this.hechos.getHechos().subscribe((data:Hecho) => this.listhechos = data);
  }

}
