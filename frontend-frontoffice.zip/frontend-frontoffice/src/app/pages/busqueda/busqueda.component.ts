import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Hecho } from '../../clases/Hecho';



@Component({
  selector: 'app-busqueda',
  templateUrl: './busqueda.component.html',
  styles: []
})
export class BusquedaComponent implements OnInit {


  listhechos: Hecho;
  
  constructor(
    public activatedRoute: ActivatedRoute,
    public http: HttpClient
  ) { 
    activatedRoute.params
      .subscribe( params => {
        let termino = params ['termino'];
        this.buscar( termino );
        
      })


    }

  ngOnInit() {
  }

  buscar ( termino: string){
    let url = "http://localhost:8080/laboratorio-web/rest/wsMobile/filtro/" + termino;
    this.http.get(url)
      .subscribe((resp: any ) => {
        console.log (resp);
        this.listhechos = resp
      });

  }


}
