import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Usuario } from '../../clases/usuario.model';
import { URL_SERVICIOS } from '../../config/config';
import { Token } from '@angular/compiler';
import { map } from 'rxjs/operators';
 
@Injectable()
export class UsuarioService {

  usuario : Usuario;
  token : string;

  constructor(
    public http: HttpClient
  ) { 
    console.log("servicio del usuario ok");
  }

  guardarStorage(id: string, token: string, usuario: Usuario){

    localStorage.setItem('id', id);
    localStorage.setItem('token', token);
    localStorage.setItem('usuario', JSON.stringify(usuario));

    this.usuario = usuario;
    this.token = token;
  }

  loginGoogle( token: string ){
    let url = URL_SERVICIOS + 'laboratorio-web/rest/wsUsuario/LoginGoogle/';

    return this.http.post(url, { token } ) 
      .pipe(
        map((resp: any) => {
          return resp;
        })
      );
  }

  crearUsuario( usuario: Usuario ) {
    let url = URL_SERVICIOS + 'laboratorio-web/rest/wsUsuario/registro';
    
    return this.http.post( url , usuario);

  }

  donacionPayPal (orderID : string ){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
  
      })
    }
    let url = URL_SERVICIOS + 'laboratorio-web/rest/wsUsuario/DonacionPayPal';
    
    return this.http.post( url , orderID, httpOptions );



  }

}
