import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HechosService {

  private dominio = "http://" + environment.dominio_api;
  
  private messageSource = new BehaviorSubject<number>(null);
  currentMessage = this.messageSource.asObservable();
  
  constructor(private http:HttpClient) { }

  changeMessage(message:number){
    this.messageSource.next(message);
}

public getHechos() {
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'

    })
  }
  const estado:String = 'PUBLICADO';
  const url = this.dominio + '/laboratorio-web/rest/wsHecho/listadoDeHechos';
  return this.http.post(url,{estado}, httpOptions);
}
}
