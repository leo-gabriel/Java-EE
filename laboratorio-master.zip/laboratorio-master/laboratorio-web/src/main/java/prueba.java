
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.laboratorio.extra.EnviarMail;
import com.laboratorio.sb.SBHechoLocalBO;
import com.periferico.soapexterno.DtHecho;
import com.periferico.soapexterno.Soap;
import com.periferico.soapexterno.SoapService;

/**
 * Servlet implementation class altausuario
 */
@WebServlet("/prueba")
public class prueba extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	private SBHechoLocalBO sBhecho;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter asd = response.getWriter();
		/*SoapService soapService;
		soapService = new SoapService(new URL("http://draps-draps.apps.us-west-2.online-starter.openshift.com/PerifericoExterno-web/Soap?wsdl"));
		Soap soap = soapService.getSoapPort();
		DtHecho aux = new DtHecho();
		aux.setId(2);
		aux.setTitulo("funciona");
		soap.agregarHecho(aux);
		*/
		// int numero_pagina=Integer.parseInt(request.getParameter("num"));
		// String str1=request.getParameter("str1");
		// String str2=request.getParameter("str2");

		try {
			//System.out.println("hola primero vengo por prueba");

			/*FechaToDate date = new FechaToDate();

			DTHecho hecho = new DTHecho("titulo", 26, "linktitulo", date.fechaSistema(), "mediotitulo", EEstado.NUEVO,
					EArea.ECONOMIA, EVeracidad.VERACIDAD, "monicatecnicopc@gmail.com", "titulofrae", "tituloautor",
					null);
			if (sBhecho.crearHechoVerificar(hecho)) {
				System.out.println(1);
				if (sBhecho.seleccionarHechoVerificar(hecho)) {
					System.out.println(2);
					if (sBhecho.asignarHechoVerificar(hecho,
							new DTUsuario(null, "brunosasso2@gmail.com", null, null))) {
						System.out.println(3);
						if (sBhecho.tomarHechoVerificar(hecho)) {
							System.out.println(4);
							if (sBhecho.verificarHecho(hecho, EVeracidad.VERDADERA, "todo verdad")) {
								System.out.println(5);
								if (sBhecho.publicarHecho(hecho,
										new DTUsuario(null, "leogaboperez@gmail.com", null, null))) {
									System.out.println(6);
									System.out.println("hecho publicado");
								} else {
									System.out.println("no se pudo publicar el hecho");
								}

							} else {
								System.out.println("no pudimos verificar hecho");
							}
						} else {
							System.out.println("no pudimos tomar hecho");
						}
					} else {
						System.out.println("no pudimos asignar hecho");
					}
				} else {
					System.out.println("no pudimos seleccionar el hecho");
				}
			} else {
				System.out.println("No pudimos crear el hecho");
			}
*/
			
			
			
			asd.println("<!DOCTYPE html>");
			asd.println("<html>");
			asd.println("<head>");
			asd.println(
					"<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">");
			asd.println("<title>Correcto</title>");
			asd.println("</head>");
			asd.println("<body>");
			asd.println("<div class=\"mx-auto col-6\">");

			asd.println("<br><h4 class=\"text-center\">Pronto</h4><br>");
			asd.println("<div class=\"alert alert-success\" role=\"alert\">\r\n"
					+ "  Todo bien, todo correcto y YO QUE ME ALEGRO\r\n" + "</div>");
			asd.println("</div>");

			asd.print("<ul class=\"list-group\">\r\n");

			// asd.print(" <li class=\"list-group-item\">"+SBhecho.Validacion_Token(str1)
			// +"</li>\r\n" );

			asd.print("</ul>");

			asd.println(
					"<script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\" integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\" crossorigin=\"anonymous\"></script>\r\n"
							+ "            <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js\" integrity=\"sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1\" crossorigin=\"anonymous\"></script>\r\n"
							+ "            <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\" integrity=\"sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM\" crossorigin=\"anonymous\"></script>");

			asd.println("</body>");
			asd.println("</html>");

		} catch (Exception e) {

			asd.println("<!DOCTYPE html>");
			asd.println("<html>");
			asd.println("<head>");
			asd.println(
					"<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">");
			asd.println("<title>Error</title>");
			asd.println("</head>");
			asd.println("<body>");
			asd.println("<h1>Ocurrio un error</h1>");
			asd.println(
					"<div class=\"alert alert-danger\" role=\"alert\">\r\n" + "" + e.getMessage() + "\r\n" + "</div>");

			asd.println(
					"<script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\" integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\" crossorigin=\"anonymous\"></script>\r\n"
							+ "            <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js\" integrity=\"sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1\" crossorigin=\"anonymous\"></script>\r\n"
							+ "            <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\" integrity=\"sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM\" crossorigin=\"anonymous\"></script>");

			asd.println("</body>");
			asd.println("</html>");

		}
	}

}
