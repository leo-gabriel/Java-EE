
package com.periferico.soapexterno;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eArea.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="eArea">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="POLITICA"/>
 *     &lt;enumeration value="SALUD"/>
 *     &lt;enumeration value="ECONOMIA"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "eArea")
@XmlEnum
public enum EArea {

    POLITICA,
    SALUD,
    ECONOMIA;

    public String value() {
        return name();
    }

    public static EArea fromValue(String v) {
        return valueOf(v);
    }

}
