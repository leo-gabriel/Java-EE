@javax.xml.bind.annotation.XmlSchema(namespace = "http://WebServices.Periferico.com/")
package com.periferico.soapexterno;
