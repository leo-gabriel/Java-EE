
package com.periferico.soapexterno;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for eEstado.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="eEstado">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NUEVO"/>
 *     &lt;enumeration value="A_COMPROBAR"/>
 *     &lt;enumeration value="EN_PROCESO"/>
 *     &lt;enumeration value="VERIFICADO"/>
 *     &lt;enumeration value="PUBLICADO"/>
 *     &lt;enumeration value="CANCELADO"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "eEstado")
@XmlEnum
public enum EEstado {

    NUEVO,
    A_COMPROBAR,
    EN_PROCESO,
    VERIFICADO,
    PUBLICADO,
    CANCELADO;

    public String value() {
        return name();
    }

    public static EEstado fromValue(String v) {
        return valueOf(v);
    }

}
