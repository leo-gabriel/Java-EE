package com.laboratorio.rest;

import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.laboratorio.datatype.DTCitizen;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTVerificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.Constantes;
import com.laboratorio.extra.FechaToDate;
import com.laboratorio.json.JsonHecho;
import com.laboratorio.json.Json_Token;
import com.laboratorio.sb.SBHechoFOLocal;
import com.laboratorio.sb.SBHechoLocalBO;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Path("/wsMobile")
public class ServiceMobile {

	@EJB
	private SBHechoFOLocal sbfront;
	@EJB
	private SBHechoLocalBO sbback;

	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/addHecho")
	public Response crearHecho(JsonHecho jhecho, @HeaderParam("JWT") String token) {
		Response retorno = Response.status(Response.Status.UNAUTHORIZED).build();
		if (sbback.validacionToken(token)) {
			FechaToDate fecha = new FechaToDate();
			DTHecho dthecho = new DTHecho(jhecho.getTitulo(), jhecho.getId(), jhecho.getLink(),
					fecha.fechaSistema(), jhecho.getMedio(), EEstado.valueOf(jhecho.getEstado()),
					EArea.valueOf(jhecho.getArea()), EVeracidad.valueOf(jhecho.getVeracidad()),
					jhecho.getEmailusuario(), jhecho.getFrase(), jhecho.getAutor(), jhecho.getImagen());

			if (sbback.crearHechoVerificar(dthecho))
				retorno = Response.status(Response.Status.CREATED).build();
		}

		return retorno;
	}

	@GET
	@Produces(value = { MediaType.APPLICATION_JSON })
	@Path("/filtro/{nombre}")
	public List<DTHecho> filtrado(@PathParam("nombre") String nombre) {
		return sbfront.busquedaHechos(nombre);
	}

	@GET
	@Produces(value = { MediaType.APPLICATION_JSON })
	@Path("/Hechos/{num_pag}")
	public List<DTHecho> getHechos(@PathParam("num_pag") int num_pag) {
		return sbfront.listadoHechos(num_pag);
	}
	
	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/LoginGoogle")
	public Response loginGoogle(Json_Token jcitizen) {
		Response retorno=Response.status(Response.Status.UNAUTHORIZED).build(); 
		DTCitizen citizen;
		try {
			citizen = sbfront.validacionTokenGoogleMobile(jcitizen.getToken());
			// instanceo la clase para poder traer la constante password
			Constantes constante = new Constantes();
			// instanceo la clase jwts con la que voy a generar el token firmado con el
			// algoritmos hash(hs256) y una clave
			String jwt = Jwts.builder().setSubject(citizen.getEmail())// se puede sacar dato
					.signWith(SignatureAlgorithm.HS256, constante.getClavetoken())// utilizo algoritmo y clave
					.setExpiration(new Date(System.currentTimeMillis() + 900000))// calcula 15 minutos y expira el token
																					// de la sesion
					.compact(); // compactamos todo

			// generarmos un json y luego le asignamos nuestro token
			JsonObject json = Json.createObjectBuilder().add("JWT", jwt).build();
			
			retorno= Response.status(Response.Status.CREATED).entity(json).build();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		// en caso de que no btengamos un usuario por parte del servidor, retornamos una
		// respueta negativa por parte del servidor
		return retorno;
	}
	
	@GET
	@Path("/Verificacion/{id_hecho}")
	@Produces(value = { MediaType.APPLICATION_JSON })
	public DTVerificacion obtenerVerificion(@PathParam("id_hecho") int id_hecho) {
		return sbfront.obtenerVerificacion(id_hecho);
	}
}
