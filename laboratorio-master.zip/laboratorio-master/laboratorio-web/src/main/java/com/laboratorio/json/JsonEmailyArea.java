package com.laboratorio.json;

import com.laboratorio.e_num.EArea;

public class JsonEmailyArea {
		
		private String email;
		private EArea area;
		
		public JsonEmailyArea(){
			super();
		}
		
		public JsonEmailyArea(String email, EArea area) {
			
			this.setEmail(email);
			this.setArea(area);
			
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public EArea getArea() {
			return area;
		}

		public void setArea(EArea area) {
			this.area = area;
		}
}
