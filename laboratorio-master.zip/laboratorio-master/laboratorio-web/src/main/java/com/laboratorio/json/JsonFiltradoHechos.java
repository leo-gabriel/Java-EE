package com.laboratorio.json;

public class JsonFiltradoHechos {
	
	private String estado;
	private String tipo;
	private String usuario;
	private String veracidad;
	private String area;
	
	public JsonFiltradoHechos() {
		super();
	}
	
	public JsonFiltradoHechos(String estado, String tipo, String usuario, String veracidad, String area) {
		super();
		this.estado = estado;
		this.tipo = tipo;
		this.usuario = usuario;
		this.veracidad = veracidad;
		this.area = area;
	}
	
	
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getVeracidad() {
		return veracidad;
	}
	public void setVeracidad(String veracidad) {
		this.veracidad = veracidad;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	

}
