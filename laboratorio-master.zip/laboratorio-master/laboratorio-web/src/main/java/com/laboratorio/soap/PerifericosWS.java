package com.laboratorio.soap;

import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import com.laboratorio.datatype.DTCalificacion;
import com.laboratorio.sb.SBCalificacionesLocal;



@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC)
public class PerifericosWS {
	@EJB
	private SBCalificacionesLocal sbc;
	
	@WebMethod
	public void recibirCalificacion(DTCalificacion calificacion) {
		sbc.recibirCalificacionExterna(calificacion);
	}
}
