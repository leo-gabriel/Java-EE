package com.laboratorio.json;

public class Json_Donacion {
	private String orderID;

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public Json_Donacion(String orderID) {
		super();
		this.orderID = orderID;
	}

	public Json_Donacion() {
		super();
	}
	
}
