package com.laboratorio.json;

public class Json_Token {
	
	private String token;
	
	public Json_Token() {
		super();
	}

	public Json_Token(String token) {
		super();
		this.token = token;
	}
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	
	
	

}
