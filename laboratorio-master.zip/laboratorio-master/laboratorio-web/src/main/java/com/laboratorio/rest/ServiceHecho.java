package com.laboratorio.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.laboratorio.datatype.DTCalificacion;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.FechaToDate;
import com.laboratorio.json.JsonFiltradoHechos;
import com.laboratorio.json.JsonHecho;
import com.laboratorio.json.JsonCalificacion;
import com.laboratorio.sb.SBCalificaciones;
import com.laboratorio.sb.SBHechoLocalBO;
import com.periferico.soapexterno.DtCalificacion;
import com.periferico.soapexterno.DtHecho;
import com.periferico.soapexterno.Soap;
import com.periferico.soapexterno.SoapService;

import java.net.MalformedURLException;
import java.net.URL;

@Path("/wsHecho")
public class ServiceHecho {

	@EJB
	private SBHechoLocalBO sbback;
	@EJB
	private SBCalificaciones sbcal;

	// public List<DTHecho> listadoDeHechos(@PathParam("estado") EEstado estado,
	// @PathParam("tipo") String tipo,
	// @PathParam("usuario") String emailusuario, @PathParam("veracidad") EVeracidad
	// veracidad, @PathParam("area") EArea area) {
	// @Path("/listadoDeHechos/{estado}/")
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON })
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/listadoDeHechos")
	public List<DTHecho> listadoDeHechos(JsonFiltradoHechos json) {
		EEstado estado = null;
		EVeracidad veracidad = null;
		EArea area = null;

		System.out.println(json.getEstado());

		if (json.getEstado() != null)
			estado = EEstado.valueOf(json.getEstado());
		if (json.getVeracidad() != null)
			veracidad = EVeracidad.valueOf(json.getVeracidad());
		if (json.getArea() != null)
			area = EArea.valueOf(json.getArea());

		return sbback.listadoDeHechos(estado, json.getTipo(), json.getUsuario(), veracidad, area);
	}

	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/addHecho")
	public Response crearHecho(JsonHecho jhecho) {
		Response retorno = Response.status(Response.Status.UNAUTHORIZED).build();
		
			FechaToDate fecha = new FechaToDate();
			DTHecho dthecho = new DTHecho(jhecho.getTitulo(), jhecho.getId(), jhecho.getLink(),
					fecha.fechaSistema(), jhecho.getMedio(), EEstado.valueOf(jhecho.getEstado()),
					EArea.valueOf(jhecho.getArea()), null,
					jhecho.getEmailusuario(), jhecho.getFrase(), jhecho.getAutor(), jhecho.getImagen());

			if (sbback.crearHechoVerificar(dthecho))
				retorno = Response.status(Response.Status.CREATED).build();
		

	return retorno;
	}
	
	@GET
	@Produces(value = { MediaType.APPLICATION_JSON })
	@Path("/isVerificada/{id}")
	public DTCalificacion isVerificado(@PathParam("id") int id) {
		
		DTCalificacion ret = sbcal.listarCalificacionesHecho(id);
		sbcal.eliminarCalificacion(id);
		return ret;
		
	}
	
	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	@Path("/verificarautomatico")
	public JsonCalificacion calificarHecho(JsonHecho hecho) {
		try {
			SoapService soapService;
			//soapService = new SoapService(new URL(Configuracion.getPerifericoHabilitado.getUrl() + "/PerifericoExterno-web/Soap?wsdl"));
			soapService = new SoapService(new URL("http://localhost:8080" + "/PerifericoExterno-web/Soap?wsdl"));
			Soap soap = soapService.getSoapPort();
			DtHecho aux = new DtHecho();
			aux.setId(hecho.getId());
			aux.setTitulo(hecho.getTitulo());
			DtCalificacion calificacion = soap.verificarHechoAutomatico(aux);
			JsonCalificacion ret = new JsonCalificacion();
			ret.setIdHecho(calificacion.getIdHecho());
			ret.setJustificacion(calificacion.getJustificacion());
			ret.setVeracidad(calificacion.getVeracidad().toString());
			return ret;
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/verificarprolongado")
	public void calificarHechoProlongado(JsonHecho hecho ) {
		try {
			SoapService soapService;
			//soapService = new SoapService(new URL(Configuracion.getPerifericoHabilitado.getUrl() + "/PerifericoExterno-web/Soap?wsdl"));
			soapService = new SoapService(new URL("http://localhost:8080" + "/PerifericoExterno-web/Soap?wsdl"));
			Soap soap = soapService.getSoapPort();
			DtHecho aux = new DtHecho();
			aux.setId(hecho.getId());
			aux.setTitulo(hecho.getTitulo());
			soap.agregarHecho(aux);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
}
