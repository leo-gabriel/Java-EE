package com.laboratorio.mbperiferico;


import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.laboratorio.datatype.DTHecho;
import com.laboratorio.sb.SBHechoLocalBO;

@ManagedBean(name = "periferico")
@SessionScoped

public class mbperiferico{
	
	private List<DTHecho> hechos;
	private String hola;
    public mbperiferico() {
    	hola = "caca";
    }
    
    @EJB    
    private SBHechoLocalBO sbean;
    
    
    
    public List<DTHecho> getHechos(){
    	
    	hechos = sbean.listadoDeHechos(null, null, null, null, null);
    	return hechos;
    }    
    
    public void setHechos(List<DTHecho> hechos) {
		this.hechos = hechos;
	}

	public String getHola() {
		return hola;
	}

	public void setHola(String hola) {
		this.hola = hola;
	}
    
    
}