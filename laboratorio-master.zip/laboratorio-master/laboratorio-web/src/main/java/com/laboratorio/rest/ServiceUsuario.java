package com.laboratorio.rest;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Date;

import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.laboratorio.datatype.DTChecker;
import com.laboratorio.datatype.DTCitizen;
import com.laboratorio.datatype.DTSubmitter;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.extra.Constantes;
import com.laboratorio.json.JsonUsuario;
import com.laboratorio.json.Json_Donacion;
import com.laboratorio.json.Json_Token;
import com.laboratorio.sb.SBHechoFOLocal;
import com.laboratorio.sb.SBHechoLocalBO;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Path("/wsUsuario")
public class ServiceUsuario {

	@EJB
	private SBHechoFOLocal sbFO;
	@EJB
	private SBHechoLocalBO sbBO;

	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/registro")
	public Response registroUsuario(JsonUsuario jusuario) {

		if (jusuario.getTipo().equals("DTChecker")) {
			DTChecker dtusuario = new DTChecker(jusuario.getUsername(), jusuario.getEmail(), jusuario.getPassword(),
					null, jusuario.getCi());
			sbBO.altaUsuario(dtusuario);
			return Response.status(Response.Status.CREATED).build();
		} else if (jusuario.getTipo().equals("DTSubmitter")) {
			DTSubmitter dtusuario = new DTSubmitter(jusuario.getUsername(), jusuario.getEmail(),
					jusuario.getPassword(), null, jusuario.getCi());
			sbBO.altaUsuario(dtusuario);
			return Response.status(Response.Status.CREATED).build();
		} else {
			System.out.println("No se puede registrar usuario");
			return Response.status(Response.Status.UNAUTHORIZED).build();
		}
	}

	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	@Path("/LoginToken")
	public Response loginToken(JsonUsuario usuario) {

		// ESTE IF CONTROLA SI EXISTE EL USUARIO EN LA BASE
		if (sbBO.login(usuario.getEmail(), usuario.getPassword()) != null) {
			DTUsuario user = sbBO.login(usuario.getEmail(), usuario.getPassword());
			// instanceo la clase para poder traer la constante clavetoken
			Constantes constante = new Constantes();
			// instanceo la clase jwts con la que voy a generar el token firmado con el
			// algoritmos hash(hs256) y una clave
			String jwt = Jwts.builder().setSubject(usuario.getEmail())// se puede sacar dato
					.signWith(SignatureAlgorithm.HS256, constante.getClavetoken())// utilizo algoritmo y clave

					.setExpiration(new Date(System.currentTimeMillis() + 900000))// calcula 15 minutos y expira el token
																					// de la sesion
					.claim("tipousuario", user.getClass().getSimpleName())// los claim agregan info al token
					.compact(); // compactamos todo
			// generarmos un json y luego le asignamos nuestro token
			JsonObject json = Json.createObjectBuilder().add("JWT", jwt).build();

			// retornamos una respuesta de servidor en conjunto con un json
			return Response.status(Response.Status.CREATED).entity(json).build();
		}

		// en caso de que no btengamos un usuario por parte del servidor, retornamos una
		// respueta negativa por parte del servidor
		return Response.status(Response.Status.UNAUTHORIZED).build();
	}

	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/LoginGoogle")
	public Response loginGoogle(Json_Token jcitizen) {

		DTCitizen citizen;
		try {
			citizen = sbFO.validacionTokenGoogle(jcitizen.getToken());
			// instanceo la clase para poder traer la constante password
			Constantes constante = new Constantes();
			// instanceo la clase jwts con la que voy a generar el token firmado con el
			// algoritmos hash(hs256) y una clave
			String jwt = Jwts.builder().setSubject(citizen.getEmail())// se puede sacar dato
					.signWith(SignatureAlgorithm.HS256, constante.getClavetoken())// utilizo algoritmo y clave
					.setExpiration(new Date(System.currentTimeMillis() + 900000))// calcula 15 minutos y expira el token
																					// de la sesion
					.compact(); // compactamos todo

			// generarmos un json y luego le asignamos nuestro token
			JsonObject json = Json.createObjectBuilder().add("JWT", jwt).build();

			if (!sbFO.login(citizen.getEmail())) {
				sbFO.altaUsuario(sbFO.validacionTokenGoogle(jcitizen.getToken()));
				// retornamos una respuesta de servidor en conjunto con un json
				return Response.status(Response.Status.CREATED).entity(json).build();
			} else
				return Response.status(Response.Status.CREATED).entity(json).build();
		} catch (GeneralSecurityException | IOException e) {
			e.printStackTrace();
		}
		// en caso de que no btengamos un usuario por parte del servidor, retornamos una
		// respueta negativa por parte del servidor
		return Response.status(Response.Status.UNAUTHORIZED).build();
	}
	
	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Path("/DonacionPayPal")
	public void donacionPayPal(Json_Donacion donacion) {
		sbFO.realizarDonacion(donacion.getOrderID());	
	}

}
