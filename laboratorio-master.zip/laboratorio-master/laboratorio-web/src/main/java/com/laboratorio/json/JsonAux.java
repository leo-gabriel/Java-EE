package com.laboratorio.json;

import com.laboratorio.e_num.EVeracidad;

public class JsonAux {
	
	private String calificacion;
	private EVeracidad veracidad;
	
	public JsonAux(){
		super();
	}
	
	public JsonAux(String calificacion, EVeracidad veracidad) {
		
		this.calificacion = calificacion;
		this.veracidad = veracidad;
		
	}
	
	public String getCalificacion() {
		return calificacion;
	}
	public void setCalificacion(String calificacion) {
		this.calificacion = calificacion;
	}

	public EVeracidad getVeracidad() {
		return veracidad;
	}

	public void setVeracidad(EVeracidad veracidad) {
		this.veracidad = veracidad;
	}

}
