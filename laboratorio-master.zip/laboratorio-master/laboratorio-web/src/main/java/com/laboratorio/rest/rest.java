package com.laboratorio.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.laboratorio.datatype.DTChecker;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.datatype.DTVerificacion;
import com.laboratorio.json.JsonAux;
import com.laboratorio.json.JsonEmailyArea;
import com.laboratorio.json.JsonUsuario;
import com.laboratorio.sb.SBHechoFOLocal;
import com.laboratorio.sb.SBHechoLocalBO;

@Path("/RestServices")
@Stateless
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public class rest {

	@EJB
	private SBHechoLocalBO sbback;
	@EJB
	private SBHechoFOLocal sbfront;

	@GET
	@Path("/Verificacion/{id_hecho}")
	public DTVerificacion obtenerVerificion(@PathParam("id_hecho") int id_hecho) {
		return sbfront.obtenerVerificacion(id_hecho);
	}

	@GET
	@Path("/Hecho/{id}")
	public DTHecho getHecho(@PathParam("id") int idhecho) {
		return sbback.getHecho(idhecho);
	}

	@GET
	@Path("/Usuarios/Checkers")
	public List<DTChecker> getCheckers() {
		return sbback.listadoChecker();
	}

	@PUT
	@Path("/Hecho/UpdateA_COMPROBAR/{id}")
	public void aCOMPROBARHecho(@PathParam("id") int idhecho, JsonUsuario usuario) {

		DTHecho hecho = new DTHecho();
		DTUsuario checker = new DTUsuario();
		checker.setEmail(usuario.getEmail());
		hecho.setId(idhecho);
		sbback.seleccionarHechoVerificar(hecho);
		sbback.asignarHechoVerificar(hecho, checker);
	}

	@PUT
	@Path("/Hecho/UpdateEN_PROCESO/{id}")
	public void enPROCESOHecho(@PathParam("id") int idhecho) {
		DTHecho hecho = new DTHecho();
		hecho.setId(idhecho);
		sbback.tomarHechoVerificar(hecho);
	}

	@PUT
	@Path("/Hecho/UpdatePUBLICAR/{id}")
	public void pUBLICARHecho(@PathParam("id") int idhecho, JsonEmailyArea jea) {
		DTHecho hecho = sbback.getHecho(idhecho);
		DTUsuario user = new DTUsuario();
		user.setEmail(jea.getEmail());
		hecho.setId(idhecho);
		hecho.setArea(jea.getArea());
		sbback.publicarHecho(hecho, user);
	}

	@PUT
	@Path("/Hecho/UpdateVERIFICADO/{id}")
	public void vERIFICARHecho(@PathParam("id") int idhecho, JsonAux body) {
		DTHecho hecho = new DTHecho();
		hecho.setId(idhecho);
		sbback.verificarHecho(hecho, body.getVeracidad(), body.getCalificacion());
	}
}
