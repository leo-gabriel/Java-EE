package com.laboratorio.c_lass;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;

@Entity
@DiscriminatorValue(value = "FRASE")
public class Frase extends Hecho implements Serializable {
	private static final long serialVersionUID = 1L;

	private String frase;
	private String autor;

	public Frase() {
		super();
	}

	public Frase(String titulo, String link, Date fecha, String medio, EEstado estado, EArea area, String frase,
			String autor, Usuario usuario) {
		super(titulo, link, fecha, medio, estado, area, usuario);
		this.frase = frase;
		this.autor = autor;
	}

	public String getFrase() {
		return frase;
	}

	public void setFrase(String frase) {
		this.frase = frase;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

}
