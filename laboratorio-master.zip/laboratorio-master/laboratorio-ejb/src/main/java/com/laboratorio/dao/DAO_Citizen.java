package com.laboratorio.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.laboratorio.c_lass.Citizen;
import com.laboratorio.c_lass.Donacion;
import com.laboratorio.c_lass.Hecho;
import com.laboratorio.c_lass.Suscripcion;
import com.laboratorio.c_lass.Verificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.Constantes;
import com.laboratorio.extra.FechaToDate;
import com.laboratorio.extra.HechoTop;
import com.laboratorio.extra.SimilitudHechos;

@Stateless
@LocalBean
public class DAO_Citizen {

	@PersistenceContext(unitName = "PERSISTENCE_CONTEXT_NAME")
	private EntityManager ema;

	private Constantes constante = new Constantes();

	@EJB
	private DAO_Extra dao;

	public DAO_Citizen() {
	}

	public List<Hecho> listadoHechosFO(int numero_pagina) {
		TypedQuery<Hecho> query = ema.createQuery("SELECT h FROM Hecho h where h.estado = :estado", Hecho.class);
		query.setParameter("estado", EEstado.PUBLICADO);
		List<Hecho> retorno = dao.paginacion(numero_pagina, query);
		return retorno;
	}

	public List<Hecho> busquedaHechos(String nombre) {
		TypedQuery<Hecho> query = ema.createQuery("SELECT h FROM Hecho h where h.estado = :estado", Hecho.class);
		query.setParameter("estado", EEstado.PUBLICADO);
		List<Hecho> lista = query.getResultList();
		List<Hecho> retorno = new ArrayList<>();
		for (Hecho var : lista) {
			String texto = var.getTitulo();
			boolean resultado = texto.contains(nombre);
			if (resultado)
				retorno.add(var);
		}
		return retorno;
	}

	public void altaUsuario(Citizen citizen) {
		ema.persist(citizen);
	}

	public void suscripcion(EArea area, Citizen usuario) {
		TypedQuery<Suscripcion> query = ema.createQuery("SELECT s FROM Suscripcion s WHERE s.area = :area",
				Suscripcion.class);
		query.setParameter("area", area);
		Suscripcion suscripcion = query.getSingleResult();
		suscripcion.setCitizensuscriptos(usuario);
		ema.persist(suscripcion);
	}

	public void realizarDonacion(Donacion donacion) {
		ema.persist(donacion);
	}

	// TOMO LOS TOP FAKE DE 7 DIAS ASIA ATRAS
	public List<HechoTop> reporteTopHechoFake() {
		List<Hecho> lista_fake = new ArrayList<>();
		FechaToDate fecha = new FechaToDate();
		Date hoy = fecha.fechaSistema();
		// constante.numero_dias ES UNA VARIABLE CONSTANTE DEFINIDA EN CONSTANTE
		for (int i = 1; i <= constante.getNumerodias(); i++) {
			Date valorfecha = fecha.restarDiasFecha(hoy, i);
			TypedQuery<Hecho> query = ema.createQuery(
					"SELECT h FROM Hecho h WHERE h.fecha = :fecha and h.veracidad = :veracidad", Hecho.class);
			query.setParameter("fecha", valorfecha);
			query.setParameter("veracidad", EVeracidad.FALSA);
			lista_fake.addAll(query.getResultList());
		}
		List<Hecho> auxiliar = lista_fake;
		List<HechoTop> retorno = new ArrayList<>();
		SimilitudHechos shecho = new SimilitudHechos();
		HechoTop htop = new HechoTop();
		for (Hecho var : lista_fake) {
			if (retorno.isEmpty()) {

				retorno.add(htop.contartop(auxiliar, var));
			} else {

				Iterator<HechoTop> ite = retorno.iterator();
				while (ite.hasNext()) {

					HechoTop aux = ite.next();
					HechoTop actual = htop.contartop(auxiliar, var);
					shecho.setWords(aux.getHecho().getTitulo(), actual.getHecho().getTitulo());
					if (aux.getCantidad() < actual.getCantidad()) {

						retorno.clear();

						retorno.add(actual);
						ite = retorno.iterator();
					} else if ((aux.getCantidad() == actual.getCantidad()) && (!shecho.getAfinidad())
							&& (!ite.hasNext())) {

						retorno.add(actual);
						ite = retorno.iterator();
					}
				}
			}
		}

		return retorno;
	}

	public List<Hecho> reporteNoticasPorVeracidad() {
		List<Hecho> retorno = new ArrayList<>();
		FechaToDate fecha = new FechaToDate();
		Date hoy = fecha.fechaSistema();
		for (int i = 1; i <= constante.getNumerodias(); i++) {
			Date valorfecha = fecha.restarDiasFecha(hoy, i);
			TypedQuery<Hecho> query = ema
					.createQuery("SELECT h FROM Hecho h WHERE h.fecha = :fecha order by h.veracidad", Hecho.class);
			query.setParameter("fecha", valorfecha);
			retorno.addAll(query.getResultList());
		}
		Collections.sort(retorno, (x, y) -> x.getVeracidad().compareTo(y.getVeracidad()));
		return retorno;
	}

	public void crearHechoVerificar(Hecho hecho) {
		ema.persist(hecho);
	}

	public Verificacion obtenerVerificacion(int id_hecho) {
		// BUSCAMOS LA VERIFICACION CORRECTA
		TypedQuery<Verificacion> query1 = ema
				.createQuery("SELECT v FROM Verificacion v WHERE  v.hecho.idhecho = :hecho_id", Verificacion.class);
		query1.setParameter("hecho_id", id_hecho);
		return query1.getSingleResult();
	}

}