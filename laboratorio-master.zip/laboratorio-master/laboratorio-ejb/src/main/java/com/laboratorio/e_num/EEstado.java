package com.laboratorio.e_num;

public enum EEstado {

	NUEVO, A_COMPROBAR, EN_PROCESO, VERIFICADO, PUBLICADO, CANCELADO
	
}
