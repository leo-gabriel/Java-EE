package com.laboratorio.e_num;

public enum EVeracidad {
	
	VERDADERA, VERDAD_A_MEDIAS, INFLADA, ENGANIOSA, FALSA, RIDICULA, VERACIDAD;

}
