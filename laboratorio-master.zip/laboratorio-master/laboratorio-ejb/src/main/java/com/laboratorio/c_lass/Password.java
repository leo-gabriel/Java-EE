package com.laboratorio.c_lass;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "password")
public class Password {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int idpassword;
	@OneToOne(mappedBy = "password")
	private Usuario usuario;
	private String hash;
	private String salt;
	
	public Password() {}
	
	public Password(String hash, String salt) {
		
		this.hash = hash;
		this.salt = salt;
	}

	public int getId() {
		return idpassword;
	}

	public void setId(int idpassword) {
		this.idpassword = idpassword;
	}
	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}
	
	
}
