package com.laboratorio.extra;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.laboratorio.datatype.DTCitizen;

import io.jsonwebtoken.Jwts;



public class Validaciones {

	public Validaciones() {
	}

	public boolean validacionEmail(String email) {
		Pattern pattern = Pattern.compile(
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher mather = pattern.matcher(email);
		return mather.find();
	}

	public boolean validacionToken(String token) {
		boolean retorno = false;
		String jwttoken = token.substring(8, token.length() - 2);
		Constantes con = new Constantes();
		try {
			Jwts.parser().setSigningKey(con.getClavetoken()).parseClaimsJws(jwttoken);
			try {
				Date fechaactual = new Date();
				Date expiracion = Jwts.parser().setSigningKey(con.getClavetoken()).parseClaimsJws(jwttoken).getBody()
						.getExpiration();
				
				if (expiracion.compareTo(fechaactual) > 0)
					retorno = true;
				else
					retorno = false;

			} catch (Exception e) {
				System.out.println("Ocurrio un error con su token.");
			}
		} catch (Exception e) {
			System.out.println("Token no valido.");
		}
		return retorno;
	}

	public DTCitizen validacionTokenGoogle(String TokenString) {
		DTCitizen retorno = null;
		GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new NetHttpTransport(),
				JacksonFactory.getDefaultInstance())
						// Specify the CLIENT_ID of the app that accesses the backend:
						.setAudience(Collections.singletonList(
								"730445304978-3qvroous7kln6sjreil1flpe1jcj427i.apps.googleusercontent.com"))
						// Or, if multiple clients access the backend:
						.build();

		try {
			// (Receive TokenString by HTTPS POST)
			GoogleIdToken idToken = verifier.verify(TokenString);

			if (idToken != null) {
				Payload payload = idToken.getPayload();

				// Get profile information from payload
				String email = payload.getEmail();
				String name = (String) payload.get("name");

				Constantes con = new Constantes();
				retorno = new DTCitizen(name, email, con.getPassword(), null, null);

			} else {
				System.out.println("FrontOffice-Token invalido.");
			}
		} catch (GeneralSecurityException | IOException e) {
			e.printStackTrace();
		}

		return retorno;
	}

	public DTCitizen validacionTokenGoogleMobile(String TokenString) {
		DTCitizen retorno = null;
		GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new NetHttpTransport(),
				JacksonFactory.getDefaultInstance())
						// Specify the CLIENT_ID of the app that accesses the backend:
						.setAudience(Collections.singletonList(
								"260736801889-dmjn6foc8ovrie6dmj50pqprgepg88dk.apps.googleusercontent.com"))
						// Or, if multiple clients access the backend:
						.build();

		try {
			// (Receive TokenString by HTTPS POST)
			GoogleIdToken idToken = verifier.verify(TokenString);

			if (idToken != null) {
				Payload payload = idToken.getPayload();

				// Get profile information from payload
				String email = payload.getEmail();
				String name = (String) payload.get("name");

				Constantes con = new Constantes();
				retorno = new DTCitizen(name, email, con.getPassword(), null, null);

			} else {
				System.out.println("Mobile-Token invalido.");
			}
		} catch (GeneralSecurityException | IOException e) {
			e.printStackTrace();
		}

		return retorno;
	}
	
	
	
}
