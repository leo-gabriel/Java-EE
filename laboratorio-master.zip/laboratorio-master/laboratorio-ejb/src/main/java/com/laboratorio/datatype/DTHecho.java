package com.laboratorio.datatype;

import java.util.Date;

import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;

public class DTHecho {
	
	private int idhecho;
	private String titulo;
	private String link;
	private Date fecha;
	private String medio;
	private EEstado estado;
	private EArea area;
	private EVeracidad veracidad;
	private String emailusuario;
	private String frase;
	private String autor;
	private String imagen;
	
	public DTHecho() {}
	
	public DTHecho(String titulo, int idhecho, String link, Date fecha, String medio, EEstado estado, EArea area, EVeracidad veracidad,
			String email_usuario, String frase, String autor, String imagen) {
		
		this.titulo=titulo;
		this.idhecho = idhecho;
		this.link = link;
		this.fecha = fecha;
		this.medio = medio;
		this.estado = estado;
		this.area = area;
		this.veracidad = veracidad;
		this.emailusuario = email_usuario;
		this.frase = frase;
		this.autor = autor;
		this.imagen = imagen;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getId() {
		return idhecho;
	}

	public void setId(int idhecho) {
		this.idhecho = idhecho;
	}

	public String getEmailusuario() {
		return emailusuario;
	}

	public void setEmailusuario(String email_usuario) {
		this.emailusuario = email_usuario;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getMedio() {
		return medio;
	}

	public void setMedio(String medio) {
		this.medio = medio;
	}

	public EEstado getEstado() {
		return estado;
	}

	public void setEstado(EEstado estado) {
		this.estado = estado;
	}

	public EArea getArea() {
		return area;
	}

	public void setArea(EArea area) {
		this.area = area;
	}

	public EVeracidad getVeracidad() {
		return veracidad;
	}

	public void setVeracidad(EVeracidad veracidad) {
		this.veracidad = veracidad;
	}

	public String getFrase() {
		return frase;
	}

	public void setFrase(String frase) {
		this.frase = frase;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
}
