package com.laboratorio.datatype;

import java.io.Serializable;
import java.util.List;

public class DTChecker extends DTUsuario implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int ciche;

	public DTChecker() {
		super();
	}

	public DTChecker(String user_name, String email, String password, List<DTHecho> hechos, int ciche) {
		super(user_name, email, password, hechos);
		this.ciche=ciche;
	}

	public int getCi() {
		return ciche;
	}

	public void setCi(int ciche) {
		this.ciche = ciche;
	}
	
	
}
