package com.laboratorio.sb;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;

import com.laboratorio.c_lass.Admin;
import com.laboratorio.c_lass.Checker;
import com.laboratorio.c_lass.Frase;
import com.laboratorio.c_lass.Hecho;
import com.laboratorio.c_lass.Noticia;
import com.laboratorio.c_lass.Password;
import com.laboratorio.c_lass.Submitter;
import com.laboratorio.c_lass.Usuario;
import com.laboratorio.c_lass.Verificacion;
import com.laboratorio.dao.DAO_Extra;
import com.laboratorio.dao.DAO_Submitter_Checker;
import com.laboratorio.datatype.DTAdmin;
import com.laboratorio.datatype.DTCalificacion;
import com.laboratorio.datatype.DTChecker;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTSubmitter;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.datatype.DTVerificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.EncriptacionPassword;
import com.laboratorio.extra.Validaciones;

@Stateless
@Local(SBHechoLocalBO.class)
public class SBHechoBO implements SBHechoLocalBO {

	@EJB
	private DAO_Submitter_Checker dao;
	@EJB
	private DAO_Extra daoExtra;

	public SBHechoBO() {
	}

	@Override
	public boolean crearHechoVerificar(DTHecho hecho) {
		boolean retorno = false;
		// HAY QUE CONTROLAR QUE EL USUARIO ESTE LOGUEADO
		if (hecho.getImagen() != null) {
			Noticia hecho_noticia = new Noticia(hecho.getTitulo(), hecho.getLink(), hecho.getFecha(), hecho.getMedio(),
					hecho.getEstado(), hecho.getArea(), hecho.getImagen(),
					daoExtra.buscarUsuarioEmail(hecho.getEmailusuario()));
			dao.crearHechoVerificar(hecho_noticia);
			retorno = true;
		} else {
			Frase hecho_frase = new Frase(hecho.getTitulo(), hecho.getLink(), hecho.getFecha(), hecho.getMedio(),
					hecho.getEstado(), hecho.getArea(), hecho.getFrase(), hecho.getAutor(),
					daoExtra.buscarUsuarioEmail(hecho.getEmailusuario()));
			dao.crearHechoVerificar(hecho_frase);
			retorno = true;
		}
		return retorno;
	}

	@Override
	public List<DTChecker> listadoChecker() {
		List<DTChecker> retorno = new ArrayList<>();
		for (Usuario var : dao.listadoChecker()) {
			Checker checker = (Checker) var;
			List<DTHecho> hechos = new ArrayList<>();
			for (Hecho var1 : checker.getHecho()) {
				hechos.add(daoExtra.hechoDTHecho(var1));
			}
			DTChecker aux = new DTChecker(checker.getUsername(), checker.getEmail(),
					checker.getPassword().getHash() + checker.getPassword().getSalt(), hechos, checker.getCi());
			retorno.add(aux);
		}
		return retorno;
	}

	@Override
	public boolean seleccionarHechoVerificar(DTHecho hecho) {
		boolean retorno = false;
		if (daoExtra.verificoEstado(hecho.getId(), EEstado.NUEVO)) {
			dao.seleccionarHechoVerificar(hecho.getId());
			retorno = true;
		}
		return retorno;
	}

	@Override
	public List<DTHecho> listadoDeHechos(EEstado estado, String tipo, String emailusuario, EVeracidad veracidad, EArea area) {
		List<DTHecho> retorno = new ArrayList<>();
		List<Hecho> lista = dao.listadoDeHechos(estado, tipo, emailusuario, veracidad, area);
		for (Hecho var : lista) {
			retorno.add(daoExtra.hechoDTHecho(var));
		}
		return retorno;
	}

	@Override
	public boolean asignarHechoVerificar(DTHecho hecho, DTUsuario usuario) {
		boolean retorno = false;
		if (daoExtra.verificoEstado(hecho.getId(), EEstado.A_COMPROBAR)) {
			if (daoExtra.existeUsuario(usuario.getEmail())) {
				dao.asignarHechoVerificar(hecho.getId(), daoExtra.buscarUsuarioEmail(usuario.getEmail()));
				retorno = true;
			}
		}
		return retorno;
	}

	@Override
	public boolean tomarHechoVerificar(DTHecho hecho) {
		boolean retorno = false;
		if (daoExtra.verificoEstado(hecho.getId(), EEstado.A_COMPROBAR)) {
			dao.tomarHechoVerificar(hecho.getId());
			retorno = true;
		}
		return retorno;
	}

	@Override
	public boolean verificarHecho(DTHecho hecho, EVeracidad veracidad, String justificacion) {
		boolean retorno = false;
		if (daoExtra.verificoEstado(hecho.getId(), EEstado.EN_PROCESO)) {
			dao.verificarHecho(hecho.getId(), veracidad, justificacion);
			retorno = true;
		}
		return retorno;
	}

	@Override
	public boolean publicarHecho(DTHecho hecho, DTUsuario usuario) {
		boolean retorno = false;
		if (daoExtra.verificoEstado(hecho.getId(), EEstado.VERIFICADO)) {
			if (daoExtra.existeUsuario(usuario.getEmail())) {
				dao.publicarHecho(hecho.getId(), daoExtra.buscarUsuarioEmail(usuario.getEmail()));
				daoExtra.notifiacionEmail(hecho);
				retorno = true;
			}
		}
		return retorno;
	}

	@Override
	public boolean cancelarHecho(DTHecho hecho, DTUsuario usuario) {
		boolean retorno = false;
		if (daoExtra.verificoEstado(hecho.getId(), EEstado.NUEVO)) {
			if (daoExtra.existeUsuario(usuario.getEmail())) {
				dao.cancelarHecho(hecho.getId(), daoExtra.buscarUsuarioEmail(usuario.getEmail()));
				retorno = true;
			}
		}
		return retorno;
	}

	@Override
	public boolean altaUsuario(DTUsuario usuario) {
		boolean retorno = false;
		if (!daoExtra.existeUsuario(usuario.getEmail())) {

			if (usuario.getClass().getSimpleName().equals("DTAdmin")) {
				try {
					Password password = EncriptacionPassword.getHashSalt(usuario.getPassword());
					DTAdmin dtadmin = (DTAdmin) usuario;
					Admin admin = new Admin(dtadmin.getUsername(), dtadmin.getEmail(), password, dtadmin.getCi());
					dao.altaUsuario(admin);
					retorno = true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (usuario.getClass().getSimpleName().equals("DTSubmitter")) {
				try {
					Password password = EncriptacionPassword.getHashSalt(usuario.getPassword());
					DTSubmitter dtsubmitter = (DTSubmitter) usuario;
					Submitter submitter = new Submitter(dtsubmitter.getUsername(), dtsubmitter.getEmail(), password,
							dtsubmitter.getCi());
					dao.altaUsuario(submitter);
					retorno = true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (usuario.getClass().getSimpleName().equals("DTChecker")) {
				try {
					Password password = EncriptacionPassword.getHashSalt(usuario.getPassword());
					DTChecker dtchecker = (DTChecker) usuario;
					Checker checker = new Checker(dtchecker.getUsername(), dtchecker.getEmail(), password,
							dtchecker.getCi());
					dao.altaUsuario(checker);
					retorno = true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return retorno;
	}

	@Override
	public boolean recibirCalificacionExterna(DTCalificacion calificacion) {
		return verificarHecho(daoExtra.hechoDTHecho(daoExtra.buscarHecho(calificacion.getIdHecho())),
				calificacion.getVeracidad(), calificacion.getJustificacion());
	}

	@Override
	public DTHecho getHecho(int idhecho) {
		Hecho hecho = dao.getHecho(idhecho);
		DTHecho hechoDT = daoExtra.hechoDTHecho(hecho);
		return hechoDT;
	}

	@Override
	public DTUsuario login(String email, String password) {
		DTUsuario dtusuario = null;
		if (daoExtra.existeUsuario(email))
			if (daoExtra.verificoPassword(email, password))
				dtusuario = daoExtra.buscarDTUsuarioEmail(email);
		return dtusuario;
	}

	@Override
	public DTVerificacion obtenerVerificacion(String email_usuario, int id_hecho) {
		Verificacion var = dao.obtenerVerificacion(email_usuario, id_hecho);
		DTVerificacion retorno = new DTVerificacion(var.getFechainicio(), var.getFechafin(), var.getCalifiacion(),
				var.getJustifiacion(), daoExtra.hechoDTHecho(daoExtra.buscarHecho(id_hecho)),
				daoExtra.buscarDTUsuarioEmail(email_usuario));
		return retorno;
	}

	@Override
	public boolean validacionToken(String jwt) {
		Validaciones validacion = new Validaciones();
		return validacion.validacionToken(jwt);
	}
}
