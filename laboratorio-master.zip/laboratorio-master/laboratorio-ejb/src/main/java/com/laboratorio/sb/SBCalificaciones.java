package com.laboratorio.sb;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import com.laboratorio.datatype.DTCalificacion;

@Singleton
@Startup
@LocalBean
public class SBCalificaciones implements SBCalificacionesLocal {

	private List<DTCalificacion> listaCalificaciones;

	public SBCalificaciones() {
	}

	@PostConstruct
	public void initialize() {
		listaCalificaciones = new ArrayList<DTCalificacion>();
	}

	@Override
	public boolean recibirCalificacionExterna(DTCalificacion calificacion) {
		return listaCalificaciones.add(calificacion);
	}

	@Override
	public boolean eliminarCalificacion(int idhecho) {
		boolean retorno = false;
		Iterator<DTCalificacion> ite = listaCalificaciones.iterator();
		while (ite.hasNext()) {
			DTCalificacion aux = ite.next();
			if (aux.getIdHecho() == idhecho) {
				ite.remove();
				retorno = true;
			}
		}
		return retorno;
	}

	@Override
	public DTCalificacion listarCalificacionesHecho(int idcali) {
		for (DTCalificacion aux : listaCalificaciones)
			if (aux.getIdHecho() == idcali)
				return aux;
		return null;
	}
}
