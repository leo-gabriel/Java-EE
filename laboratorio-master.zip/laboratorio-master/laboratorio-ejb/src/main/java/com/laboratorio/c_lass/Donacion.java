package com.laboratorio.c_lass;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "donacion") 
public class Donacion { 
 
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int iddonacion;
	private float monto;
	@ManyToOne
	private Citizen donador;
	
	public Donacion() {}

	public Donacion(float monto, Citizen donador) {
		this.monto = monto;
		this.donador = donador;
	}

	public int getIddonacion() {
		return iddonacion;
	}

	public float getMonto() {
		return monto;
	}

	public void setMonto(float monto) {
		this.monto = monto;
	}

	public Citizen getDonador() {
		return donador;
	}

	public void setDonador(Citizen donador) {
		this.donador = donador;
	}

	
	

}
