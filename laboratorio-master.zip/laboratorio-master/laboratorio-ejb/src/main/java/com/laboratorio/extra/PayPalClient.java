package com.laboratorio.extra;

import com.paypal.core.PayPalEnvironment;
import com.paypal.core.PayPalHttpClient;

public class PayPalClient {
	
	
	private PayPalEnvironment environment = new PayPalEnvironment.Sandbox(new Constantes().getClientIdPayPal(), new Constantes().getClientSecretPayPal());

	/**
	 * PayPal HTTP client instance with environment that has access credentials
	 * context. Use to invoke PayPal APIs.
	 */
	private PayPalHttpClient client = new PayPalHttpClient(environment);

	/**
	 * Method to get client object
	 *
	 * @return PayPalHttpClient client
	 */
	public PayPalHttpClient client() {
		return this.client;
	}
}
