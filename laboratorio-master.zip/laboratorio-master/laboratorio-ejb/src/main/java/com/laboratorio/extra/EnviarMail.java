package com.laboratorio.extra;

import javax.ws.rs.core.MediaType;

import com.laboratorio.datatype.DTHecho;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class EnviarMail {

	public EnviarMail() {
	}

	public void apiMailgun(String recipient, String user_name, DTHecho hecho) {
		FechaToDate fecha = new FechaToDate();
		Client client = Client.create();
		client.addFilter(new HTTPBasicAuthFilter("api", "280272519b73d10f8c16e9d7e6d6f24a-4a62b8e8-35ba79b5"));
		WebResource webResource = client.resource("https://api.mailgun.net/v3/mg.hechosdraps.com/messages");
		MultivaluedMapImpl formData = new MultivaluedMapImpl();
		formData.add("from", "HechosDRAPS <postmaster@mg.hechosdraps.com>");
		formData.add("to", recipient);
		formData.add("subject", "Notificacion de Hecho");
		formData.add("template", "notificacionhechoprueba");

		formData.add("v:titulo_hecho", hecho.getTitulo());
		formData.add("v:area_hecho", hecho.getArea());
		formData.add("v:titulo_hecho", hecho.getTitulo());
		formData.add("v:link_hecho", hecho.getTitulo());
		formData.add("v:fecha_hecho", fecha.verFecha(hecho.getFecha()));
		formData.add("v:medio_hecho", hecho.getMedio());
		formData.add("v:veracidad_hecho", hecho.getVeracidad());
		formData.add("v:nombre_citizen", user_name);

		webResource.type(MediaType.APPLICATION_FORM_URLENCODED).post(ClientResponse.class, formData);
	}

}
