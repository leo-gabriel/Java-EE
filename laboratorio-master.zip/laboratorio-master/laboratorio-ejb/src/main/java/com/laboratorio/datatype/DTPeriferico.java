package com.laboratorio.datatype;

public class DTPeriferico {
	private String nombre;
	private String url;
	
	public DTPeriferico(String nombre, String url) {
		super();
		this.nombre = nombre;
		this.url = url;
	}
	public String getNombre() {
		return this.nombre;
	}
	public String getUrl() {
		return this.url;
	}
}
