package com.laboratorio.sb;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import javax.ejb.Local;

import com.laboratorio.datatype.DTCitizen;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.datatype.DTVerificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.extra.HechoTop;

@Local
public interface SBHechoFOLocal {
	
	public boolean crearHechoVerificar(DTHecho hecho);
	public List<DTHecho> listadoHechos(int numero_pagina);
	public List<DTHecho> busquedaHechos(String nombre);
	public boolean altaUsuario(DTUsuario usuario);
	public boolean suscripcion(EArea area, DTCitizen citizen);
	public boolean realizarDonacion(String ordenid);
	public boolean login(String email);
	public DTUsuario verPerfil(String email_usuario);
	public DTVerificacion obtenerVerificacion(int id_hecho );
	public List<HechoTop> reporteTopHechoFake();
	public List<DTHecho> reporteNoticasPorVeracidad();
	//FUNCION PARA VALIDAR TOKENGOOGLE
	public DTCitizen validacionTokenGoogle(String TokenString)throws GeneralSecurityException, IOException;
	//FUNCION PARA VALIDAR TOKENGOOGLE MOBILE
	public DTCitizen validacionTokenGoogleMobile(String TokenString);
}
