package com.laboratorio.c_lass;



import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@DiscriminatorValue( value="SUBMITTER" )
public class Submitter extends Usuario implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int ciusuario;

	public Submitter() {
		super();
	}

	public Submitter(String user_name, String email, Password password, int ciusuario) {
		super(user_name, email, password);
		this.ciusuario=ciusuario;
	}

	public int getCi() {
		return ciusuario;
	} 

	public void setCi(int ciusuario) {
		this.ciusuario = ciusuario;
	}
	
	

}
