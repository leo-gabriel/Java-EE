package com.laboratorio.c_lass;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity 
@Table(name = "usuario")
@Inheritance( strategy = InheritanceType.SINGLE_TABLE )
@DiscriminatorColumn( name="tipo" )
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;
 
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idusuario;
	//COLOCAMOS ESTE ATRIBUTO PARA PODER ACCEDER AL @DiscriminatorColumn
	@Column(name="tipo", insertable = false, updatable = false)
	private String tipo; 
	public String getTipo() {
		return tipo;
	}

	private String username; 
	private String email; 
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "password_id", referencedColumnName = "idpassword")
	private Password password;
	
	@OneToMany(mappedBy="usuario")
	private List<Hecho> hecho=new ArrayList<>();
	 
	public Usuario() {}

	public Usuario(String user_name, String email, Password password) {
		this.username = user_name;
		this.email = email;
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String user_name) {
		this.username = user_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Password getPassword() {
		return password;
	}

	public void setPassword(Password password) {
		this.password = password;
	}

	public int getId() {
		return idusuario;
	}

	public void setId(int idusuario) {
		this.idusuario = idusuario;
	}

	public List<Hecho> getHecho() {
		return hecho;
	}

	public void setHecho(List<Hecho> hecho) {
		this.hecho = hecho;
	}

	
}
