package com.laboratorio.extra;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Random;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import com.laboratorio.c_lass.Password;

public class EncriptacionPassword {

	private static final Random random = new Random();

	public static Password getHashSalt(String password) throws Exception {

		byte[] salt = new byte[16];
		// generamos salt
		random.nextBytes(salt);
		KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 128);
		try {
			SecretKeyFactory skf = SecretKeyFactory.getInstance("PBEWithHmacSHA256AndAES_128");
			byte[] hash = skf.generateSecret(spec).getEncoded();
			Base64.Encoder enc = Base64.getEncoder();

			return new Password(enc.encodeToString(hash), enc.encodeToString(salt));
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		} catch (InvalidKeySpecException e) {
			System.out.println(e.getMessage());
		}

		throw new Exception("No se pudo crear hash");
	}

	public static boolean verificoPassword(String password, String stringHash, String stringSalt) {
		Base64.Decoder dec = Base64.getDecoder();
		byte[] salt = dec.decode(stringSalt);
		KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 128);

		try {
			SecretKeyFactory skf = SecretKeyFactory.getInstance("PBEWithHmacSHA256AndAES_128");
			byte[] hash = skf.generateSecret(spec).getEncoded();
			Base64.Encoder enc = Base64.getEncoder();
			String currentHash = enc.encodeToString(hash);
			return currentHash.equals(stringHash);
		} catch (NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		} catch (InvalidKeySpecException e) {
			System.out.println(e.getMessage());
		}

		return false;
	}

}
