package com.laboratorio.sb;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.laboratorio.c_lass.Citizen;
import com.laboratorio.c_lass.Donacion;
import com.laboratorio.c_lass.Frase;
import com.laboratorio.c_lass.Hecho;
import com.laboratorio.c_lass.Noticia;
import com.laboratorio.c_lass.Password;
import com.laboratorio.c_lass.Verificacion;
import com.laboratorio.dao.DAO_Citizen;
import com.laboratorio.dao.DAO_Extra;
import com.laboratorio.datatype.DTCitizen;
import com.laboratorio.datatype.DTDonacion;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.datatype.DTVerificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.extra.Constantes;
import com.laboratorio.extra.EncriptacionPassword;
import com.laboratorio.extra.GetOrder;
import com.laboratorio.extra.HechoTop;
import com.laboratorio.extra.Validaciones;

@Stateless
public class SBHechoFO implements SBHechoFOLocal {

	@EJB
	private DAO_Citizen dao;
	@EJB
	private DAO_Extra daoExtra;

	public SBHechoFO() {
	}

	@Override
	public List<DTHecho> listadoHechos(int numero_pagina) {
		List<DTHecho> retorno = new ArrayList<>();
		List<Hecho> lista = dao.listadoHechosFO(numero_pagina);
		for (Hecho var : lista) {
			retorno.add(daoExtra.hechoDTHecho(var));
		}
		return retorno;
	}

	@Override
	public List<DTHecho> busquedaHechos(String nombre) {
		List<DTHecho> retorno = new ArrayList<>();
		for (Hecho var : dao.busquedaHechos(nombre)) {
			retorno.add(daoExtra.hechoDTHecho(var));
		}
		return retorno;
	}

	@Override
	public boolean altaUsuario(DTUsuario usuario) {
		boolean retorno = false;
		try {
			if (!daoExtra.existeUsuario(usuario.getEmail())) {
				try {
					Password password = EncriptacionPassword.getHashSalt(usuario.getPassword());
					DTCitizen dtcitizen = (DTCitizen) usuario;
					Citizen citizen = new Citizen(dtcitizen.getUsername(), dtcitizen.getEmail(), password);
					dao.altaUsuario(citizen);
					retorno = true;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retorno;
	}

	@Override
	public boolean suscripcion(EArea area, DTCitizen citizen) {
		boolean retorno = false;
		try {
			if (daoExtra.existeUsuario(citizen.getEmail())) {
				dao.suscripcion(area, (Citizen) daoExtra.buscarUsuarioEmail(citizen.getEmail()));
				retorno = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retorno;
	}

	@Override
	public boolean realizarDonacion(String ordenid) {
		boolean retorno = false;
		try {
			GetOrder orden=new GetOrder();
			DTDonacion donacion=orden.getOrder(ordenid);
			Donacion dona = new Donacion(donacion.getMonto(), (Citizen) daoExtra.buscarUsuarioEmail(donacion.getDonador()));
			dao.realizarDonacion(dona);
			retorno = true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Ocurrio un error en la donacion");
		}
		return retorno;
	}

	@Override
	public boolean login(String email) {
		boolean retorno = false;
		Constantes con = new Constantes();
		if (daoExtra.existeUsuario(email))
			retorno = daoExtra.verificoPassword(email, con.getPassword());
		return retorno;
	}

	@Override
	public DTUsuario verPerfil(String email_usuario) {
		DTUsuario retorno = null;
		if (daoExtra.existeUsuario(email_usuario))
			retorno = daoExtra.buscarDTUsuarioEmail(email_usuario);
		return retorno;
	}

	@Override
	public List<HechoTop> reporteTopHechoFake() {
		return dao.reporteTopHechoFake();
	}

	@Override
	public List<DTHecho> reporteNoticasPorVeracidad() {
		List<DTHecho> retorno = new ArrayList<>();
		for (Hecho var : dao.reporteNoticasPorVeracidad())
			retorno.add(daoExtra.hechoDTHecho(var));
		return retorno;
	}

	@Override
	public boolean crearHechoVerificar(DTHecho hecho) {
		boolean retorno = false;
		// HAY QUE CONTROLAR QUE EL USUARIO ESTE LOGUEADO
		if (hecho.getImagen() != null) {
			Noticia hecho_noticia = new Noticia(hecho.getTitulo(), hecho.getLink(), hecho.getFecha(),
					hecho.getMedio(), hecho.getEstado(), hecho.getArea(), hecho.getImagen(),
					daoExtra.buscarUsuarioEmail(hecho.getEmailusuario()));
			dao.crearHechoVerificar(hecho_noticia);
			retorno = true;
		} else {
			Frase hecho_frase = new Frase(hecho.getTitulo(), hecho.getLink(), hecho.getFecha(),
					hecho.getMedio(), hecho.getEstado(), hecho.getArea(), hecho.getFrase(), hecho.getAutor(),
					daoExtra.buscarUsuarioEmail(hecho.getEmailusuario()));
			dao.crearHechoVerificar(hecho_frase);
			retorno = true;
		}
		return retorno;
	}

	@Override
	public DTVerificacion obtenerVerificacion(int id_hecho) {
		Verificacion aux = dao.obtenerVerificacion(id_hecho);
		return new DTVerificacion(null, null, null, aux.getJustifiacion(), null, null);
	}

	@Override
	public DTCitizen validacionTokenGoogle(String TokenString) {
		Validaciones validacion = new Validaciones();
		return validacion.validacionTokenGoogle(TokenString);
	}

	@Override
	public DTCitizen validacionTokenGoogleMobile(String TokenString) {
		Validaciones validacion = new Validaciones();
		return validacion.validacionTokenGoogleMobile(TokenString);
	}
}
