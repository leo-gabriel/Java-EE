package com.laboratorio.dao;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.laboratorio.c_lass.Admin;
import com.laboratorio.c_lass.Checker;
import com.laboratorio.c_lass.Citizen;
import com.laboratorio.c_lass.Donacion;
import com.laboratorio.c_lass.Frase;
import com.laboratorio.c_lass.Hecho;
import com.laboratorio.c_lass.Noticia;
import com.laboratorio.c_lass.Password;
import com.laboratorio.c_lass.Submitter;
import com.laboratorio.c_lass.Suscripcion;
import com.laboratorio.c_lass.Usuario;
import com.laboratorio.datatype.DTAdmin;
import com.laboratorio.datatype.DTChecker;
import com.laboratorio.datatype.DTCitizen;
import com.laboratorio.datatype.DTDonacion;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTSubmitter;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.extra.Constantes;
import com.laboratorio.extra.EncriptacionPassword;
import com.laboratorio.extra.EnviarMail;

@Stateless
@LocalBean
public class DAO_Extra {
	
	private Constantes constante=new Constantes();
	
	@PersistenceContext(unitName="PERSISTENCE_CONTEXT_NAME")
	private EntityManager ema;
	
	public DAO_Extra() {}
	
	public void notifiacionEmail(DTHecho hecho) {
		TypedQuery<Suscripcion> query = ema.createQuery("SELECT s FROM Suscripcion s WHERE s.area = :area",
				Suscripcion.class);
		query.setParameter("area", hecho.getArea());
		try {
			Suscripcion suscripcion = query.getSingleResult();
			try {
				List<Citizen> lista = suscripcion.getCitizensuscriptos();
				EnviarMail notificacion = new EnviarMail();
				for (Citizen var : lista) {
					notificacion.apiMailgun(var.getEmail(), var.getUsername(), hecho);
				}
			} catch (Exception e) {
				System.out.println("La suscripcion no tiene ningun Citizen");
			}
		} catch (Exception e) {
			System.out.println("No se pudo obtener la Suscripcion del area: " + hecho.getArea());
		}
	}
	 
	//para paginar una lista de hechos que se pasen
	public List<Hecho>  paginacion(int numero_pagina, TypedQuery<Hecho> query) {
		//constante.cantidad_elementos ES UNA VARIABLE CONSTANTE DEFINIDA EN CONSTANTE
		query.setFirstResult((numero_pagina-1) * constante.getCantidadelementos()); 
		query.setMaxResults(constante.getCantidadelementos());
		return query.getResultList();
	}
	
	
	
	////////////////////////////////////////////////////////////////////////////
	//////////////////////////BUSCAMOS ENTIDADES///////////////////////////////
	///////////////////////////////////////////////////////////////////////////
	public Hecho buscarHecho(int id_hecho) {
		TypedQuery<Hecho>  query= ema.createQuery("SELECT h FROM Hecho h WHERE h.idhecho = :id", Hecho.class);
		query.setParameter("id", id_hecho);
		return query.getSingleResult();
	}
		
	public Usuario buscarUsuario(int id_usuario) {
		TypedQuery<Usuario>  query= ema.createQuery("SELECT u FROM Usuario u WHERE u.idusuario = :id", Usuario.class);
		query.setParameter("id", id_usuario);
		return query.getSingleResult();
	}
	
	public Usuario buscarUsuarioEmail(String email_usuario) {
		TypedQuery<Usuario>  query= ema.createQuery("SELECT u FROM Usuario u WHERE u.email = :id", Usuario.class);
		query.setParameter("id", email_usuario);
		return query.getSingleResult();	
	}
	
	/////////////////////////////////////////////////////////////////////////////
	//////////////////////////BUSCAMOS DT_ENTIDADES/////////////////////////////
	///////////////////////////////////////////////////////////////////////////
	
	public DTUsuario buscarDTUsuarioEmail(String email_usuario) {
		Usuario usuario = buscarUsuarioEmail(email_usuario);
		DTUsuario retorno = null;

		if (usuario.getClass().getSimpleName().equals("Citizen")
				|| usuario.getClass().getSimpleName().equals("com$laboratorio$c_lass$Citizen$pcsubclass")) {

			Citizen citizen = (Citizen) usuario;

			List<DTDonacion> dt_lista_donacion = new ArrayList<>();
			List<DTHecho> dt_lista_hecho = new ArrayList<>();

			for (Donacion var : citizen.getDonaciones()) {
				dt_lista_donacion.add(donacionDTDonacion(var));
			}

			for (Hecho var : citizen.getHecho()) {
				dt_lista_hecho.add(hechoDTHecho(var));
			}

			retorno = new DTCitizen(citizen.getUsername(), citizen.getEmail(),
					citizen.getPassword().getHash() + citizen.getPassword().getSalt(), dt_lista_hecho, dt_lista_donacion);

		} else if (usuario.getClass().getSimpleName().equals("Submitter")
				|| usuario.getClass().getSimpleName().equals("com$laboratorio$c_lass$Submitter$pcsubclass")) {
			Submitter sub = (Submitter) usuario;
			List<DTHecho> dt_lista_hecho = new ArrayList<>();

			for (Hecho var : sub.getHecho()) {
				dt_lista_hecho.add(hechoDTHecho(var));
			}

			retorno = new DTSubmitter(sub.getUsername(), sub.getEmail(),
					sub.getPassword().getHash() + sub.getPassword().getSalt(), dt_lista_hecho, sub.getCi());

		} else if (usuario.getClass().getSimpleName().equals("Checker")
				|| usuario.getClass().getSimpleName().equals("com$laboratorio$c_lass$Checker$pcsubclass")) {
			Checker che = (Checker) usuario;
			List<DTHecho> dt_lista_hecho = new ArrayList<>();

			for (Hecho var : che.getHecho()) {
				dt_lista_hecho.add(hechoDTHecho(var));
			}

			retorno = new DTChecker(che.getUsername(), che.getEmail(),
					che.getPassword().getHash() + che.getPassword().getSalt(), dt_lista_hecho, che.getCi());

		} else if (usuario.getClass().getSimpleName().equals("Admin")
				|| usuario.getClass().getSimpleName().equals("com$laboratorio$c_lass$Admin$pcsubclass")) {
			Admin admi = (Admin) usuario;
			List<DTHecho> dt_lista_hecho = new ArrayList<>();

			for (Hecho var : admi.getHecho()) {
				dt_lista_hecho.add(hechoDTHecho(var));
			}
			retorno = new DTAdmin(admi.getUsername(), admi.getEmail(),
					admi.getPassword().getHash() + admi.getPassword().getSalt(), dt_lista_hecho, admi.getCi());

		}
		return retorno;
	}

	
	/////////////////////////////////////////////////////////////////////////////
	//////////////////////////TRANSFORMAMOS A DT/////////////////////////////
	///////////////////////////////////////////////////////////////////////////
	public DTHecho hechoDTHecho(Hecho hecho) {
		DTHecho retorno;
		if ((hecho.getClass().getSimpleName().equals("Noticia"))
				|| (hecho.getClass().getSimpleName().equals("com$laboratorio$c_lass$Noticia$pcsubclass"))) {
			Noticia noticia = (Noticia) hecho;
			retorno = new DTHecho(noticia.getTitulo(), noticia.getId(), noticia.getLink(), noticia.getFecha(),
					noticia.getMedio(), noticia.getEstado(), noticia.getArea(), noticia.getVeracidad(),
					noticia.getUsuario().getEmail(), null, null, noticia.getImagen());
		} else {
			Frase frase = (Frase) hecho;
			retorno = new DTHecho(frase.getTitulo(), frase.getId(), frase.getLink(), frase.getFecha(), frase.getMedio(),
					frase.getEstado(), frase.getArea(), frase.getVeracidad(), frase.getUsuario().getEmail(),
					frase.getFrase(), frase.getAutor(), null);
		}
		return retorno;
	}
	
	public DTDonacion donacionDTDonacion(Donacion donacion) {
		DTDonacion retorno=new DTDonacion(donacion.getMonto(), donacion.getDonador().getEmail());
		return retorno;
	}
	
	/////////////////////////////////////////////////////////////////////////////
	//////////////////////////////VALIDACIONES//////////////////////////////////
	///////////////////////////////////////////////////////////////////////////
	public boolean existeUsuario(String email_usuario) {
		try{
			buscarUsuarioEmail(email_usuario);
			return true;
		}catch(Exception e) {
			System.out.println("No existe el usuario con el mail: "+email_usuario);
			return false;
		}			
	}
	
	public boolean verificoPassword(String email_usuario, String password) {
		TypedQuery<Usuario> query = ema.createQuery("SELECT u FROM Usuario u WHERE u.email = :id", Usuario.class);
		query.setParameter("id", email_usuario);
		Usuario usuario = query.getSingleResult();
		Password pass = usuario.getPassword();
		return EncriptacionPassword.verificoPassword(password, pass.getHash(), pass.getSalt());
	}
	
	//busco un hecho y verifico si tiene el estado que le paso
	public boolean verificoEstado(int id_hecho, EEstado estado) {
		boolean retorno = false;
		try {
			if (buscarHecho(id_hecho).getEstado().equals(estado))
				retorno = true;
			else
				System.out.println("El estado no es el deseado");
		} catch (Exception e) {
			System.out.println("No existe el hecho");
		}
		return retorno;
	}
	
}
