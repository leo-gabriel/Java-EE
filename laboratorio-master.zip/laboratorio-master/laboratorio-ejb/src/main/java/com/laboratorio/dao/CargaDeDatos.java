package com.laboratorio.dao;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.laboratorio.c_lass.Admin;
import com.laboratorio.c_lass.Checker;
import com.laboratorio.c_lass.Citizen;
import com.laboratorio.c_lass.Frase;
import com.laboratorio.c_lass.Noticia;
import com.laboratorio.c_lass.Password;
import com.laboratorio.c_lass.Submitter;
import com.laboratorio.c_lass.Suscripcion;
import com.laboratorio.c_lass.Verificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.Constantes;
import com.laboratorio.extra.EncriptacionPassword;
import com.laboratorio.extra.FechaToDate;

@Singleton
@Startup
@LocalBean
public class CargaDeDatos {

	@PersistenceContext(unitName = "PERSISTENCE_CONTEXT_NAME")
	private EntityManager ema; 
	
	public CargaDeDatos() {
	}

	// carga datos en nuestra base de datos por defecto
	@PostConstruct
	public void cargaDatos() {
		Constantes con=new Constantes();
		FechaToDate fecha = new FechaToDate();
		Password password1 = null;
		Password password2 = null;
		Password password3 = null;
		Password password4 = null;
		Password password5 = null;
		Password password6 = null;
		Password password7 = null;
		try {
			password1 = EncriptacionPassword.getHashSalt(con.getPassword());
			password2 = EncriptacionPassword.getHashSalt(con.getPassword());
			password3 = EncriptacionPassword.getHashSalt("passwordsubmitter");
			password4 = EncriptacionPassword.getHashSalt("passwordchecker");
			password5 = EncriptacionPassword.getHashSalt("passwordchecker");
			password6 = EncriptacionPassword.getHashSalt("passwordadmin");
			password7 = EncriptacionPassword.getHashSalt(con.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}

		// USUARIOS
		Admin admin = new Admin("admin", "email@admin.com", password6, 12345678);
		ema.persist(admin);

		Citizen citizen = new Citizen("Monica", "monicatecnicopc@gmail.com", password1);
		ema.persist(citizen);
		Citizen citizen2 = new Citizen("Gaston", "gaston.aon.93@gmail.com", password2);
		ema.persist(citizen2);
		Citizen citizen3 = new Citizen("HechosDRAPS", "drapslab2019-buyer@gmail.com", password7);
		ema.persist(citizen3);

		Submitter submitter = new Submitter("Gonzalo", "gonzalodiharce@gmail.com", password3, 12345678);
		ema.persist(submitter);

		Checker checker = new Checker("Bruno", "brunosasso2@gmail.com", password4, 12345678);
		ema.persist(checker);
		Checker checker1 = new Checker("Leonardo", "leogaboperez@gmail.com", password5, 12345678);
		ema.persist(checker1);

		// HECHOS
		Noticia noticia = new Noticia("Se comienza a construir nuevo hospital ", "https://www.elpais.com.uy/",
				fecha.fechaSistema(), "Diario Virtual", EEstado.NUEVO, EArea.SALUD, "imagen.jpg", citizen);
		ema.persist(noticia);
		Noticia noticia1 = new Noticia("Datos y curiosidades de los politicos",
				"https://www.elpais.com.uy/multimedia/informes-especiales/datos-curiosidades-politicos-quieren-acceder-sillon-presidencial.html",
				fecha.fechaSistema(), "Diario Virtual", EEstado.NUEVO, EArea.POLITICA, "imagen.jpg", citizen);
		ema.persist(noticia1);
		Noticia noticia2 = new Noticia(
				"La tarjeta de Sartori: ¿qué tan viable es dar medicamentos gratis a los jubilados?",
				"https://www.elpais.com.uy/multimedia/informes-especiales/datos-curiosidades-politicos-quieren-acceder-sillon-presidencial.html",
				fecha.fechaSistema(), "Diario Virtual", EEstado.NUEVO, EArea.POLITICA, "imagen.jpg", citizen);
		ema.persist(noticia2);

		Frase frase = new Frase("La elección no está definida hasta el día que se cuenten los votos",
				"https://www.elpais.com.uy/que-pasa/tarjeta-sartori-viable-dar-medicamentos-gratis-jubilados.html",
				fecha.fechaSistema(), "Diario Virtual", EEstado.NUEVO, EArea.POLITICA,
				"La elección no está definida hasta el día que se cuenten los votos", "Lacalle Pou", submitter);
		ema.persist(frase);

		Frase frase1 = new Frase("El más picante del condado",
				"https://www.montevideo.com.uy/Noticias/Sanguinetti--El-FA-deja-un-pais-hipotecado-y-con-fracasos-en-seguridad-y-educacion--uc722063",
				fecha.fechaSistema(), "Portal de Montevideo", EEstado.NUEVO, EArea.POLITICA,
				"El FA deja un país hipotecado y con fracasos en seguridad y educación", "Sanguinetti", citizen);
		ema.persist(frase1);

		// HECHOS CON ESTADO PUBLICADOS PARA PODER VISUALIZAR EN EL FRONTOFFICE Y EL
		// MOBILE
		Noticia noticia3 = new Noticia("Diez precandidatos a la Presidencia y siete preguntas iguales",
				"https://www.elpais.com.uy/informacion/politica/diez-precandidatos-presidencia-siete-preguntas-iguales.html",
				fecha.fechaSistema(), "Diario Virtual", EEstado.PUBLICADO, EArea.POLITICA, "imagen.jpg", submitter);
		noticia3.setVeracidad(EVeracidad.ENGANIOSA);
		ema.persist(noticia3);

		Noticia noticia4 = new Noticia(
				"Lacalle Pou va a “esperar a que sugieran nombres” para la fórmula si gana la interna",
				"https://www.elpais.com.uy/informacion/politica/gana-interna-lacalle-pou-esperar-sugieran-nombres-formula.html",
				fecha.fechaSistema(), "Diario Virtual", EEstado.PUBLICADO, EArea.POLITICA, "imagen.jpg", submitter);
		noticia4.setVeracidad(EVeracidad.VERDADERA);
		ema.persist(noticia4);

		Noticia noticia5 = new Noticia("Sartori: 4.000 autos de voluntarios para llevar a los votantes",
				"https://www.elpais.com.uy/informacion/politica/sartori-autos-voluntarios-llevar-votantes.html",
				fecha.fechaSistema(), "Diario Virtual", EEstado.PUBLICADO, EArea.POLITICA, "imagen.jpg", submitter);
		noticia5.setVeracidad(EVeracidad.VERDAD_A_MEDIAS);
		ema.persist(noticia5);

		Frase frase2 = new Frase(
				"Martínez y una carta a los militantes: “Lo que está en juego es la vigencia de los logros\"",
				"https://www.montevideo.com.uy/Noticias/Martinez-y-una-carta-a-los-militantes--Lo-que-esta-en-juego-es-la-vigencia-de-los-logros--uc722560",
				fecha.fechaSistema(), "Portal de Montevideo", EEstado.PUBLICADO, EArea.POLITICA,
				"Lo que está en juego es la vigencia de los logros", "Daniel Martínez", submitter);
		frase2.setVeracidad(EVeracidad.RIDICULA);
		ema.persist(frase2);

		Frase frase3 = new Frase("Lacalle Pou: Vamos rumbo a un gobierno multicolor",
				"http://www.lr21.com.uy/politica/1404091-luis-lacalle-pou-acto-elecciones-internas-presidencia",
				fecha.fechaSistema(), "Web", EEstado.PUBLICADO, EArea.POLITICA, "Vamos rumbo a un gobierno multicolor",
				"Lacalle Pou", submitter);
		frase3.setVeracidad(EVeracidad.INFLADA);
		ema.persist(frase3);
		
		//JUSTIFICACION
		
		Verificacion verificacion1=new Verificacion(fecha.fechaSistema(), noticia3, checker);
		verificacion1.setFechafin(fecha.fechaSistema());
		verificacion1.setCalifiacion(noticia3.getVeracidad());
		verificacion1.setJustifiacion("No se encontró información en el link proporcionado.");
		ema.persist(verificacion1);
		
		Verificacion verificacion2=new Verificacion(fecha.fechaSistema(), noticia4, checker);
		verificacion2.setFechafin(fecha.fechaSistema());
		verificacion2.setCalifiacion(noticia4.getVeracidad());
		verificacion2.setJustifiacion("Se corroboro en varias paginas la noticia, los sitios son de carácter serio y publican información previamente justificada.");
		ema.persist(verificacion2);
		
		Verificacion verificacion3=new Verificacion(fecha.fechaSistema(), noticia5, checker1);
		verificacion3.setFechafin(fecha.fechaSistema());
		verificacion3.setCalifiacion(noticia5.getVeracidad());
		verificacion3.setJustifiacion("No se encontró información clara de la noticia.");
		ema.persist(verificacion3);
		
		Verificacion verificacion4=new Verificacion(fecha.fechaSistema(), frase2, checker1);
		verificacion4.setFechafin(fecha.fechaSistema());
		verificacion4.setCalifiacion(frase2.getVeracidad());
		verificacion4.setJustifiacion("La frase es incoherente, no tiene fundamentos, se investigo en varios portales.");
		ema.persist(verificacion4);
		
		Verificacion verificacion5=new Verificacion(fecha.fechaSistema(), frase3, checker);
		verificacion5.setFechafin(fecha.fechaSistema());
		verificacion5.setCalifiacion(frase3.getVeracidad());
		verificacion5.setJustifiacion("Frase muy sobre valorada.");
		ema.persist(verificacion5);
		
		// SUSCRIPCIONES
		Suscripcion suscripcion = new Suscripcion(EArea.ECONOMIA);
		suscripcion.setCitizensuscriptos(citizen);
		suscripcion.setCitizensuscriptos(citizen2);
		ema.persist(suscripcion);

		Suscripcion suscripcion1 = new Suscripcion(EArea.POLITICA);
		suscripcion1.setCitizensuscriptos(citizen);
		suscripcion1.setCitizensuscriptos(citizen2);
		ema.persist(suscripcion1);

		Suscripcion suscripcion2 = new Suscripcion(EArea.SALUD);
		suscripcion2.setCitizensuscriptos(citizen);
		suscripcion2.setCitizensuscriptos(citizen2);
		ema.persist(suscripcion2);
	}
}
