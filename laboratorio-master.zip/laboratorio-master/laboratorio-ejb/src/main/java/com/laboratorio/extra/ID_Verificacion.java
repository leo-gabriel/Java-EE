package com.laboratorio.extra;

import java.io.Serializable;

import javax.persistence.Embeddable;

@SuppressWarnings("serial")
@Embeddable
public class ID_Verificacion implements Serializable {
	
	private int hechoid;
	private int checkerid;
	
	public ID_Verificacion() {}

	public ID_Verificacion(int hecho_id, int checker_id) {
		this.hechoid=hecho_id;
		this.checkerid=checker_id;
	}
		
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + checkerid;
		result = prime * result + hechoid;
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ID_Verificacion other = (ID_Verificacion) obj;
		if (checkerid != other.checkerid)
			return false;
		if (hechoid != other.hechoid)
			return false;
		return true;
	}
		
		
}

