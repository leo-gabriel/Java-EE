package com.laboratorio.c_lass;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.laboratorio.e_num.EArea;

@Entity
@Table(name="suscripcion")
public class Suscripcion { 

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idsuscripcion;
	private EArea area;
	@ManyToMany
	@JoinTable(name="SUSCRIPCION_CITIZEN", 
		joinColumns=@JoinColumn(name="suscripcion_id"),
		inverseJoinColumns=@JoinColumn(name="citizen_id"))
	private List<Citizen> citizensuscriptos=new ArrayList<>();
	
	
	public Suscripcion() {}


	public Suscripcion(EArea area) {
		this.area = area;		
	}


	public int getId() {
		return idsuscripcion;
	}


	public void setId(int idsuscripcion) {
		this.idsuscripcion = idsuscripcion;
	}


	public EArea getArea() {
		return area;
	}


	public void setArea(EArea area) {
		this.area = area;
	}


	public List<Citizen> getCitizensuscriptos() {
		return citizensuscriptos;
	}


	public void setCitizensuscriptos(Citizen citizen) {
		this.citizensuscriptos.add(citizen);
	}	
}
