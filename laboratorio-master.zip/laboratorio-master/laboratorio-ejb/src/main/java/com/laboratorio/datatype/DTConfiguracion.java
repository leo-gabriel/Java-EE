package com.laboratorio.datatype;

import java.util.List;

public class DTConfiguracion {
	
	private List<DTPeriferico> listaPerifericos;
	private DTPeriferico perifericoHabilitado;
	private Boolean notificaciones;
	private int tiempoMaximoVerificacion;
	
	public DTConfiguracion(List<DTPeriferico> listaPerifericos, Boolean notificaciones, int tiempoMaximoVerificacion, DTPeriferico perifericoHabilitado) {
		super();
		this.listaPerifericos = listaPerifericos;
		this.notificaciones = notificaciones;
		this.tiempoMaximoVerificacion = tiempoMaximoVerificacion;
		this.perifericoHabilitado = perifericoHabilitado;
	}
	public List<DTPeriferico> getListaPerifericos() {
		return listaPerifericos;
	}

	public Boolean getNotificaciones() {
		return notificaciones;
	}

	public int getTiempoMaximoVerificacion() {
		return tiempoMaximoVerificacion;
	}
	
	public DTPeriferico getPerifericoHabilitado() {
		return perifericoHabilitado;
	}
}
