package com.laboratorio.extra;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "periferico")
public class Periferico {
	@Id
	private String nombre;
	private String url; 
	public Periferico() {
		super();
	}
	public Periferico(String nombre, String url) {
		super();
		this.nombre = nombre;
		this.url = url;
	}
	public String getNombre() {
		return nombre;
	}
	
	public String getUrl() {
		return url;
	}
}
