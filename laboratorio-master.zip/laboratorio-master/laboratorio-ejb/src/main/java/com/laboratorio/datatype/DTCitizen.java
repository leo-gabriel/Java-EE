package com.laboratorio.datatype;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DTCitizen extends DTUsuario implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private List<DTDonacion> donaciones=new ArrayList<>();
	public DTCitizen() {
		super();
	}
	public DTCitizen(String user_name, String email, String password, List<DTHecho> hechos, List<DTDonacion> donaciones) {
		super(user_name, email, password, hechos);
		this.donaciones=donaciones;
	}
	
	public List<DTDonacion> getDonaciones() {
		return donaciones;
	}
	public void setDonaciones(List<DTDonacion> donaciones) {
		this.donaciones = donaciones;
	}
}
