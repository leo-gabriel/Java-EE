package com.laboratorio.datatype;

import java.io.Serializable;
import java.util.List;

public class DTSubmitter extends DTUsuario implements Serializable  {
	private static final long serialVersionUID = 1L;
	
	private int cisub;

	public DTSubmitter() {
		super();
	}

	public DTSubmitter(String user_name, String email, String password, List<DTHecho> hechos, int cisub) {
		super(user_name, email, password, hechos);
		this.cisub=cisub;
	}

	public int getCi() {
		return cisub;
	}

	public void setCi(int cisub) {
		this.cisub = cisub;
	}
	
	
}
