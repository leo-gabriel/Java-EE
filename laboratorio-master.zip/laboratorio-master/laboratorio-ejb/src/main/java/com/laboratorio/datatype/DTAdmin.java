package com.laboratorio.datatype;

import java.io.Serializable;
import java.util.List;

public class DTAdmin extends DTUsuario implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int ciadmi;

	public DTAdmin() {
		super();
	}

	public DTAdmin(String user_name, String email, String password, List<DTHecho> hechos, int ciadmi) {
		super(user_name, email, password, hechos);
		this.ciadmi=ciadmi;
	}

	public int getCi() {
		return ciadmi;
	}

	public void setCi(int ciadmi) {
		this.ciadmi = ciadmi;
	}
	
	
}
