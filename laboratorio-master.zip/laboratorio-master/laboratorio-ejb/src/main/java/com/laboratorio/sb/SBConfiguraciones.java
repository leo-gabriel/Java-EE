package com.laboratorio.sb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.laboratorio.datatype.DTConfiguracion;
import com.laboratorio.datatype.DTPeriferico;
import com.laboratorio.extra.Configuracion;
import com.laboratorio.extra.Periferico;

@Singleton
@Startup
@LocalBean
public class SBConfiguraciones implements SBConfiguracionesLocal {

	private Configuracion configuracion;

	@PersistenceContext(unitName = "PERSISTENCE_CONTEXT_NAME")
	private EntityManager ema;

	public SBConfiguraciones() {
	}

	@PostConstruct
	public void initialize() {

		configuracion = ema.find(Configuracion.class, 0);
		if (configuracion == null) {
			Periferico periferico1 = new Periferico("Openshift",
					"http://perifericoexterno-perifericoexterno.b9ad.pro-us-east-1.openshiftapps.com/PerifericoExterno-web/Soap?wsdl");
			configuracion = new Configuracion(0, true, 5, periferico1);
			configuracion.getListaPerifericos().add(periferico1);
			ema.persist(periferico1);
			ema.persist(configuracion);
		}
	}

	@Override
	public DTConfiguracion getConfiguracion() {
		configuracion = ema.find(Configuracion.class, 0);
		List<DTPeriferico> listaDtPeriferico = new ArrayList<>();
		for (Periferico periferico : configuracion.getListaPerifericos())
			listaDtPeriferico.add(new DTPeriferico(periferico.getNombre(), periferico.getUrl()));
		DTPeriferico perifericoHabilitado = new DTPeriferico(configuracion.getPerifericoHabilitado().getNombre(),
				configuracion.getPerifericoHabilitado().getUrl());
		return new DTConfiguracion(listaDtPeriferico, configuracion.getNotificaciones(),
				configuracion.getTiempoMaximoVerificacion(), perifericoHabilitado);
	}

	@Override
	public Boolean crearPeriferico(DTPeriferico dtp) {
		configuracion = ema.find(Configuracion.class, 0);
		if (ema.find(Periferico.class, dtp.getNombre()) == null) {
			Periferico periferico = new Periferico(dtp.getNombre(), dtp.getUrl());
			configuracion.getListaPerifericos().add(periferico);
			ema.persist(periferico);
			return true;
		} else
			return false;
	}

	@Override
	public void habilitarPeriferico(DTPeriferico dtp) {
		Periferico periferico = ema.find(Periferico.class, dtp.getNombre());
		configuracion = ema.find(Configuracion.class, 0);
		configuracion.setPerifericoHabilitado(periferico);
		ema.refresh(periferico);
	}

	@Override
	public void hdNotificaciones(Boolean notificaciones) {
		Configuracion con = ema.find(Configuracion.class, 0);
		con.setNotificaciones(notificaciones);
		ema.refresh(con);
	}

	public void setTiempoMaximo(int tiempoMaximoVerificacion) {
		Configuracion con = ema.find(Configuracion.class, 0);
		con.setTiempoMaximoVerificacion(tiempoMaximoVerificacion);
		ema.refresh(con);
	}
}
