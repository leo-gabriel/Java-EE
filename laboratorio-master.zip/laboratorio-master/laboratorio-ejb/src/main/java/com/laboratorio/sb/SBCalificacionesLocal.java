package com.laboratorio.sb;

import java.util.List;

import javax.ejb.Local;

import com.laboratorio.datatype.DTCalificacion;

@Local
public interface SBCalificacionesLocal {

	public DTCalificacion listarCalificacionesHecho(int idcali);
	public boolean eliminarCalificacion(int idhecho);
	public boolean recibirCalificacionExterna(DTCalificacion calificacion);

}
