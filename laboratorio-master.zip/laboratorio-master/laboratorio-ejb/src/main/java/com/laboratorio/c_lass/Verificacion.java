package com.laboratorio.c_lass;

import java.util.Date;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.ID_Verificacion;

@Entity
@Table(name="verificacion")
public class Verificacion {
	 
	@EmbeddedId
	private ID_Verificacion idv;
	@Temporal(javax.persistence.TemporalType.DATE)
	private Date fechainicio;
	@Temporal(javax.persistence.TemporalType.DATE)
	private Date fechafin;
	private EVeracidad veracidad; 
	private String justifiacion;
	@ManyToOne
	@JoinColumn(name="hechoid", insertable=false, updatable=false)
	private Hecho hecho;
	@ManyToOne
	@JoinColumn(name="checkerid", insertable=false, updatable=false)
	private Checker checker;
	
	public ID_Verificacion getIdv() {
		return idv;
	}

	public Hecho getHecho() {
		return hecho;
	}

	public Checker getChecker() {
		return checker;
	}

	public Verificacion() {}
	
	public Verificacion(Date fecha_inicio, Hecho hecho, Checker checker) {
		this.fechainicio = fecha_inicio;
		this.hecho = hecho;
		this.checker = checker;
		
		idv=new ID_Verificacion(hecho.getId(), checker.getId());
		
	}

	public Date getFechainicio() {
		return fechainicio;
	}

	public void setFechainicio(Date fecha_inicio) {
		this.fechainicio = fecha_inicio;
	}

	public Date getFechafin() {
		return fechafin;
	}

	public void setFechafin(Date fecha_fin) {
		this.fechafin = fecha_fin;
	}

	public EVeracidad getCalifiacion() {
		return veracidad;
	}

	public void setCalifiacion(EVeracidad califiacion) {
		this.veracidad = califiacion;
	}

	public String getJustifiacion() {
		return justifiacion;
	}

	public void setJustifiacion(String justifiacion) {
		this.justifiacion = justifiacion;
	}
}
