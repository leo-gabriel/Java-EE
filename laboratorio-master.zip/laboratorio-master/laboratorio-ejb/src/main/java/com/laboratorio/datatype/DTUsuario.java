package com.laboratorio.datatype;

import java.io.Serializable;
import java.util.List;

public class DTUsuario implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String username;
	private String email;
	private String password;
	private List<DTHecho> hechos;
	
	public DTUsuario() {}
	
	public DTUsuario(String user_name, String email, String password, List<DTHecho> hechos) {
		this.username = user_name;
		this.email = email;
		this.password = password;
		this.hechos = hechos;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String user_name) {
		this.username = user_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<DTHecho> getHechos() {
		return hechos;
	}

	public void setHechos(List<DTHecho> hechos) {
		this.hechos = hechos;
	}
	
	
	

}
