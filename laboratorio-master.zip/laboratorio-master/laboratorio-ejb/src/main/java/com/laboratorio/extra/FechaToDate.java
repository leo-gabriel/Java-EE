package com.laboratorio.extra;

import java.util.Calendar;
import java.util.Date;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class FechaToDate {
	 
public FechaToDate() {}
	
	public Date stringDate(String strFecha) {
		DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd");  
        DateTime dtime= fmt.parseDateTime(strFecha);  
        return dtime.toDate();
    }
    
    public String verFecha(Date fecha){
    	DateTimeFormatter fmt = DateTimeFormat.forPattern("dd-MM-yyyy");  
    	DateTime dtime=new DateTime(fecha);
    	DateTime dt1=fmt.parseDateTime(dtime.getDayOfMonth()+"-"+dtime.getMonthOfYear()+"-"+dtime.getYear());
    	return fmt.print(dt1);  
    }
    
    public Date fechaSistema() {
    	DateTime dtime= new DateTime(); 
    	return stringDate(dtime.getYear()+"-"+dtime.getMonthOfYear()+"-"+dtime.getDayOfMonth());
    }
    
    public Date restarDiasFecha(Date fecha, int dias){
    	Calendar calendar = Calendar.getInstance();
    	calendar.setTime(fecha); // Configuramos la fecha que se recibe
    	calendar.add(Calendar.DAY_OF_YEAR, -dias);  // numero de días a añadir, o restar en caso de días<0
    	return calendar.getTime(); // Devuelve el objeto Date con los nuevos días añadidos
    }
}
