package com.laboratorio.c_lass;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
@DiscriminatorValue(value = "CITIZEN")
public class Citizen extends Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@OneToMany(mappedBy = "donador")
	private List<Donacion> donaciones = new ArrayList<>();

	public Citizen() {
		super();
	}

	public Citizen(String user_name, String email, Password password) {
		super(user_name, email, password);
	}

	public List<Donacion> getDonaciones() {
		return donaciones;
	}

	public void setDonaciones(List<Donacion> donaciones) {
		this.donaciones = donaciones;
	}
}
