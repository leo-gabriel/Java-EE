package com.laboratorio.c_lass;



import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue( value="CHECKER" )
public class Checker extends Usuario implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int ciusuario;

	public Checker() {
		super();
	}

	public Checker(String user_name, String email, Password password, int ciusuario) {
		super(user_name, email, password);
		this.ciusuario=ciusuario;
	}

	public int getCi() {
		return ciusuario; 
	}

	public void setCi(int ciusuario) {
		this.ciusuario = ciusuario;
	}

}
