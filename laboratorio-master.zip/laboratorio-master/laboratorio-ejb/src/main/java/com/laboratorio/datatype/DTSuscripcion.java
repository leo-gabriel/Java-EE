package com.laboratorio.datatype;

import java.util.ArrayList;
import java.util.List;

import com.laboratorio.e_num.EArea;

public class DTSuscripcion {
	
	private EArea area;
	private List<DTUsuario> citizensuscriptos;
	
	public DTSuscripcion() {}
	
	public DTSuscripcion(EArea area, List<DTUsuario> citizen_suscriptos) {
		this.area = area;
		this.citizensuscriptos = new ArrayList<>();
		this.citizensuscriptos.addAll(citizen_suscriptos);
	}

	public EArea getArea() {
		return area;
	}

	public void setArea(EArea area) {
		this.area = area;
	}

	public List<DTUsuario> getCitizensuscriptos() {
		return citizensuscriptos;
	}

	public void setCitizensuscriptos(List<DTUsuario> citizen_suscriptos) {
		this.citizensuscriptos = citizen_suscriptos;
	}
	
	
}
