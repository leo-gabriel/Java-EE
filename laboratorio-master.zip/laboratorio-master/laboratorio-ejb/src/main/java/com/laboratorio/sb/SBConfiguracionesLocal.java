package com.laboratorio.sb;

import javax.ejb.Local;

import com.laboratorio.datatype.DTConfiguracion;
import com.laboratorio.datatype.DTPeriferico;

@Local
public interface SBConfiguracionesLocal {

	DTConfiguracion getConfiguracion();
	Boolean crearPeriferico(DTPeriferico dtp);
	void hdNotificaciones(Boolean notificaciones);
	public void setTiempoMaximo(int tiempoMaximoVerificacion);
	void habilitarPeriferico(DTPeriferico dtp);

}
