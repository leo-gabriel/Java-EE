package com.laboratorio.e_num;

public enum EArea {

	POLITICA, SALUD, ECONOMIA;


}
