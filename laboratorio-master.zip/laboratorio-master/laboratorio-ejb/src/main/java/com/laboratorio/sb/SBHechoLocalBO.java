package com.laboratorio.sb;

import java.util.List;

import javax.ejb.Local;

import com.laboratorio.datatype.DTCalificacion;
import com.laboratorio.datatype.DTChecker;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.datatype.DTVerificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;

@Local
public interface SBHechoLocalBO {
	
	
	public List<DTHecho> listadoDeHechos(EEstado estado, String tipo, String emailusuario, EVeracidad veracidad, EArea area);
	public boolean crearHechoVerificar(DTHecho hecho);
	public boolean seleccionarHechoVerificar(DTHecho hecho);
	public boolean asignarHechoVerificar(DTHecho hecho, DTUsuario usuario);
	public boolean tomarHechoVerificar(DTHecho hecho);
	public boolean verificarHecho(DTHecho hecho, EVeracidad veracidad, String justificacion);
	public boolean publicarHecho(DTHecho hecho, DTUsuario usuario);
	public boolean cancelarHecho(DTHecho hecho, DTUsuario usuario);
	public boolean altaUsuario(DTUsuario usuario);
	public DTUsuario login(String email, String password);
	public List<DTChecker> listadoChecker();
	public DTHecho getHecho(int idhecho);
	public boolean recibirCalificacionExterna(DTCalificacion calificacion);
	public DTVerificacion obtenerVerificacion(String email_usuario, int id_hecho );
	//FUNCION PARA VALIDAR TOKEN
	public boolean validacionToken(String jwt);
}
