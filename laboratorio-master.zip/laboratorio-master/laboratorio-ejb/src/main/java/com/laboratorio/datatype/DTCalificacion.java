package com.laboratorio.datatype;

import com.laboratorio.e_num.EVeracidad;

public class DTCalificacion {
	
	private int idHecho;
	private EVeracidad veracidad;
	private String justificacion;
	
	
	public DTCalificacion() {}
	
	public DTCalificacion(int idHecho, EVeracidad veracidad, String justificacion) {
		this.idHecho=idHecho;
		this.veracidad = veracidad;
		this.justificacion = justificacion;
	}
	public int getIdHecho() {
		return idHecho;
	}
	public void setIdHecho(int idHecho) {
		this.idHecho = idHecho;
	}
	public EVeracidad getVeracidad() {
		return veracidad;
	}
	public void setVeracidad(EVeracidad veracidad) {
		this.veracidad = veracidad;
	}
	public String getJustificacion() {
		return justificacion;
	}
	public void setJustificacion(String justificacion) {
		this.justificacion = justificacion;
	}
}
