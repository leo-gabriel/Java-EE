package com.laboratorio.c_lass;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;

@Entity
@Table(name = "hecho")  
@Inheritance( strategy = InheritanceType.SINGLE_TABLE )
@DiscriminatorColumn( name="tipo" )
public class Hecho implements Serializable{
	private static final long serialVersionUID = 1L;
 
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idhecho; 
	private String titulo;
	//COLOCAMOS ESTE ATRIBUTO PARA PODER ACCEDER AL @DiscriminatorColumn
	@Column(name="tipo", insertable = false, updatable = false)
	private String tipo;
	public String getTipo() {
		return tipo;
	}

	private String link;
	@Temporal(javax.persistence.TemporalType.DATE)
	private Date fecha;
	private String medio;
	private EVeracidad veracidad;
	private EEstado estado;
	private EArea area;
	@ManyToOne 
	private Usuario usuario; 
	 
	public Hecho() {} 

	public Hecho(String titulo, String link, Date fecha, String medio, EEstado estado, EArea area, Usuario usuario) {
		this.titulo = titulo;
		this.link = link;
		this.fecha = fecha; 
		this.medio = medio;
		//dato por default cuando se crea el hecho
		this.veracidad = EVeracidad.VERACIDAD;
		this.estado = estado;
		this.area = area;
		this.usuario=usuario;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public int getId() {
		return idhecho;
	}

	public void setId(int hecho) {
		this.idhecho = hecho;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
 
	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getMedio() {
		return medio;
	}

	public void setMedio(String medio) {
		this.medio = medio;
	}

	public EVeracidad getVeracidad() {
		return veracidad;
	}

	public void setVeracidad(EVeracidad veracidad) {
		this.veracidad = veracidad;
	}

	public EEstado getEstado() {
		return estado;
	}

	public void setEstado(EEstado estado) {
		this.estado = estado;
	}

	public EArea getArea() {
		return area;
	}

	public void setArea(EArea area) {
		this.area = area;
	}
	
	

}
