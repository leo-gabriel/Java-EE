package com.laboratorio.datatype;

public class DTDonacion {
	
	private float monto;
	private String emaildonador;
	
	public DTDonacion() {}
	
	public DTDonacion(float monto, String email_donador) {
		this.monto = monto;
		this.emaildonador = email_donador;
	}

	public float getMonto() {
		return monto;
	}

	public void setMonto(float monto) {
		this.monto = monto;
	}

	public String getDonador() {
		return emaildonador;
	}

	public void setDonador(String email_donador) {
		this.emaildonador = email_donador;
	}
	
	
}
