package com.laboratorio.extra;

import java.util.List;

import com.laboratorio.c_lass.Hecho;

public class HechoTop {

	private Hecho hecho;
	private int cantidad;

	public HechoTop() {
	}

	public HechoTop(Hecho hecho, int cantidad) {
		this.hecho = hecho;
		this.cantidad = cantidad;
	}

	public Hecho getHecho() {
		return hecho;
	}

	public int getCantidad() {
		return cantidad;
	}

	// CONTAMOS CUANTAS VECES EL HECHO SE REPITE EN UNA LISTA DE HECHOS, SIN
	// CONTARSE A EL MISMO
	public HechoTop contartop(List<Hecho> listahechos, Hecho hecho) {
		int cantidad = 0;
		SimilitudHechos shecho = new SimilitudHechos();
		for (Hecho var : listahechos) {
			shecho.setWords(hecho.getTitulo(), var.getTitulo());
			if (var.getId() != hecho.getId() && shecho.getAfinidad())
				cantidad++;
		}
		HechoTop retorno = new HechoTop(hecho, cantidad);
		return retorno;
	}

}
