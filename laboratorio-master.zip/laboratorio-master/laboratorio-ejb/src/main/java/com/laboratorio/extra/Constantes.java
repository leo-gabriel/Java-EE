package com.laboratorio.extra;

public final class Constantes {

	//NUMERO PARA LA PAGINACION
	private final int cantidadelementos=20;
	
	//DIAS PARA RESTAR EN EL DAO_Extra.TophechosFake
	private final int numerodias=7;
	
	//CLAVE PARA EL TOKEN
	private final String clavetoken="HechosDRAPS";
	
	//PASSWORD POR DEFECTO PARA CITIZEN
	private final String password="passwordcitizen";
	
	//TOKEN DE GOOGLE NO VALIDO, EXPIRADO, SOLO PARA PROBAR LA VERIFICACION DE UN TOKEN NO VALIDO
	private final String tokengoogle="eyJhbGciOiJSUzI1NiIsImtpZCI6IjY4NjQyODlmZmE1MWU0ZTE3ZjE0ZWRmYWFmNTEzMGRmNDBkODllN2QiLCJ0eXAiOiJKV1QifQ."
			+ "eyJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiYXpwIjoiNzMwNDQ1MzA0OTc4LTNxdnJvb3VzN2tsbjZzanJlaWwxZmxwZTFqY2o0MjdpLmFwcHMuZ29"
			+ "vZ2xldXNlcmNvbnRlbnQuY29tIiwiYXVkIjoiNzMwNDQ1MzA0OTc4LTNxdnJvb3VzN2tsbjZzanJlaWwxZmxwZTFqY2o0MjdpLmFwcHMuZ29vZ2xldXNlcm"
			+ "NvbnRlbnQuY29tIiwic3ViIjoiMTA1Nzk3MzY2MTAyNTMwNTIyMjg5IiwiZW1haWwiOiJnYXN0b24uYW9uLjkzQGdtYWlsLmNvbSIsImVtYWlsX3Zlcmlma"
			+ "WVkIjp0cnVlLCJhdF9oYXNoIjoibnI0clBDaXdZX2ttREwyMmNqYy1UZyIsIm5hbWUiOiJHYXN0b24gQcOxb24iLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDYu"
			+ "Z29vZ2xldXNlcmNvbnRlbnQuY29tLy1NX1hTYjR4TXg5QS9BQUFBQUFBQUFBSS9BQUFBQUFBQUFBQS9BQ0hpM3JkOGtTN3ZHR2NTMTR3VVpEOVI0al8xOHo"
			+ "1Z1lRL3M5Ni1jL3Bob3RvLmpwZyIsImdpdmVuX25hbWUiOiJHYXN0b24iLCJmYW1pbHlfbmFtZSI6IkHDsW9uIiwibG9jYWxlIjoiZXMtNDE5IiwiaWF0Ij"
			+ "oxNTYwODE5ODY2LCJleHAiOjE1NjA4MjM0NjYsImp0aSI6ImI5NTQzYTJjODEyYjgxOTRhNGNjNTViNGM5ZmQzNjE1ZTIxOTdiNTUifQ.qIOncEbT5eensZ"
			+ "ePymM6YwHJ7jUssA4XEUnNZgpOCL6vuCqWu-qiIWY_XplYD5Di162iLKzz6GJjAFE8xIdREYO0OhPJ_FE02LGSF4c6dsv3AOOMZGTNVD5zF7qaZxMfJH2k0"
			+ "G2WCPcyOPYn3QKGl4bfHMkpdh1wfTfZWpdoWfRat3Q3tFRxmI1pZ5MUYQMLK-n9liKA-pR_9M-bw7JVjJ8u3Sc6LxZ8KCx9iEeCzI9XvAvM_mn7Nzuq-Y5R"
			+ "JHA9lg-n8ZT-iFjrzqdepg2L5hvYY3Of1f2fGBhS3HWBUw-xi0Xex3l73q62_lrxLGGyrg5lXVeY7_rOK3rnaLMCcw";
	
	private final String clientId = "AQLAgBgj_rzNuYH6mWJAq006SrKSxrrQOJGXCj26ehcSPnUhiBCHxOERQ4zyqQDtM8fjaW4rgOJ2lxGa";
	
	private final String clientSecret = "EE3fqSDHxA3sQRCaY20sZafl-ND-hJTnStCQN9R8pm7SZQPty_vwHn0yn3oRsmqj9vt8FYHf-maip6o7";
	
	public String getClientIdPayPal() {
		return clientId;
	}

	public String getClientSecretPayPal() {
		return clientSecret;
	}

	public Constantes() {}

	public int getCantidadelementos() {
		return cantidadelementos;
	}

	public int getNumerodias() {
		return numerodias;
	}

	public String getClavetoken() {
		return clavetoken;
	}

	public String getPassword() {
		return password;
	}

	public String getTokengoogle() {
		return tokengoogle;
	}
	
	
	
}
