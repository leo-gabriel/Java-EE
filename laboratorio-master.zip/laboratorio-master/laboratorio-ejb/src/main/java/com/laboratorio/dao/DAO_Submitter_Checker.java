package com.laboratorio.dao;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.laboratorio.c_lass.Checker;
import com.laboratorio.c_lass.Hecho;
import com.laboratorio.c_lass.Usuario;
import com.laboratorio.c_lass.Verificacion;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.FechaToDate;

@Stateless
@LocalBean
public class DAO_Submitter_Checker {

	@PersistenceContext(unitName = "PERSISTENCE_CONTEXT_NAME")
	private EntityManager ema;

	@EJB
	private DAO_Extra dao;

	public DAO_Submitter_Checker() {
	}

	/////////////////////////////////////////////////////////////////////
	////////////////////////// FUNCIONES OFICIALES///////////////////////
	///////////////////////////////////////////////////////////////////
	public void altaUsuario(Usuario usuario) {
		ema.persist(usuario);
	}

	public void crearHechoVerificar(Hecho hecho) {
		ema.persist(hecho);
	}

	public void cancelarHecho(int id_hecho, Usuario usuario) {
		Hecho resultado = dao.buscarHecho(id_hecho);
		resultado.setEstado(EEstado.CANCELADO);
		resultado.setUsuario(usuario);
		ema.persist(resultado);
	}

	public void publicarHecho(int id_hecho, Usuario usuario) {
		Hecho resultado = dao.buscarHecho(id_hecho);
		resultado.setEstado(EEstado.PUBLICADO);
		resultado.setUsuario(usuario);
		ema.persist(resultado);
	}

	public void verificarHecho(int id_hecho, EVeracidad veracidad, String justificacion) {
		Hecho resultado = dao.buscarHecho(id_hecho);
		// CAMBIAMOS EL ESTADO DEL HECHO A "VERIFICADO Y LE DAMOS UNA VERACIDAD"
		resultado.setEstado(EEstado.VERIFICADO);
		resultado.setVeracidad(veracidad);
		ema.persist(resultado);
		// BUSCAMOS LA VERIFICACION CORRECTA
		TypedQuery<Verificacion> query1 = ema.createQuery(
				"SELECT v FROM Verificacion v WHERE v.checker.idusuario = :checker_id and v.hecho.idhecho = :hecho_id",
				Verificacion.class);
		query1.setParameter("checker_id", resultado.getUsuario().getId());
		query1.setParameter("hecho_id", resultado.getId());
		Verificacion veri = query1.getSingleResult();
		FechaToDate fecha = new FechaToDate();
		veri.setFechafin(fecha.fechaSistema());
		veri.setCalifiacion(veracidad);
		veri.setJustifiacion(justificacion);
		ema.persist(veri);
	}

	public void tomarHechoVerificar(int id_hecho) {
		Hecho resultado = dao.buscarHecho(id_hecho);
		// CAMBIAMOS EL ESTADO DEL HECHO A "EN_PROCESO"
		resultado.setEstado(EEstado.EN_PROCESO);
		ema.persist(resultado);
		FechaToDate fecha = new FechaToDate();
		// CREAMOS LA INSTANCIA DE LA VERIFICACION, CON LA FECHA, EL HECHO Y EL CHECKER
		// DE LA SESION
		Verificacion verificacion = new Verificacion(fecha.fechaSistema(), resultado, (Checker) resultado.getUsuario());
		ema.persist(verificacion);
	}

	public void asignarHechoVerificar(int id_hecho, Usuario usuario) {
		Hecho resultado = dao.buscarHecho(id_hecho);
		// ASIGNAMOS EL USUARIO CHECKER
		resultado.setUsuario(usuario);
		ema.persist(resultado);
	}

	public void seleccionarHechoVerificar(int id_hecho) {
		Hecho resultado = dao.buscarHecho(id_hecho);
		// CAMBIAMOS EL ESTADO DEL HECHO A "A_COMPROBAR"
		resultado.setEstado(EEstado.A_COMPROBAR);
		ema.persist(resultado);
	}

	public List<Hecho> listadoDeHechos(EEstado estado, String tipo, String emailusuario, EVeracidad veracidad,
			EArea area) {

		TypedQuery<Hecho> query = ema.createQuery(
				"SELECT h FROM Hecho h WHERE h.estado = :estado OR h.tipo = :tipo OR h.usuario = :usuario OR "
						+ "h.veracidad = :veracidad OR h.area = :area",	Hecho.class);
		
		query.setParameter("estado", estado);
		query.setParameter("tipo", tipo);
		query.setParameter("veracidad", veracidad);
		query.setParameter("area", area);
		
		if (emailusuario != null && dao.existeUsuario(emailusuario))
			query.setParameter("usuario", dao.buscarUsuarioEmail(emailusuario));
		else
			query.setParameter("usuario", null);

		if (estado==null && tipo==null && emailusuario==null && veracidad==null && area==null)
			return ema.createQuery("SELECT h FROM Hecho h", Hecho.class).getResultList();
		
		return query.getResultList();
	}

	public List<Usuario> listadoChecker() {
		TypedQuery<Usuario> query = ema.createQuery("SELECT h FROM Usuario h where h.tipo=:CHECKER", Usuario.class);
		query.setParameter("CHECKER", "CHECKER");
		return query.getResultList();
	}

	public List<Hecho> listaHechosEstado(EEstado estado) {
		TypedQuery<Hecho> query = ema.createQuery("SELECT h FROM Hecho h WHERE h.estado = :estado", Hecho.class);
		query.setParameter("estado", estado);
		return query.getResultList();
	}

	public Hecho getHecho(int idhecho) {
		return dao.buscarHecho(idhecho);
	}

	public Verificacion obtenerVerificacion(String email_usuario, int id_hecho) {
		// BUSCAMOS LA VERIFICACION CORRECTA
		TypedQuery<Verificacion> query1 = ema.createQuery(
				"SELECT v FROM Verificacion v WHERE v.checker.idusuario = :checker_id and v.hecho.idhecho = :hecho_id",
				Verificacion.class);
		query1.setParameter("checker_id", dao.buscarUsuarioEmail(email_usuario).getId());
		query1.setParameter("hecho_id", id_hecho);
		return query1.getSingleResult();
	}
}
