package com.laboratorio.datatype;

import java.util.Date;

import com.laboratorio.e_num.EVeracidad;

public class DTVerificacion {
	
	private Date fechainicio;
	private Date fechafin;
	private EVeracidad veracidad;
	private String justifiacion;
	private DTHecho hecho;
	private DTUsuario checker;
	
	public DTVerificacion() {}
	
	public DTVerificacion(Date fecha_inicio, Date fecha_fin, EVeracidad veracidad, String justifiacion, DTHecho hecho,
			DTUsuario checker) {
				this.fechainicio = fecha_inicio;
		this.fechafin = fecha_fin;
		this.veracidad = veracidad;
		this.justifiacion = justifiacion;
		this.hecho = hecho;
		this.checker = checker;
	}

	public Date getFechainicio() {
		return fechainicio;
	}

	public void setFechainicio(Date fecha_inicio) {
		this.fechainicio = fecha_inicio;
	}

	public Date getFechafin() {
		return fechafin;
	}

	public void setFechafin(Date fecha_fin) {
		this.fechafin = fecha_fin;
	}

	public EVeracidad getVeracidad() {
		return veracidad;
	}

	public void setVeracidad(EVeracidad veracidad) {
		this.veracidad = veracidad;
	}

	public String getJustifiacion() {
		return justifiacion;
	}

	public void setJustifiacion(String justifiacion) {
		this.justifiacion = justifiacion;
	}

	public DTHecho getHecho() {
		return hecho;
	}

	public void setHecho(DTHecho hecho) {
		this.hecho = hecho;
	}

	public DTUsuario getChecker() {
		return checker;
	}

	public void setChecker(DTUsuario checker) {
		this.checker = checker;
	}
}
