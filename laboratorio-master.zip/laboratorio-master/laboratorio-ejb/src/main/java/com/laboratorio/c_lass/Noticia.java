package com.laboratorio.c_lass;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;

@Entity
@DiscriminatorValue( value="NOTICIA" )
public class Noticia extends Hecho implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String imagen;

	public Noticia() {}

	public Noticia(String titulo, String link, Date fecha, String medio, EEstado estado, EArea area, String imagen, Usuario usuario) {
		super(titulo, link, fecha, medio, estado, area, usuario);
		this.imagen=imagen;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
	
}
