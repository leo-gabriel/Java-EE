package com.laboratorio.extra;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "configuracion") 
public class Configuracion {  
	@Id 
	private int idconfi;
	@OneToMany 
	private List<Periferico> listaPerifericos = new ArrayList<Periferico>();
	@OneToOne
	private Periferico perifericoHabilitado;
	private Boolean notificaciones;
	private int tiempoMaximoVerificacion;
	public Configuracion() {
		super();
	}
	public Configuracion(int idconfi, Boolean notificaciones, int tiempoMaximoVerificacion, Periferico perifericoHabilitado) {
		super();
		this.idconfi = idconfi;
		this.notificaciones = notificaciones;
		this.tiempoMaximoVerificacion = tiempoMaximoVerificacion;
		this.perifericoHabilitado = perifericoHabilitado;
	}
	public List<Periferico> getListaPerifericos() {
		return listaPerifericos;
	}
	
	public int getIdconfi() {
		return idconfi;
	}
	public Boolean getNotificaciones() {
		return notificaciones;
	}
	public void setNotificaciones(Boolean notificaciones) {
		this.notificaciones = notificaciones;
	}
	public int getTiempoMaximoVerificacion() {
		return tiempoMaximoVerificacion;
	}
	public void setTiempoMaximoVerificacion(int tiempoMaximoVerificacion) {
		this.tiempoMaximoVerificacion = tiempoMaximoVerificacion;
	}
	public Periferico getPerifericoHabilitado() {
		return perifericoHabilitado;
	}
	public void setPerifericoHabilitado(Periferico perifericoHabilitado) {
		this.perifericoHabilitado = perifericoHabilitado;
	}
}
