package com.laboratorio.extra;

import java.io.IOException;

import org.json.JSONObject;

import com.braintreepayments.http.HttpResponse;
import com.braintreepayments.http.serializer.Json;
import com.laboratorio.datatype.DTDonacion;
import com.paypal.orders.Order;
import com.paypal.orders.OrdersGetRequest;

public class GetOrder extends PayPalClient {

	public DTDonacion getOrder(String orderId) throws IOException {
		OrdersGetRequest request = new OrdersGetRequest(orderId);

		HttpResponse<Order> response = client().execute(request);

		System.out.println("Full response body:");
		System.out.println(new JSONObject(new Json().serialize(response.result())).toString(4));

		return new DTDonacion(Float.parseFloat(response.result().purchaseUnits().get(0).amount().value()),
				response.result().payer().emailAddress());
	}

}
