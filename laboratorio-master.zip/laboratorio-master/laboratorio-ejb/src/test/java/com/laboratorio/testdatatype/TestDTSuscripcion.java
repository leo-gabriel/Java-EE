package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTSuscripcion;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.e_num.EArea;

public class TestDTSuscripcion {
	
	private EArea area;
	private List<DTUsuario> citizensuscriptos=new ArrayList<>();
	
	@Before
	public void setUp() {
		area=EArea.ECONOMIA;
		List<DTHecho> hechos =null;
		citizensuscriptos.add(new DTUsuario("user", "email", "password", hechos));
	}

	@Test
	public void dTSuscripcion() {
		DTSuscripcion sus=new DTSuscripcion(area, citizensuscriptos);
		DTSuscripcion compa=new DTSuscripcion();
		
		compa.setArea(area);
		compa.setCitizensuscriptos(citizensuscriptos);
		
		assertTrue(sus.getArea().equals(compa.getArea()));
		assertTrue(sus.getCitizensuscriptos().get(0).getUsername().equals(compa.getCitizensuscriptos().get(0).getUsername()));
		
	}

}
