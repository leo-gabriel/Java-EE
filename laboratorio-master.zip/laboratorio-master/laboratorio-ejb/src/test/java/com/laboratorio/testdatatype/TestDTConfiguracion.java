package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.datatype.DTConfiguracion;
import com.laboratorio.datatype.DTPeriferico;

public class TestDTConfiguracion {

	private List<DTPeriferico> listaPerifericos = new ArrayList<>();
	private Boolean notificaciones;
	private int tiempoMaximoVerificacion;

	@Before
	public void setUpClass() throws Exception {
		listaPerifericos.add(new DTPeriferico("nombre", "url"));
		notificaciones = true;
		tiempoMaximoVerificacion = 1;
	}

	@Test
	public void dTConfiguracion() {
		DTConfiguracion config = new DTConfiguracion(listaPerifericos, notificaciones, tiempoMaximoVerificacion,
				new DTPeriferico("nombre", "url"));

		assertTrue(config.getListaPerifericos().get(0).getNombre().equals("nombre"));
		assertTrue(config.getNotificaciones());
		assertTrue(config.getTiempoMaximoVerificacion() == 1);
		assertTrue(config.getPerifericoHabilitado().getNombre().equals("nombre"));

	}

}
