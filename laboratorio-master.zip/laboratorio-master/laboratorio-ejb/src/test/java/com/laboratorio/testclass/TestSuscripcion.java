package com.laboratorio.testclass;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.c_lass.Citizen;
import com.laboratorio.c_lass.Suscripcion;
import com.laboratorio.e_num.EArea;

public class TestSuscripcion {
	
	private int idsus;
	private EArea area;
	private Citizen citizen;

	@Before
	public void setUpClass() {
		idsus=1;
		area=EArea.ECONOMIA;
		citizen=new Citizen();
		citizen.setUsername("citizen");
	}
	
	@Test
	public void suscripcion() {
		Suscripcion sus=new Suscripcion();
		sus.setId(idsus);
		sus.setArea(area);
		sus.setCitizensuscriptos(citizen);
		
		assertEquals(sus.getId(), idsus);
		assertEquals(sus.getArea(), area);
		assertEquals(sus.getCitizensuscriptos().get(0).getUsername(), "citizen");
	}

}
