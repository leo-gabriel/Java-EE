package com.laboratorio.testdao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.laboratorio.dao.DAO_Extra;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.FechaToDate;
import com.laboratorio.sb.SBHechoFOLocal;

public class TestDAO_Extra {

	private static Context context;

	@BeforeClass
	public static void setUP() throws NamingException {
		Properties props = new Properties();
		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");

		props.put("DefaultDS", "new://Resource?type=DataSource");
		props.put("DefaultDS.JdbcDriver", "org.hsqldb.jdbcDriver");
		props.put("DefaultDS.JdbcUrl", "jdbc:hsqldb:.");

		context = new InitialContext(props);
	}

	/**
	 * Parada del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@AfterClass
	public static void setDOWN() throws NamingException {
		context.close();
	}

	@Test
	public void dAO() throws NamingException {
		DAO_Extra sbean = (DAO_Extra) context.lookup("DAO_ExtraLocalBean");

		assertEquals(sbean.buscarUsuario(2).getId(), 2);

		SBHechoFOLocal sb1 = (SBHechoFOLocal) context.lookup("SBHechoFOLocal");

		FechaToDate fecha = new FechaToDate();

		DTHecho frase = new DTHecho("Frase", 110, "link.frase", fecha.restarDiasFecha(fecha.fechaSistema(), 1),
				"medio.frase", EEstado.NUEVO, EArea.POLITICA, EVeracidad.FALSA, "email_citizen", "frasetexto",
				"autorfrase", null);
		DTHecho frase2 = new DTHecho("Frase", 111, "link.frase", fecha.restarDiasFecha(fecha.fechaSistema(), 1),
				"medio.frase", EEstado.NUEVO, EArea.POLITICA, EVeracidad.FALSA, "email_admin", "frasetexto",
				"autorfrase", null);
		assertTrue(sb1.crearHechoVerificar(frase));
		assertTrue(sb1.crearHechoVerificar(frase2));

		assertEquals(sbean.buscarDTUsuarioEmail("email_citizen").getEmail(), "email_citizen");
		assertEquals(sbean.buscarDTUsuarioEmail("email_subm").getEmail(), "email_subm");
		assertEquals(sbean.buscarDTUsuarioEmail("email_admin").getEmail(), "email_admin");

		assertFalse(sbean.verificoEstado(110, EEstado.A_COMPROBAR));
		assertFalse(sbean.verificoEstado(0, EEstado.A_COMPROBAR));

		sbean.notifiacionEmail(frase);
	}
}
