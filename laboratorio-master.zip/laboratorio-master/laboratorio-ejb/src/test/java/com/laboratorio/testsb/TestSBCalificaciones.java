package com.laboratorio.testsb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.laboratorio.datatype.DTCalificacion;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.sb.SBCalificacionesLocal;

public class TestSBCalificaciones {

	private static Context context;

	@BeforeClass
	public static void setUP() throws NamingException {
		Properties props = new Properties();
		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");

		props.put("DefaultDS", "new://Resource?type=DataSource");
		props.put("DefaultDS.JdbcDriver", "org.hsqldb.jdbcDriver");
		props.put("DefaultDS.JdbcUrl", "jdbc:hsqldb:.");

		context = new InitialContext(props);
	}

	/**
	 * Parada del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@AfterClass
	public static void setDOWN() throws NamingException {
		context.close();
	}

	/**
	 * Invocación a través del interfaz local
	 * 
	 * @throws NamingException
	 */
	@Test
	public void sBCalificaciones() throws NamingException {
		SBCalificacionesLocal sbean = (SBCalificacionesLocal) context.lookup("SBCalificacionesLocalBean");

		assertTrue(sbean.recibirCalificacionExterna(new DTCalificacion(1, EVeracidad.FALSA, "Muy Falsa")));
		assertTrue(
				sbean.recibirCalificacionExterna(new DTCalificacion(2, EVeracidad.VERDAD_A_MEDIAS, "No lo se Rick")));
		assertTrue(sbean.recibirCalificacionExterna(new DTCalificacion(3, EVeracidad.RIDICULA, "Ridicula")));

		assertTrue(sbean.eliminarCalificacion(1));

		//assertEquals(sbean.listarCalificacionesHecho(2).size(), 1);

	}

}
