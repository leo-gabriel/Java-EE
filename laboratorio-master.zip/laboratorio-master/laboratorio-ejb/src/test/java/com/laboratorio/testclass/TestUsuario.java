package com.laboratorio.testclass;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.c_lass.Admin;
import com.laboratorio.c_lass.Checker;
import com.laboratorio.c_lass.Citizen;
import com.laboratorio.c_lass.Donacion;
import com.laboratorio.c_lass.Hecho;
import com.laboratorio.c_lass.Password;
import com.laboratorio.c_lass.Submitter;
import com.laboratorio.extra.EncriptacionPassword;

public class TestUsuario {

	private String username;
	private String email;
	private Password password;
	private int ciusu;
	private int idusu;
	private List<Hecho> hecho = new ArrayList<>();
	private List<Donacion> donaciones = new ArrayList<>();

	@Before
	public void setUpClass() {
		username = "user_name";
		email = "email";
		try {
			password = EncriptacionPassword.getHashSalt("password");
		} catch (Exception e) {
			e.printStackTrace();
		}
		ciusu = 123;
		idusu = 1;
		hecho.add(new Hecho("titulo", null, null, null, null, null, null));
		Donacion don = new Donacion();
		don.setMonto(200);
		don.setDonador(new Citizen());
		donaciones.add(don);
	}

	@Test
	public void usuario() {
		Admin adm = new Admin();
		adm.setUsername(username);
		adm.setEmail(email);
		adm.setPassword(password);
		adm.setId(idusu);
		adm.setHecho(hecho);
		adm.setCi(ciusu);
		Checker che = new Checker();
		che.setCi(ciusu);
		Submitter sub = new Submitter();
		sub.setCi(ciusu);
		Citizen citi = new Citizen();
		citi.setDonaciones(donaciones);

		assertEquals(adm.getUsername(), username);
		assertEquals(adm.getEmail(), email);
		assertTrue(EncriptacionPassword.verificoPassword("password", password.getHash(), password.getSalt()));
		assertEquals(adm.getId(), idusu);
		assertEquals(adm.getHecho().get(0).getTitulo(), "titulo");
		assertEquals(adm.getCi(), ciusu);
		assertEquals(che.getCi(), ciusu);
		assertEquals(sub.getCi(), ciusu);

	}
}
