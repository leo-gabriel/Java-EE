package com.laboratorio.testclass;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.c_lass.Frase;
import com.laboratorio.c_lass.Noticia;
import com.laboratorio.e_num.EArea;
import com.laboratorio.extra.FechaToDate;

public class TestHecho {

	private String titulo;
	private int idhecho;
	private String link;
	private Date fecha;
	private String medio;
	private EArea area;
	private String imagen;
	private String frase;
	private String autor;
	
	@Before
	public void setUpClass() {
		titulo="titulo";
		idhecho=1;
		link="link";
		FechaToDate date=new FechaToDate();
		fecha=date.fechaSistema();
		medio="medio";
		area=EArea.ECONOMIA;
		imagen="imagen";
		frase="frase";
		autor="autor";
		
	}

	@Test
	public void hecho() {
		Noticia not=new Noticia();
		not.setTitulo(titulo);
		not.setId(idhecho);
		not.setLink(link);
		not.setFecha(fecha);
		not.setMedio(medio);
		not.setArea(area);
		not.setImagen(imagen);
		Frase fra=new Frase();
		fra.setAutor(autor);
		fra.setFrase(frase);
		
		assertEquals(not.getTitulo(), titulo);
		assertEquals(not.getId(), idhecho);
		assertEquals(not.getLink(), link);
		FechaToDate fec=new FechaToDate();
		assertEquals(fec.verFecha(not.getFecha()), fec.verFecha(fecha));
		assertEquals(not.getMedio(), medio);
		assertEquals(not.getArea(), area);
		assertEquals(not.getImagen(), imagen);
		assertEquals(fra.getAutor(), autor);
		assertEquals(fra.getFrase(), frase);	
	}

}
