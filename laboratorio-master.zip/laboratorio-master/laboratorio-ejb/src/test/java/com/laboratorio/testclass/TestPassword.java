package com.laboratorio.testclass;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.c_lass.Password;
import com.laboratorio.c_lass.Usuario;

public class TestPassword {

	private int idpas;
	private Usuario usuario;
	private String hash;
	private String salt;

	@Before
	public void setUpClass() {
		idpas = 1;
		usuario = new Usuario();
		usuario.setUsername("username");
		hash = "hash";
		salt = "salt";
	}

	@Test
	public void password() {
		Password pass = new Password();
		pass.setId(idpas);
		pass.setUsuario(usuario);
		pass.setHash(hash);
		pass.setSalt(salt);

		assertEquals(pass.getId(), idpas);
		assertEquals(pass.getUsuario().getUsername(), "username");
		assertEquals(pass.getSalt(), salt);
		assertEquals(pass.getHash(), hash);
	}
}
