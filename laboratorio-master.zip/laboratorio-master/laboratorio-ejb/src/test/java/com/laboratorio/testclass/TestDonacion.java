package com.laboratorio.testclass;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.laboratorio.c_lass.Donacion;

public class TestDonacion {

	@Test
	public void donacion() {
		Donacion donacion = new Donacion();

		assertNotNull(donacion.getIddonacion());
	}

}
