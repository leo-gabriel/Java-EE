package com.laboratorio.testdao;

import static org.junit.Assert.assertNotNull;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.laboratorio.dao.DAO_Submitter_Checker;
import com.laboratorio.e_num.EEstado;

public class TestDAO_Submitter_Checker {

	private static Context context;

	@BeforeClass
	public static void setUP() throws NamingException {
		Properties props = new Properties();
		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");

		props.put("DefaultDS", "new://Resource?type=DataSource");
		props.put("DefaultDS.JdbcDriver", "org.hsqldb.jdbcDriver");
		props.put("DefaultDS.JdbcUrl", "jdbc:hsqldb:.");

		context = new InitialContext(props);
	}

	/**
	 * Parada del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@AfterClass
	public static void setDOWN() throws NamingException {
		context.close();
	}

	@Test
	public void dAO() throws NamingException {
		DAO_Submitter_Checker sbean = (DAO_Submitter_Checker) context.lookup("DAO_Submitter_CheckerLocalBean");

		assertNotNull(sbean.listaHechosEstado(EEstado.NUEVO));

	}

}
