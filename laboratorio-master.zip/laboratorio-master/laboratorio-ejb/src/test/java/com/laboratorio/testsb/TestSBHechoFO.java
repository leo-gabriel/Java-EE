package com.laboratorio.testsb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.laboratorio.datatype.DTCitizen;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.Constantes;
import com.laboratorio.extra.FechaToDate;
import com.laboratorio.sb.SBHechoFOLocal;
import com.laboratorio.sb.SBHechoLocalBO;

public class TestSBHechoFO {

	private static DTCitizen citizen;

	private static Context context;

	/**
	 * Inicialización del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@BeforeClass
	public static void setUP() throws NamingException {
		Properties props = new Properties();
		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");

		props.put("DefaultDS", "new://Resource?type=DataSource");
		props.put("DefaultDS.JdbcDriver", "org.hsqldb.jdbcDriver");
		props.put("DefaultDS.JdbcUrl", "jdbc:hsqldb:.");

		context = new InitialContext(props);

		// CARGAMOS DATOS PARA USUARIOS
		citizen = new DTCitizen("citizen", "email_citizen", "passwordcitizen", null, null);
	}

	/**
	 * Parada del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@AfterClass
	public static void setDOWN() throws NamingException {
		context.close();
	}

	/**
	 * Invocación a través del interfaz local
	 * 
	 * @throws NamingException
	 */
	@Test
	public void sBHechoBO() throws NamingException {
		SBHechoFOLocal sbean = (SBHechoFOLocal) context.lookup("SBHechoFOLocal");
		//DAO_Extra dao = (DAO_Extra) context.lookup("DAO_ExtraLocalBean");

		System.out.println("AltaUsuario");
		assertTrue(sbean.altaUsuario(citizen));

		System.out.println("Login");
		assertTrue(sbean.login("email_citizen"));

		System.out.println("Suscripcion");
		assertTrue(sbean.suscripcion(EArea.ECONOMIA, citizen));

		System.out.println("BusquedaHechos");
		assertEquals(sbean.busquedaHechos("Lacalle").size(), 2);

		System.out.println("ListadoHechos");
		assertEquals(sbean.listadoHechos(1).size(), 6);

		System.out.println("RealizarDonacion");
		assertTrue(sbean.realizarDonacion("6FP72614J4903442N"));

		System.out.println("VerPerfil");
		assertNotNull(sbean.verPerfil(citizen.getEmail()));

		SBHechoLocalBO sb1 = (SBHechoLocalBO) context.lookup("SBHechoBOLocal");

		FechaToDate fecha = new FechaToDate();

		DTHecho frase = new DTHecho("Frase FO", 114, "link.frase", fecha.restarDiasFecha(fecha.fechaSistema(), 1),
				"medio.frase", EEstado.NUEVO, EArea.POLITICA, EVeracidad.FALSA, "email_citizen", "frasetexto",
				"autorfrase", null);
		DTHecho frase1 = new DTHecho("Frase con diferencia", 115, "link.frase",
				fecha.restarDiasFecha(fecha.fechaSistema(), 2), "medio.frase", EEstado.NUEVO, EArea.POLITICA,
				EVeracidad.FALSA, "email_subm", "frasetexto", "autorfrase", null);
		DTHecho frase2 = new DTHecho("No al maltrato de animales", 116, "link.frase",
				fecha.restarDiasFecha(fecha.fechaSistema(), 2), "medio.frase", EEstado.NUEVO, EArea.POLITICA,
				EVeracidad.FALSA, "email_subm", "frasetexto", "autorfrase", null);
		DTHecho noticia = new DTHecho("No al maltrato de animales", 117, "link.frase",
				fecha.restarDiasFecha(fecha.fechaSistema(), 2), "medio.frase", EEstado.NUEVO, EArea.POLITICA,
				EVeracidad.FALSA, "email_subm", null, null, "imagen.jpg");
		
		assertTrue(sb1.crearHechoVerificar(frase));
		assertTrue(sb1.seleccionarHechoVerificar(frase));
		assertTrue(sb1.asignarHechoVerificar(frase, new DTUsuario(null, "email_che", null, null)));
		assertTrue(sb1.tomarHechoVerificar(frase));
		assertTrue(sb1.verificarHecho(frase, EVeracidad.FALSA, "Es Verdadera"));

		assertTrue(sb1.crearHechoVerificar(frase1));
		assertTrue(sb1.seleccionarHechoVerificar(frase1));
		assertTrue(sb1.asignarHechoVerificar(frase1, new DTUsuario(null, "email_che", null, null)));
		assertTrue(sb1.tomarHechoVerificar(frase1));
		assertTrue(sb1.verificarHecho(frase1, EVeracidad.FALSA, "Es Verdadera"));

		assertTrue(sb1.crearHechoVerificar(frase2));
		assertTrue(sb1.seleccionarHechoVerificar(frase2));
		assertTrue(sb1.asignarHechoVerificar(frase2, new DTUsuario(null, "email_che", null, null)));
		assertTrue(sb1.tomarHechoVerificar(frase2));
		assertTrue(sb1.verificarHecho(frase2, EVeracidad.FALSA, "Es Verdadera"));

		assertTrue(sbean.crearHechoVerificar(noticia));
		assertTrue(sb1.seleccionarHechoVerificar(noticia));
		assertTrue(sb1.asignarHechoVerificar(noticia, new DTUsuario(null, "email_che", null, null)));
		assertTrue(sb1.tomarHechoVerificar(noticia));
		assertTrue(sb1.verificarHecho(noticia, EVeracidad.FALSA, "Es Verdadera"));

		assertNotNull(sbean.reporteTopHechoFake());

		assertNotNull(sbean.reporteNoticasPorVeracidad());

		assertNotNull(sbean.obtenerVerificacion(117));

		// OBTENEMOS UN TOKEN NO VALIDO, INSTANCIANDO LA CONSTANTE TOKENGOOGLE
		Constantes constante = new Constantes();
		try {
			assertNull(sbean.validacionTokenGoogle(constante.getTokengoogle()));
		} catch (GeneralSecurityException | IOException e) {
			e.printStackTrace();
		}
		
	}

}
