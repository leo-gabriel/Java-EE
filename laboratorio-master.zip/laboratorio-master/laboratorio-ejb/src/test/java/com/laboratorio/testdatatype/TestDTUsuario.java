package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.datatype.DTAdmin;
import com.laboratorio.datatype.DTChecker;
import com.laboratorio.datatype.DTCitizen;
import com.laboratorio.datatype.DTDonacion;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTSubmitter;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;

public class TestDTUsuario {
	
	private String username;
	private String email;
	private String password;
	private List<DTHecho> hechos = new ArrayList<>();
	private int ciusuario;
	private List<DTDonacion> donaciones =new ArrayList<>();
	
	public TestDTUsuario() {}
	
	@Before
	public void setUpClass() throws Exception {
		Date fecha = null;
		username="Prueba username";
		email="Preuba email";
		password="Prueba password";
		hechos.add(new DTHecho("hecho", 1, "link", fecha, "medio", EEstado.NUEVO, EArea.POLITICA, EVeracidad.VERACIDAD, "email_usuario", 
				"frase", "autor", "imagen"));
		ciusuario=12345678;
		donaciones.add(new DTDonacion(123, "email donador"));
		
	}
	
	@Test
	public void dTUsuario() {
		DTAdmin admin=new DTAdmin(username, email, password, hechos, ciusuario);
		DTChecker checker=new DTChecker(username, email, password, hechos, ciusuario);
		DTCitizen citizen=new DTCitizen(username, email, password, hechos, donaciones);
		DTSubmitter submitter=new DTSubmitter(username, email, password, hechos, ciusuario);
		
		DTAdmin adminaux =new DTAdmin();
		DTChecker checkeraux=new DTChecker();
		DTCitizen citizenaux=new DTCitizen();
		DTSubmitter submitteauxr=new DTSubmitter();
		
		//preparcion del admin
		adminaux.setUsername(admin.getUsername());
		adminaux.setEmail(admin.getEmail());
		adminaux.setPassword(admin.getPassword());
		adminaux.setHechos(admin.getHechos());
		adminaux.setCi(admin.getCi());
		//preparacicon del checker
		checkeraux.setUsername(checker.getUsername());
		checkeraux.setEmail(checker.getEmail());
		checkeraux.setPassword(checker.getPassword());
		checkeraux.setHechos(checker.getHechos());
		checkeraux.setCi(checker.getCi());
		//preparacion del citizen
		citizenaux.setUsername(citizen.getUsername());
		citizenaux.setEmail(citizen.getEmail());
		citizenaux.setPassword(citizen.getPassword());
		citizenaux.setHechos(citizen.getHechos());
		citizenaux.setDonaciones(citizen.getDonaciones());
		//preparacion del submitter
		submitteauxr.setUsername(submitter.getUsername());
		submitteauxr.setEmail(submitter.getEmail());
		submitteauxr.setPassword(submitter.getPassword());
		submitteauxr.setHechos(submitter.getHechos());
		submitteauxr.setCi(submitter.getCi());
		/////////////////////////////////////////////
		assertTrue(adminaux.getUsername().equals(username));
		assertTrue(adminaux.getEmail().equals(email));
		assertTrue(adminaux.getPassword().equals(password));
		assertTrue(adminaux.getHechos().get(0).getTitulo().equals("hecho"));
		assertTrue(adminaux.getCi()==ciusuario);
		////////////////////////////////////////////
		assertTrue(checkeraux.getUsername().equals(username));
		assertTrue(checkeraux.getEmail().equals(email));
		assertTrue(checkeraux.getPassword().equals(password));
		assertTrue(checkeraux.getHechos().get(0).getTitulo().equals("hecho"));
		assertTrue(checkeraux.getCi()==ciusuario);
		/////////////////////////////////////////////
		assertTrue(citizenaux.getUsername().equals(username));
		assertTrue(citizenaux.getEmail().equals(email));
		assertTrue(citizenaux.getPassword().equals(password));
		assertTrue(citizenaux.getHechos().get(0).getTitulo().equals("hecho"));
		assertTrue(citizenaux.getDonaciones().get(0).getMonto()==123);
		//////////////////////////////////////////////
		assertTrue(submitteauxr.getUsername().equals(username));
		assertTrue(submitteauxr.getEmail().equals(email));
		assertTrue(submitteauxr.getPassword().equals(password));
		assertTrue(submitteauxr.getHechos().get(0).getTitulo().equals("hecho"));
		assertTrue(submitteauxr.getCi()==ciusuario);
		
	}

}
