package com.laboratorio.testextra;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.laboratorio.datatype.DTHecho;
import com.laboratorio.extra.Configuracion;
import com.laboratorio.extra.EnviarMail;
import com.laboratorio.extra.ID_Verificacion;
import com.laboratorio.extra.Validaciones;

public class TestExtra {

	@SuppressWarnings("unlikely-arg-type")
	@Test
	public void extra() {
		Validaciones vali = new Validaciones();
		assertFalse(vali.validacionEmail("email"));
		assertNull(vali.validacionTokenGoogleMobile(
				"eyJhbGciOiJSUzI1NiIsImtpZCI6IjExOGRmMjU0YjgzNzE4OWQxYmMyYmU5NjUwYTgyMTEyYzAwZGY1YTQiLCJ0eXAiOiJKV1QifQ."
				+ "eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiIyNjA3MzY4MDE4ODktZTdxaWt1aDM1bGYxMDMxZGRxZGV"
				+ "vajhmMjBhcTVjMTYuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiIyNjA3MzY4MDE4ODktZG1qbjZmb2M4b3ZyaWU2ZG"
				+ "1qNTBwcXByZ2VwZzg4ZGsuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDYwNzYyMDY1MTc4NzI1NjQwOTgiLCJlb"
				+ "WFpbCI6Im1vbmljYXRlY25pY29wY0BnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwibmFtZSI6Ik1vbmljYSBSb2RyaWd1"
				+ "ZXoiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EtL0FBdUU3bUQ4RVhRVWJlUHFUekxNOXVkS01"
				+ "TNjEzaUhaa3JtQy1RNWlUbDB0TEE9czk2LWMiLCJnaXZlbl9uYW1lIjoiTW9uaWNhICIsImZhbWlseV9uYW1lIjoiUm9kcmlndWV6Ii"
				+ "wibG9jYWxlIjoiZXMtNDE5IiwiaWF0IjoxNTYxNzUyMDgwLCJleHAiOjE1NjE3NTU2ODB9.fm0oB9J5PvSE_OrI3kZMxaFUJRXxZFE4"
				+ "wIC5vGkgt3Ok39PmQJI6gX9afX_Oh9Mfg5xTKHzkWDpztBN_Slbm9YEeEPssLpHmN4qw9ahvWwUqmqEaepifLXpydEqOeODudGGoYh0"
				+ "zhQ9mnW8R_SQBQYdbK3qOk3e4iPZ__KJxYNVH0VmLglV3OSO28tXN9zzZxriS-KXxT3mLkewXaADff6F0IoZ2P-26GAIYks1zkT4nPa"
				+ "ly-I-vseE0t2edHkkm1pkFo-LgaWb4HX1DDtRz48q_JnDATdxuR_a-VICGLgsLV76gIHFFil5_8AJE8SIMZBzRM-8O5BBufNAbqJMxIQ"));

		ID_Verificacion ide = new ID_Verificacion(1, 2);
		ID_Verificacion id1 = new ID_Verificacion(3, 7);
		ID_Verificacion id3 = new ID_Verificacion(4, 2);

		assertFalse(ide.equals(id1));
		assertFalse(ide.equals(null));
		assertFalse(ide.equals(vali));
		assertFalse(ide.equals(id3));
		assertTrue(ide.equals(ide));

		EnviarMail email = new EnviarMail();
		email.apiMailgun("prueba", "prueba", new DTHecho());

		Configuracion confi = new Configuracion();
		assertNotNull(confi.getIdconfi());
	}

}
