package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.datatype.DTPassword;

public class TestDTPassword {

	private String hash;
	private String salt;

	@Before
	public void setUpClass() throws Exception {
		hash = "hash";
		salt = "salt";
	}

	@Test
	public void dTPassword() {
		DTPassword pass = new DTPassword(hash, salt);
		DTPassword compa = new DTPassword();

		compa.setHash(hash);
		compa.setSalt(salt);

		assertTrue(pass.getHash().equals(compa.getHash()));
		assertTrue(pass.getSalt().equals(compa.getSalt()));
	}

}
