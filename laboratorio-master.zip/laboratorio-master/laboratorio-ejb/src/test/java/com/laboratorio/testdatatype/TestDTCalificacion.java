package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.datatype.DTCalificacion;
import com.laboratorio.e_num.EVeracidad;

public class TestDTCalificacion {

	private int idHecho;
	private EVeracidad veracidad;
	private String justificacion;
	
	
	@Before
	public void setUpClass() {
		idHecho=1;
		veracidad=EVeracidad.VERACIDAD;
		justificacion="Prueba justificacion";
	}
	
	@Test
	public void dTCalificacion() {
		
		DTCalificacion calificacion=new DTCalificacion(idHecho, veracidad, justificacion);
		DTCalificacion comparacion=new DTCalificacion();
		
		comparacion.setIdHecho(idHecho);
		comparacion.setVeracidad(veracidad);
		comparacion.setJustificacion(justificacion);
		
		assertTrue(calificacion.getIdHecho()==idHecho);
		assertTrue(calificacion.getVeracidad().equals(veracidad));
		assertTrue(calificacion.getJustificacion().equals(justificacion));
		
		assertTrue(comparacion.getIdHecho()==idHecho);
		assertTrue(comparacion.getVeracidad().equals(veracidad));
		assertTrue(comparacion.getJustificacion().equals(justificacion));
		
	}
}
