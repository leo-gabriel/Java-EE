package com.laboratorio.testclass;

import java.util.Date;

import org.junit.Test;

import com.laboratorio.c_lass.Verificacion;

public class TestVerificacion {

	@Test
	public void verificacion() {
		Verificacion veri = new Verificacion();

		veri.setFechainicio(new Date());
		veri.getIdv();
		veri.getHecho();
		veri.getChecker();
	}

}
