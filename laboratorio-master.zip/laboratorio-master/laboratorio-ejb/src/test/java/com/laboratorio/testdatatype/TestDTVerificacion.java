package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTUsuario;
import com.laboratorio.datatype.DTVerificacion;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.FechaToDate;

public class TestDTVerificacion {

	private Date fechainicio;
	private Date fechafin;
	private EVeracidad veracidad;
	private String justifiacion;
	private DTHecho hecho;
	private DTUsuario checker;

	@Before
	public void setUp() {
		FechaToDate date = new FechaToDate();
		fechainicio = date.restarDiasFecha(date.fechaSistema(), 1);
		fechafin = date.fechaSistema();
		veracidad = EVeracidad.VERACIDAD;
		justifiacion = "justificacion";
		hecho = new DTHecho();
		hecho.setTitulo("titulo");
		checker = new DTUsuario();
		checker.setUsername("user");
	}

	@Test
	public void dTVerificacion() {
		DTVerificacion veri = new DTVerificacion(fechainicio, fechafin, veracidad, justifiacion, hecho, checker);
		DTVerificacion compa = new DTVerificacion();

		compa.setFechainicio(fechainicio);
		compa.setFechafin(fechafin);
		compa.setVeracidad(veracidad);
		compa.setJustifiacion(justifiacion);
		compa.setHecho(hecho);
		compa.setChecker(checker);

		FechaToDate date = new FechaToDate();
		assertTrue(date.verFecha(veri.getFechainicio()).equals(date.verFecha(compa.getFechainicio())));
		assertTrue(date.verFecha(veri.getFechafin()).equals(date.verFecha(compa.getFechafin())));
		assertTrue(veri.getVeracidad().equals(compa.getVeracidad()));
		assertTrue(veri.getJustifiacion().equals(compa.getJustifiacion()));
		assertTrue(veri.getHecho().getTitulo().equals(compa.getHecho().getTitulo()));
		assertTrue(veri.getChecker().getUsername().equals(compa.getChecker().getUsername()));

	}
}
