package com.laboratorio.testtotal;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.laboratorio.testclass.TestDonacion;
import com.laboratorio.testclass.TestHecho;
import com.laboratorio.testclass.TestPassword;
import com.laboratorio.testclass.TestSuscripcion;
import com.laboratorio.testclass.TestUsuario;
import com.laboratorio.testclass.TestVerificacion;
import com.laboratorio.testdao.TestDAO_Extra;
import com.laboratorio.testdao.TestDAO_Submitter_Checker;
import com.laboratorio.testdatatype.TestDTCalificacion;
import com.laboratorio.testdatatype.TestDTConfiguracion;
import com.laboratorio.testdatatype.TestDTDonacion;
import com.laboratorio.testdatatype.TestDTPassword;
import com.laboratorio.testdatatype.TestDTSuscripcion;
import com.laboratorio.testdatatype.TestDTUsuario;
import com.laboratorio.testdatatype.TestDTVerificacion;
import com.laboratorio.testdatatype.TestDThecho;
import com.laboratorio.testextra.TestExtra;
import com.laboratorio.testsb.TestSBCalificaciones;
import com.laboratorio.testsb.TestSBConfiguraciones;
import com.laboratorio.testsb.TestSBHechoBO;
import com.laboratorio.testsb.TestSBHechoFO;

@RunWith(Suite.class)
@SuiteClasses({ TestDTCalificacion.class, TestDTConfiguracion.class, TestDTDonacion.class, TestDTUsuario.class,
		TestDThecho.class, TestDTPassword.class, TestDTSuscripcion.class, TestDTVerificacion.class, TestSBHechoBO.class,
		TestUsuario.class, TestHecho.class, TestVerificacion.class, TestPassword.class, TestSBHechoFO.class,
		TestSuscripcion.class, TestSBConfiguraciones.class, TestDAO_Submitter_Checker.class, TestDAO_Extra.class,
		TestExtra.class, TestSBCalificaciones.class, TestDonacion.class })
	public class TodoTest {
}
