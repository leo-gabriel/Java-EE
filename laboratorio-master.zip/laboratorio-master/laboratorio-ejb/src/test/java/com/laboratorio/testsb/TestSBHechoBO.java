package com.laboratorio.testsb;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.laboratorio.datatype.DTAdmin;
import com.laboratorio.datatype.DTCalificacion;
import com.laboratorio.datatype.DTChecker;
import com.laboratorio.datatype.DTHecho;
import com.laboratorio.datatype.DTSubmitter;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.FechaToDate;
import com.laboratorio.sb.SBHechoLocalBO;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TestSBHechoBO {

	private static DTAdmin admin;
	private static DTSubmitter submitter;
	private static DTChecker checker;
	private static DTChecker usuario_repetido;
	private static DTHecho frase;
	private static DTHecho noticia;
	private static DTHecho auxiliar;
	private static Context context;

	/**
	 * Inicialización del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@BeforeClass
	public static void setUP() throws NamingException {
		Properties props = new Properties();
		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");

		props.put("DefaultDS", "new://Resource?type=DataSource");
		props.put("DefaultDS.JdbcDriver", "org.hsqldb.jdbcDriver");
		props.put("DefaultDS.JdbcUrl", "jdbc:hsqldb:.");

		context = new InitialContext(props);

		// CARGAMOS DATOS PARA USUARIOS
		admin = new DTAdmin("admin", "email_admin", "passwordcitizen", null, 123);
		submitter = new DTSubmitter("subm", "email_subm", "passwordsubmitter", null, 123);
		checker = new DTChecker("che", "email_che", "passwordchecker", null, 123);
		usuario_repetido = new DTChecker("che", "email_che", "passwordchecker", null, 123);

		// CARGAMOS DATOS PARA HECHOS
		FechaToDate fecha = new FechaToDate();
		// los id, son 101 y 102, los asigna openejb, los usamos para poder buscarlos
		frase = new DTHecho("Frase", 101, "link.frase", fecha.fechaSistema(), "medio.frase", EEstado.NUEVO,
				EArea.POLITICA, EVeracidad.VERACIDAD, "email_subm", "frasetexto", "autorfrase", null);
		noticia = new DTHecho("Noticia", 102, "link.noticia", fecha.fechaSistema(), "medionoticia", EEstado.NUEVO,
				EArea.SALUD, EVeracidad.FALSA, "email_subm", null, null, "imagen.jpg");
		auxiliar = new DTHecho("NoticiaAUX", 103, "link.noticia", fecha.fechaSistema(), "medionoticia", EEstado.NUEVO,
				EArea.SALUD, EVeracidad.FALSA, "email_che", null, null, "imagen.jpg");
	}

	/**
	 * Parada del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@AfterClass
	public static void setDOWN() throws NamingException {
		context.close();
	}

	/**
	 * Invocación a través del interfaz local
	 * 
	 * @throws NamingException
	 */
	@Test
	public void sBHechoBO() throws NamingException {
		SBHechoLocalBO sbean = (SBHechoLocalBO) context.lookup("SBHechoBOLocal");
		System.out.println("AltaUsuario");
		assertTrue(sbean.altaUsuario(submitter));
		assertTrue(sbean.altaUsuario(checker));
		assertTrue(sbean.altaUsuario(admin));
		assertFalse(sbean.altaUsuario(usuario_repetido));

		System.out.println("Login");
		assertNotNull(sbean.login("email_admin", "passwordcitizen"));
		assertNotNull(sbean.login("email_subm", "passwordsubmitter"));
		assertNotNull(sbean.login("email_che", "passwordchecker"));

		System.out.println("CrearHechoVerificar");
		assertTrue(sbean.crearHechoVerificar(frase));
		assertTrue(sbean.crearHechoVerificar(noticia));
		assertTrue(sbean.crearHechoVerificar(auxiliar));

		System.out.println("ListadoDeHechos");
		List<DTHecho> lista = sbean.listadoDeHechos(EEstado.NUEVO, null, "email_subm", null, null);
		List<DTHecho> lista1 = sbean.listadoDeHechos(EEstado.NUEVO, null, null, null, null);
		assertEquals(lista.size(), 7);
		assertEquals(lista1.size(), 7);

		System.out.println("getHecho");
		assertEquals(sbean.getHecho(103).getId(), 103);

		System.out.println("SeleccionarHechoVerificar");
		assertTrue(sbean.seleccionarHechoVerificar(frase));
		assertTrue(sbean.seleccionarHechoVerificar(auxiliar));

		System.out.println("AsignarHechoVerificar");
		assertTrue(sbean.asignarHechoVerificar(frase, checker));
		assertTrue(sbean.asignarHechoVerificar(auxiliar, checker));

		System.out.println("TomarHechoVerificar");
		assertTrue(sbean.tomarHechoVerificar(frase));
		assertTrue(sbean.tomarHechoVerificar(auxiliar));

		System.out.println("VerificarHecho");
		assertTrue(sbean.verificarHecho(frase, EVeracidad.VERDADERA, "Es Verdadera"));

		System.out.println("PublicarHecho");
		assertTrue(sbean.publicarHecho(frase, submitter));

		System.out.println("CancelarHecho");
		assertTrue(sbean.cancelarHecho(noticia, submitter));

		System.out.println("ListadoChecker");
		assertNotNull(sbean.listadoChecker());

		System.out.println("Validacion_Token");
		assertFalse(sbean.validacionToken(
				"{\"JWT\":\"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJicnVub3Nhc3NvMkBnbWFpbC5jb20iLCJleHAiOjE1NjA0NTkwMTYsInRpcG91c3VhcmlvIjoiRFRDaGVja2VyIn0.4ydS7c5CiJuQ5c-zwfGlORiYFKYc-JXoa3mX-h-lHw8\"}"));

		System.out.println("ObtenerVerificacion");
		assertNotNull(sbean.obtenerVerificacion(checker.getEmail(), 103));

		System.out.println("recibirCalificacionExterna");
		assertTrue(sbean.recibirCalificacionExterna(new DTCalificacion(103, EVeracidad.ENGANIOSA, "Enganiosa")));

		assertEquals(sbean.listadoDeHechos(null, null, null, null, null).size(), 13);
	}

}
