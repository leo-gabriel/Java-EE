package com.laboratorio.testsb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.laboratorio.datatype.DTPeriferico;
import com.laboratorio.sb.SBConfiguracionesLocal;

public class TestSBConfiguraciones {

	private static Context context;

	@BeforeClass
	public static void setUP() throws NamingException {
		Properties props = new Properties();
		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.LocalInitialContextFactory");

		props.put("DefaultDS", "new://Resource?type=DataSource");
		props.put("DefaultDS.JdbcDriver", "org.hsqldb.jdbcDriver");
		props.put("DefaultDS.JdbcUrl", "jdbc:hsqldb:.");

		context = new InitialContext(props);
	}

	/**
	 * Parada del contenedor de EJBs.
	 * 
	 * @throws NamingException
	 */
	@AfterClass
	public static void setDOWN() throws NamingException {
		context.close();
	}

	/**
	 * Invocación a través del interfaz local
	 * 
	 * @throws NamingException
	 */
	@Test
	public void sBConfiguracion() throws NamingException {
		SBConfiguracionesLocal sbean = (SBConfiguracionesLocal) context.lookup("SBConfiguracionesLocal");

		assertTrue(sbean.crearPeriferico(new DTPeriferico("testperiferico", "testurl")));
		assertFalse(sbean.crearPeriferico(new DTPeriferico("testperiferico", "testurl")));

		sbean.habilitarPeriferico(new DTPeriferico("testperiferico", "testurl"));
		;
		List<DTPeriferico> lista = sbean.getConfiguracion().getListaPerifericos();
		assertTrue(lista.get(1).getNombre().equals("testperiferico"));

		sbean.hdNotificaciones(false);
		assertFalse(sbean.getConfiguracion().getNotificaciones());

		sbean.setTiempoMaximo(25);
		assertEquals(sbean.getConfiguracion().getTiempoMaximoVerificacion(), 25);
	}

}
