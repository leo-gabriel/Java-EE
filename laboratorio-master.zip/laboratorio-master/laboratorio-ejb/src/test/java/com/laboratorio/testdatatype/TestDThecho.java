package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.laboratorio.datatype.DTHecho;
import com.laboratorio.e_num.EArea;
import com.laboratorio.e_num.EEstado;
import com.laboratorio.e_num.EVeracidad;
import com.laboratorio.extra.FechaToDate;

public class TestDThecho {
	
	private String titulo;
	private int idhecho;
	private String link;
	private Date fecha;
	private String medio;
	private EEstado estado;
	private EArea area;
	private EVeracidad veracidad;
	private String emailusuario;
	private String frase;
	private String autor;
	private String imagen;
	
	
	@Before
	public void setUpClass() throws Exception {
		titulo="titulo";
		idhecho=1;
		link="link";
		FechaToDate date=new FechaToDate();
		fecha=date.fechaSistema();
		medio="medio";
		estado=EEstado.NUEVO;
		area=EArea.ECONOMIA;
		veracidad=EVeracidad.VERACIDAD;
		emailusuario="email";
		frase="frase";
		autor="autor";
		imagen="imagen";
	}

	@Test
	public void dTHecho() {
		
		DTHecho hecho=new DTHecho(titulo, idhecho, link, fecha, medio, estado, area, veracidad, emailusuario, frase, autor, imagen);
		DTHecho comparacion=new DTHecho();
		
		comparacion.setTitulo(titulo);
		comparacion.setId(idhecho);
		comparacion.setLink(link);
		comparacion.setFecha(fecha);
		comparacion.setMedio(medio);
		comparacion.setEstado(estado);
		comparacion.setArea(area);
		comparacion.setVeracidad(veracidad);
		comparacion.setEmailusuario(emailusuario);
		comparacion.setFrase(frase);
		comparacion.setAutor(autor);
		comparacion.setImagen(imagen);
		
		assertTrue(hecho.getTitulo().equals(comparacion.getTitulo()));
		assertTrue(hecho.getId()==comparacion.getId());
		assertTrue(hecho.getLink().equals(comparacion.getLink()));
		FechaToDate date=new FechaToDate();
		assertTrue(date.verFecha(hecho.getFecha()).equals(date.verFecha(comparacion.getFecha())));
		assertTrue(hecho.getMedio().equals(comparacion.getMedio()));
		assertTrue(hecho.getEstado().equals(comparacion.getEstado()));
		assertTrue(hecho.getArea().equals(comparacion.getArea()));
		assertTrue(hecho.getVeracidad().equals(comparacion.getVeracidad()));
		assertTrue(hecho.getEmailusuario().equals(comparacion.getEmailusuario()));
		assertTrue(hecho.getFrase().equals(comparacion.getFrase()));
		assertTrue(hecho.getAutor().equals(comparacion.getAutor()));
		assertTrue(hecho.getImagen().equals(comparacion.getImagen()));
		
	}

}
