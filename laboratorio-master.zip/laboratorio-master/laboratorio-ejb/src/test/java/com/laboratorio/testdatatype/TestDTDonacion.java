package com.laboratorio.testdatatype;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.laboratorio.datatype.DTDonacion;

public class TestDTDonacion {

	public TestDTDonacion() {
	}

	@Test
	public void dTDonacion() {

		DTDonacion var1 = new DTDonacion(155, "Un email de prueba");
		DTDonacion var2 = new DTDonacion();

		var2.setMonto(155);
		var2.setDonador("Un email de prueba");

		assertTrue(var1.getMonto() == var2.getMonto());
		assertTrue(var1.getDonador().equals(var2.getDonador()));
	}

}
