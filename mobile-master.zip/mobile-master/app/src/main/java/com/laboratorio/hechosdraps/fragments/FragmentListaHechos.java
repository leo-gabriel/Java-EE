package com.laboratorio.hechosdraps.fragments;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.cloudinary.android.MediaManager;
import com.laboratorio.hechosdraps.MainActivity;
import com.laboratorio.hechosdraps.R;
import com.laboratorio.hechosdraps.adapters.HechosAdapters;
import com.laboratorio.hechosdraps.clases.GlideApp;
import com.laboratorio.hechosdraps.clases.Hecho;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.Context.SEARCH_SERVICE;
import static android.support.v4.content.ContextCompat.getSystemService;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link FragmentListaHechos.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link FragmentListaHechos#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentListaHechos extends Fragment implements SearchView.OnQueryTextListener, MenuItem.OnActionExpandListener {



    Context mContext;

    private OnFragmentInteractionListener mListener;
    RecyclerView recyclerHechos;
    private ArrayList<Hecho> lstHecho;
    ImageView imagenVeracidad;

///10.0.2.2
    private final String URL="http://179.27.97.58:8080/laboratorio-web/rest/wsMobile/Hechos/1";
    private JsonArrayRequest jsonObjectRequest;
    private RequestQueue request;

    public FragmentListaHechos() {
        // Required empty public constructor
    }


    public static FragmentListaHechos newInstance(String param1, String param2) {
        FragmentListaHechos fragment = new FragmentListaHechos();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        mContext=getActivity();


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View vista= inflater.inflate(R.layout.fragment_fragment_lista_hechos, container, false);


        lstHecho=new ArrayList<>();
        recyclerHechos= vista.findViewById(R.id.reciclerviewid);
        recyclerHechos.setHasFixedSize(true);

         jsonRequest();
        return vista;
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
         inflater.inflate(R.menu.activity_main_drawer,menu);
         MenuItem searchItem= menu.findItem(R.id.search);
         SearchView searchView= (SearchView) searchItem.getActionView();
         searchView.setOnQueryTextListener(this);
         searchView.setQueryHint("Search");
        super.onCreateOptionsMenu(menu, inflater);
        super.onCreateOptionsMenu(menu, inflater);
    }


    private void jsonRequest() {
        jsonObjectRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                JSONObject jsonObject= null;

                for(int i=0; i < response.length(); i++){

                    try{
                        jsonObject = response.getJSONObject(i);
                        Hecho hecho=new Hecho();
                        hecho.setId(jsonObject.getInt("id"));
                        hecho.setTitulo(jsonObject.getString("titulo"));
                        hecho.setArea(jsonObject.getString("area"));
                        hecho.setLink(jsonObject.getString("link"));
                        hecho.setMedio(jsonObject.getString("medio"));
                        hecho.setVeracidad(jsonObject.getString("veracidad"));
                       if(!jsonObject.isNull("autor")){
                            hecho.setAutor(jsonObject.getString("autor"));
                            hecho.setFrase(jsonObject.getString("frase"));

                        }else{
                            hecho.setImagen(jsonObject.getString("imagen"));
                        }

                        lstHecho.add(hecho);

                    }catch(JSONException e){
                        e.printStackTrace();
                    }
                }

               setuprecyclerview(lstHecho);
            }
        },new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        request= Volley.newRequestQueue(getActivity().getApplicationContext());
        request.add(jsonObjectRequest);

    }

   public void filtro(String name){
        jsonObjectRequest=new JsonArrayRequest("http://179.27.97.58:8080/laboratorio-web/rest/wsMobile/filtro/"+name, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                JSONObject jsonObject= null;

                for(int i=0; i < response.length(); i++){

                    try{
                        jsonObject = response.getJSONObject(i);
                        Hecho hecho=new Hecho();
                        hecho.setTitulo(jsonObject.getString("titulo"));
                        hecho.setArea(jsonObject.getString("area"));
                        hecho.setLink(jsonObject.getString("link"));
                        hecho.setMedio(jsonObject.getString("medio"));
                        hecho.setVeracidad(jsonObject.getString("veracidad"));

                        if(!jsonObject.isNull("autor")){
                            hecho.setAutor(jsonObject.getString("autor"));
                            hecho.setFrase(jsonObject.getString("frase"));

                        }else{
                            hecho.setImagen(jsonObject.getString("imagen"));
                        }

                        lstHecho.add(hecho);

                    }catch(JSONException e){
                        e.printStackTrace();
                    }
                }

                setuprecyclerview(lstHecho);
            }
        },new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        request= Volley.newRequestQueue(getActivity().getApplicationContext());
        request.add(jsonObjectRequest);

    }





    private void setuprecyclerview(final List<Hecho> lstHecho) {

       HechosAdapters myAdapter= new HechosAdapters(lstHecho,getContext());
       recyclerHechos.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerHechos.setAdapter(myAdapter);

    }



    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public boolean onMenuItemActionExpand(MenuItem item) {
        return false;
    }

    @Override
    public boolean onMenuItemActionCollapse(MenuItem item) {
        return false;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
       if(newText==null || newText.trim().isEmpty()){
           lstHecho = new ArrayList<>();
           jsonRequest();
           return false;
       }else {

           lstHecho = new ArrayList<>();
           filtro(newText);
           return false;
       }
    }





    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


    }

