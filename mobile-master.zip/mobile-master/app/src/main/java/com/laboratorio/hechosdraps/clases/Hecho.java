package com.laboratorio.hechosdraps.clases;

import java.io.Serializable;

public class Hecho implements Serializable {
    private String titulo;
    private	int id;
    private String link;
    private	String fecha;
    private	String medio;
    private	String estado;
    private	String area;
    private	String veracidad;
    private	String email_usuario;
    private	String frase;
    private	String autor;
    private	String imagen;
    private String justificacion;

    @Override
    public String toString() {
        return  titulo ;
    }

    public int getId() {
        return id;
    }

    public String getJustificacion() { return justificacion;}

    public void setJustificacion(String justificacion) {this.justificacion = justificacion; }

    public void setId(int id) {
        this.id = id;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getMedio() {
        return medio;
    }

    public void setMedio(String medio) {
        this.medio = medio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getVeracidad() {
        return veracidad;
    }

    public void setVeracidad(String veracidad) {
        this.veracidad = veracidad;
    }

    public String getEmail_usuario() {
        return email_usuario;
    }

    public void setEmail_usuario(String email_usuario) {
        this.email_usuario = email_usuario;
    }

    public String getFrase() {
        return frase;
    }

    public void setFrase(String frase) {
        this.frase = frase;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


}
