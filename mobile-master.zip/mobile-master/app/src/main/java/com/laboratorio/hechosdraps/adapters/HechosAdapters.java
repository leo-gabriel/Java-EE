package com.laboratorio.hechosdraps.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.ColorSpace;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.laboratorio.hechosdraps.DetalleHecho;
import com.laboratorio.hechosdraps.R;
import com.laboratorio.hechosdraps.clases.Hecho;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HechosAdapters extends RecyclerView.Adapter<HechosAdapters.MyViewHolder>{
    private Context mContext;
    private List<Hecho> listaHechos;
    private ArrayList<Hecho> arrayList;

    public HechosAdapters(List<Hecho> listaHechos, Context mContext) {
        this.mContext = mContext;
        this.listaHechos = listaHechos;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View vista= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent,false);
      RecyclerView.LayoutParams layoutParams= new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
      vista.setLayoutParams(layoutParams);
        final MyViewHolder viewHolder=new MyViewHolder(vista);
        viewHolder.view_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Hecho hecho = listaHechos.get(viewHolder.getAdapterPosition());
                Intent i= new Intent(mContext, DetalleHecho.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("hecho", hecho);
                i.putExtras(bundle);
                mContext.startActivity(i);

            }
        });



      return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.titulo.setText(listaHechos.get(i).getTitulo());
        myViewHolder.area.setText(listaHechos.get(i).getArea());
        myViewHolder.veracidad.setText(listaHechos.get(i).getVeracidad());
        switch (myViewHolder.veracidad.getText().toString()){
            case "VERDADERA":
                Glide.with(mContext).load( "https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/verdadera_wilpt8.jpg").into(myViewHolder.imagenVeracidad);
                break;
            case "VERDAD_A_MEDIAS":
                Glide.with(mContext).load( "https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/vardadamedias_mq8yyw.jpg").into(myViewHolder.imagenVeracidad);
                break;
            case "INFLADA":
                Glide.with(mContext).load( "https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/inflada_bmnouf.jpg").into(myViewHolder.imagenVeracidad);
                break;
            case "FALSA":
                Glide.with(mContext).load( "https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/falsa_bmdyhd.jpg").into(myViewHolder.imagenVeracidad);
                break;
            case "RIDICULA":
                Glide.with(mContext).load( "https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/ridicula_tlibti.jpg").into(myViewHolder.imagenVeracidad);
                break;
            case "ENGANIOSA":
                Glide.with(mContext).load( "https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/enganiosa_hd4p1o.jpg").into(myViewHolder.imagenVeracidad);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return listaHechos.size();
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView titulo, area, veracidad;
        LinearLayout view_container;
        ImageView imagenVeracidad;

        public MyViewHolder(View itemview){
            super(itemview);
            view_container=itemview.findViewById(R.id.container);
            titulo= itemview.findViewById(R.id.titulo_hecho);
            area=itemview.findViewById(R.id.area_hecho);
            veracidad=itemview.findViewById(R.id.veracidad_hecho);
            imagenVeracidad= itemview.findViewById(R.id.imagen_hecho);
        }



    }
}
