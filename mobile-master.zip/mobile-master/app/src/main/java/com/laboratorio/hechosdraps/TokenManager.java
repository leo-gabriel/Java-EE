package com.laboratorio.hechosdraps;

import android.content.Context;
import android.content.SharedPreferences;

public class TokenManager {

    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    static Context context;
    static int privatemode=0;
    private static final String PREF_NAME="JWTTOKEN";
    private static final String KEY_USER_NAME="username";
    private static final String KEY_JWT_TOKEN="jwttoken";

    public static String getFromSharedPreferences(String key){
        SharedPreferences sharedPref= context.getSharedPreferences(PREF_NAME,privatemode);
        return sharedPref.getString(key, "");
    }
    public TokenManager(Context context){
        this.context=context;
        preferences=context.getSharedPreferences(PREF_NAME,privatemode);
        editor= preferences.edit();

    }

    public void CreatedLoginSession(String username, String jwtvalue){
        editor.putString(KEY_USER_NAME,username);
        editor.putString(KEY_JWT_TOKEN,jwtvalue);
        editor.commit();
    }





}
