package com.laboratorio.hechosdraps.clases;

public class Utilidades {

   public static int rotacion=0;
   public static boolean validaPantalla;
}
