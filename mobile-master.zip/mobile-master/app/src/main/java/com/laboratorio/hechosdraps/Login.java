package com.laboratorio.hechosdraps;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.Task;
import com.laboratorio.hechosdraps.MainActivity;
import com.laboratorio.hechosdraps.R;
import com.laboratorio.hechosdraps.TokenManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class Login extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {
Context context;
EditText editTextemail, editTextpassword;
Button btnIngresar;
TextInputLayout usuario, contrasena;
private RequestQueue request;
JsonObjectRequest jsonObjectRequest;

TokenManager tokenManager;
private String tokenGoogle;
private String email_usuario;
private static final String KEY_EMAIL="email";
private static final String KEY_token="token";
private static final String URL_lOGIN="http://179.27.97.58:8080/laboratorio-web/rest/wsMobile/LoginGoogle";
boolean cor=false;

private GoogleApiClient googleApiClient;
private SignInButton signInButton;
public static final int SIGN_IN_CODE=777;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.login);
        tokenManager=new TokenManager(getApplicationContext());
        signInButton=findViewById(R.id.signin);

       GoogleSignInOptions gso= new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).
               requestIdToken(getString(R.string.default_web_client_id))
               .requestEmail()
               .build();



        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this,this)
                .addApi(Auth.GOOGLE_SIGN_IN_API,gso)
                .build();

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
                startActivityForResult(intent,SIGN_IN_CODE);

                LoginGoogle();



            }
        });
   }


    public void LoginGoogle() {
        final GoogleSignInAccount account= GoogleSignIn.getLastSignedInAccount(this);
        tokenGoogle= account.getIdToken();
        email_usuario=account.getEmail();

              Map<String,String>parametros= new HashMap<String,String>();
              parametros.put(KEY_token,tokenGoogle);

            JSONObject param= new JSONObject(parametros);
            JsonObjectRequest jsonObjectRequest= new JsonObjectRequest(Request.Method.POST,URL_lOGIN,param, new Response.Listener<JSONObject>(){

                @Override
                public void onResponse(JSONObject response) {
                    try{

                    JSONObject objres= new JSONObject(response.toString());
                    tokenManager.CreatedLoginSession(email_usuario,objres.toString());

                    Intent intentPrincipal = new Intent(Login.this, MainActivity.class);
                    startActivity(intentPrincipal);
                    }catch (JSONException e){

                    }

                }
            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    if (error instanceof AuthFailureError) {
                        Toast.makeText(getApplicationContext(),"Acceso Denegado, verifique Usuario y/o Password",Toast.LENGTH_LONG).show();
                        Intent intentPrincipal = new Intent(Login.this, Login.class);
                        startActivity(intentPrincipal);
                        }
                }
            });

            request=Volley.newRequestQueue(this);
            request.add(jsonObjectRequest);



      }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==SIGN_IN_CODE){

           GoogleSignInResult result= Auth.GoogleSignInApi.getSignInResultFromIntent(data);
        //   handleSignInResult(result);


        }
    }

    private void handleSignInResult(GoogleSignInResult result) {

      if(result.isSuccess()){
            goMainScreen();
      }else{
        Toast.makeText(this,"Failed",Toast.LENGTH_LONG).show();
      }


    }



    private void goMainScreen() {
        Intent intent=new Intent(this,MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }



}




