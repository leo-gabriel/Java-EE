package com.laboratorio.hechosdraps.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.laboratorio.hechosdraps.Login;
import com.laboratorio.hechosdraps.MainActivity;
import com.laboratorio.hechosdraps.R;
import com.laboratorio.hechosdraps.TokenManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link FragmentSolicitarFrase.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link FragmentSolicitarFrase#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentSolicitarFrase extends Fragment {


    private OnFragmentInteractionListener mListener;
    EditText titulo, link, fecha, medio, texto_frase, autor;
    Button buttonEnviar;
    Spinner area_frase;
    private RequestQueue request;
    private static final String URL_SOL_FRASE="http://179.27.97.58:8080/laboratorio-web/rest/wsMobile/addHecho";

    public FragmentSolicitarFrase() {
        // Required empty public constructor
    }


    public static FragmentSolicitarFrase newInstance(String param1, String param2) {
        FragmentSolicitarFrase fragment = new FragmentSolicitarFrase();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View vista= inflater.inflate(R.layout.fragment_fragment_solicitar_frase, container, false);
        area_frase = (Spinner) vista.findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.areas, android.R.layout.simple_spinner_item);
        area_frase.setAdapter(adapter);
        titulo = vista.findViewById(R.id.editTitulo);
        link = vista.findViewById(R.id.editTextLink);

        medio = vista.findViewById(R.id.editTextMedio);
        texto_frase = vista.findViewById(R.id.editTextFrase);
        autor = vista.findViewById(R.id.editTextAutor);
        buttonEnviar= vista.findViewById(R.id.buttonIngresar);
        request = Volley.newRequestQueue(getContext());
        buttonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SolicitarFrase();
                titulo.setText("");
                link.setText("");
                medio.setText("");
                texto_frase.setText("");
                autor.setText("");


            }
        });

        return vista;
    }

    public void SolicitarFrase() {
        Fragment miFragment=null;

        final String tituloFrase= titulo.getText().toString().trim();
        final String linkFrase= link.getText().toString().trim();
        final String veracidad= "VERACIDAD";
        final String medioFrase= medio.getText().toString().trim();
        final String textoFrase= texto_frase.getText().toString().trim();
        final String autorFrase= autor.getText().toString().trim();
        final String areaFrase= area_frase.getItemAtPosition(area_frase.getSelectedItemPosition()).toString().trim();
        final String estadoFrase= "NUEVO";


        String email_usuario= (String) TokenManager.getFromSharedPreferences("username").toString();
       final String token=(String) TokenManager.getFromSharedPreferences("jwttoken").toString();


        if(TextUtils.isEmpty(tituloFrase)){
            titulo.setError("Campo Obligatorio");
            titulo.requestFocus();
            return;
        }else if(Patterns.WEB_URL.matcher(linkFrase).find()==false){
            link.setError("Formato Invalido o Vacio");
            link.requestFocus();
            return;
        }else if(TextUtils.isEmpty(medioFrase)){
            medio.setError("Campo Obligatorio");
            medio.requestFocus();
            return;

        }else if(TextUtils.isEmpty(textoFrase)){
            texto_frase.setError("Campo Obligatorio");
            texto_frase.requestFocus();
            return;
        }else if(TextUtils.isEmpty(autorFrase)){
            autor.setError("Campo Obligatorio");
            autor.requestFocus();
            return;
        }


        Map<String,String> parametros= new HashMap<String,String>();
        parametros.put("titulo",tituloFrase);
        parametros.put("link",linkFrase);
        parametros.put("veracidad",veracidad);
        parametros.put("medio",medioFrase);
        parametros.put("frase",textoFrase);
        parametros.put("autor",autorFrase);
        parametros.put("area",areaFrase);
        parametros.put("estado",estadoFrase);

        parametros.put("emailusuario",email_usuario);


        JSONObject param= new JSONObject(parametros);
        JsonObjectRequest jsonObjectRequest= new JsonObjectRequest(Request.Method.POST,URL_SOL_FRASE,param, new Response.Listener<JSONObject>(){

            @Override
            public void onResponse(JSONObject response) {
                try{
                    JSONObject objres= new JSONObject(response.toString());


                }catch (JSONException e){

                }

            }
        },new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError error) {
                if (error instanceof AuthFailureError) {
                    Toast.makeText(getContext(),"Su sesión ha expirado, ingrese nuevamente",Toast.LENGTH_LONG).show();
                    Intent intentLogin = new Intent(getActivity(), Login.class);
                    startActivity(intentLogin);

                }
            }
        })
        {
            @Override
            public String getBodyContentType() {return "application/json; charset=UTF-8";}

          @Override
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("Content-Type", "application/json");
                headers.put("JWT",token);

                return headers;
            }
        };



        request.add(jsonObjectRequest);
        Toast.makeText(getContext(), "Hecho Creado", Toast.LENGTH_LONG).show();
        Intent intentPrincipal = new Intent(getActivity(), MainActivity.class);
        startActivity(intentPrincipal);



    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
