package com.laboratorio.hechosdraps;

import android.content.Context;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.laboratorio.hechosdraps.clases.Hecho;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DetalleHecho extends AppCompatActivity {
    TextView titulo, area, autor, frase, justificacion;
    ImageView imgHecho;

    private Context mContext;
    private JsonObjectRequest jsonObjectRequest;
    private RequestQueue request;
    private  String just="prueba";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_hecho);
        getSupportActionBar().hide();

        mContext = getApplicationContext();

        titulo = findViewById(R.id.aa_titulo_hecho);
        area = findViewById(R.id.aa_area_hecho);
        autor = findViewById(R.id.aa_autor);
        frase = findViewById(R.id.aa_frase);
        justificacion = findViewById(R.id.aa_justificacion);
        imgHecho = findViewById(R.id.aa_imagen_hecho);
        justificacion = findViewById(R.id.aa_justificacion);
        CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.collapsingtoolbar_id);
        collapsingToolbarLayout.setTitleEnabled(true);

        Bundle objetoEnviado = getIntent().getExtras();
        Hecho hecho_detalle = null;


        if (objetoEnviado != null) {
            hecho_detalle = (Hecho) objetoEnviado.getSerializable("hecho");


            if (hecho_detalle.getImagen() == null) {

                titulo.setText(hecho_detalle.getTitulo().toString());

                area.setText(hecho_detalle.getArea().toString());

                autor.setText(hecho_detalle.getAutor().toString());
                frase.setText(hecho_detalle.getFrase().toString());
                switch (hecho_detalle.getVeracidad()) {
                    case "VERDADERA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/verdadera_wilpt8.jpg").into(imgHecho);
                        break;
                    case "VERDAD_A_MEDIAS":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/vardadamedias_mq8yyw.jpg").into(imgHecho);
                        break;
                    case "INFLADA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/inflada_bmnouf.jpg").into(imgHecho);
                        break;
                    case "FALSA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/falsa_bmdyhd.jpg").into(imgHecho);
                        break;
                    case "RIDICULA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/ridicula_tlibti.jpg").into(imgHecho);
                        break;
                    case "ENGANIOSA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/enganiosa_hd4p1o.jpg").into(imgHecho);
                        break;
                }

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,"http://179.27.97.58:8080/laboratorio-web/rest/wsMobile/Verificacion/" + hecho_detalle.getId(), null,
                        new Response.Listener<JSONObject>(){
                            @Override
                            public void onResponse(JSONObject response) {

                                try {

                                  justificacion.setText(response.getString("justifiacion"));

                                } catch (JSONException e) {

                                }
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

                request = Volley.newRequestQueue(mContext.getApplicationContext());
                request.add(jsonObjectRequest);

                collapsingToolbarLayout.setTitle("Frase");

            } else {
                titulo.setText(hecho_detalle.getTitulo().toString());
                area.setText(hecho_detalle.getArea().toString());

                switch (hecho_detalle.getVeracidad()) {
                    case "VERDADERA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/verdadera_wilpt8.jpg").into(imgHecho);
                        break;
                    case "VERDAD_A_MEDIAS":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/vardadamedias_mq8yyw.jpg").into(imgHecho);
                        break;
                    case "INFLADA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/inflada_bmnouf.jpg").into(imgHecho);
                        break;
                    case "FALSA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/falsa_bmdyhd.jpg").into(imgHecho);
                        break;
                    case "RIDICULA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/ridicula_tlibti.jpg").into(imgHecho);
                        break;
                    case "ENGANIOSA":
                        Glide.with(mContext).load("https://res.cloudinary.com/cdnimages-hechosdraps/image/upload/v1561740370/enganiosa_hd4p1o.jpg").into(imgHecho);
                        break;
                }

                frase.setVisibility(View.INVISIBLE);
                autor.setVisibility(View.INVISIBLE);

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,"http://179.27.97.58:8080/laboratorio-web/rest/wsMobile/Verificacion/" + hecho_detalle.getId(), null,
                        new Response.Listener<JSONObject>(){
                            @Override
                            public void onResponse(JSONObject response) {

                                try {
                                    justificacion.setText(response.getString("justifiacion"));

                                } catch (JSONException e) {

                                }
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

                request = Volley.newRequestQueue(mContext.getApplicationContext());
                request.add(jsonObjectRequest);

                collapsingToolbarLayout.setTitle("Noticia");
            }


        }
    }


}

