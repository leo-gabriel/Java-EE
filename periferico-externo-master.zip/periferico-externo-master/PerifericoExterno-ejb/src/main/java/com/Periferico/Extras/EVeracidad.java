package com.Periferico.Extras;

public enum EVeracidad {
	
	VERDADERA, VERDAD_A_MEDIAS, INFLADA, ENGANIOSA, FALSA, RIDICULA, VERACIDAD;

}
