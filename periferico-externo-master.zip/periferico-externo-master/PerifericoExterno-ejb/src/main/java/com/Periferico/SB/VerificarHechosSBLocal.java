package com.Periferico.SB;

import java.util.List;

import javax.ejb.Local;

import com.Periferico.Extras.DTHecho;


@Local
public interface VerificarHechosSBLocal {
	public List<DTHecho> getListaHechosCalificar();
	public void agregarHecho(DTHecho hecho);
	public void calificarHecho(DTHecho hecho, com.laboratorio.Soap.EVeracidad veracidad, String justificacion)
			throws Exception;
}
