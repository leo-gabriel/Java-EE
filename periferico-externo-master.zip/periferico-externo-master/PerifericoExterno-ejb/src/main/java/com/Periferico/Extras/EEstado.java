package com.Periferico.Extras;

public enum EEstado {

	NUEVO, A_COMPROBAR, EN_PROCESO, VERIFICADO, PUBLICADO, CANCELADO
	
}
