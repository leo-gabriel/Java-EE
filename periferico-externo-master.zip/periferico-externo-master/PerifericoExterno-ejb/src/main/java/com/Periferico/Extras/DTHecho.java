package com.Periferico.Extras;

import java.util.Date;


public class DTHecho {
	
	private int id;
	private String titulo;
	private String link;
	private Date fecha;
	private String medio;
	private EEstado estado;
	private EArea area;
	private EVeracidad veracidad;
	private String email_usuario;
	private String frase;
	private String autor;
	private String imagen;
	
	public DTHecho() {}
	
	public DTHecho(String titulo,int id, String link, Date fecha, String medio, EEstado estado, EArea area, EVeracidad veracidad,
			String email_usuario, String frase, String autor, String imagen) {
		
		this.titulo=titulo;
		this.id = id;
		this.link = link;
		this.fecha = fecha;
		this.medio = medio;
		this.estado = estado;
		this.area = area;
		this.veracidad = veracidad;
		this.email_usuario = email_usuario;
		this.frase = frase;
		this.autor = autor;
		this.imagen = imagen;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail_usuario() {
		return email_usuario;
	}

	public void setEmail_usuario(String email_usuario) {
		this.email_usuario = email_usuario;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getMedio() {
		return medio;
	}

	public void setMedio(String medio) {
		this.medio = medio;
	}

	public EEstado getEstado() {
		return estado;
	}

	public void setEstado(EEstado estado) {
		this.estado = estado;
	}

	public EArea getArea() {
		return area;
	}

	public void setArea(EArea area) {
		this.area = area;
	}

	public EVeracidad getVeracidad() {
		return veracidad;
	}

	public void setVeracidad(EVeracidad veracidad) {
		this.veracidad = veracidad;
	}

	public String getUsuario() {
		return email_usuario;
	}

	public void setUsuario(String email_usuario) {
		this.email_usuario = email_usuario;
	}

	public String getFrase() {
		return frase;
	}

	public void setFrase(String frase) {
		this.frase = frase;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
	

}

