package com.Periferico.SB;

import javax.ejb.Local;

import com.Periferico.Extras.DTCalificacion;
import com.Periferico.Extras.DTHecho;

@Local
public interface VerificacionAutomaticaSBLocal {

	public DTCalificacion verificarHechoAutomatico(DTHecho hecho);

	public String obtenerPagina(String urlString);

	public DTCalificacion calificacionExterna(DTHecho hecho);

}
