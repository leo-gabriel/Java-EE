package com.Periferico.SB;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import com.Periferico.Extras.DTHecho;

/**
 * Message-Driven Bean implementation class for: verificacionProlongadaMDB
 */
@MessageDriven(
		activationConfig = { 
				@ActivationConfigProperty(
				propertyName = "destination", propertyValue = "java:/jms/queue/queue_ejercicio4"), @ActivationConfigProperty(
				propertyName = "destinationType", propertyValue = "javax.jms.Queue")
		},mappedName = "queue_ejercicio4")
public class verificacionProlongadaMDB implements MessageListener {

	@EJB
	private VerificarHechosSBLocal vhsb;

    public verificacionProlongadaMDB() {}

    
    public void onMessage(Message message) {
    	String msjEntrada;
		try {
			msjEntrada = ((TextMessage)message).getText();
			System.out.println(msjEntrada);
			String[] parts = msjEntrada.split("\\|");
			System.out.println(parts[0]);
			System.out.println(parts[1]);
			DTHecho aux = new DTHecho(parts[0],Integer.parseInt(parts[1]), null, null, null, null, null, null, null, null, null, null);
			vhsb.agregarHecho(aux);
		} catch (JMSException e) {
			e.printStackTrace();
		}


        
    }

}
