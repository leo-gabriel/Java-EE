package com.Periferico.SB;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import com.Periferico.Extras.DTHecho;
import com.Periferico.Extras.EArea;
import com.Periferico.Extras.EEstado;
import com.laboratorio.Soap.DtCalificacion;
import com.Periferico.Extras.EVeracidad;
import com.laboratorio.Soap.PerifericosWS;
import com.laboratorio.Soap.PerifericosWSService;





@Singleton
@Startup
@LocalBean
public class VerificarHechosSB implements VerificarHechosSBRemote, VerificarHechosSBLocal {
	
	private List<DTHecho> listaHechosCalificar;
	
    public VerificarHechosSB() {}
    
    @PostConstruct
    public void initialize(){
    	listaHechosCalificar = new ArrayList<DTHecho>();
    	listaHechosCalificar.add(new DTHecho("titulo", 0, "link", new Date(), "medio", EEstado.EN_PROCESO, EArea.ECONOMIA, EVeracidad.VERACIDAD, "email_usuario", "frase", "autor", "imagen"));
    	listaHechosCalificar.add(new DTHecho("titulo2", 1, "link2", new Date(), "medio2", EEstado.EN_PROCESO, EArea.ECONOMIA, EVeracidad.VERACIDAD, "email_usuario2", "frase2", "autor2", "imagen2"));
    }
    
    public List<DTHecho> getListaHechosCalificar(){
    	return listaHechosCalificar;
    }
     
    public void agregarHecho(DTHecho hecho) {
    	listaHechosCalificar.add(hecho);
    }
    @Override
    public void calificarHecho(DTHecho hecho, com.laboratorio.Soap.EVeracidad veracidad, String justificacion) throws Exception {
		PerifericosWSService perifericoWSService = new PerifericosWSService();
		PerifericosWS perifericoWS = perifericoWSService.getPerifericosWSPort(); 
		DtCalificacion dtc = new DtCalificacion();
		dtc.setIdHecho(hecho.getId());
		dtc.setVeracidad(veracidad);
		dtc.setJustificacion(justificacion);
		sacarHecho(dtc.getIdHecho());
		perifericoWS.recibirCalificacion(dtc);
    }
    
    public void sacarHecho(int idHecho) {
    	int i = 0;
    	Boolean salir = false;
    	while(i < listaHechosCalificar.size() && salir == false) {
    		if(idHecho == listaHechosCalificar.get(i).getId()) {
    			listaHechosCalificar.remove(i);
    			salir = true;
    		}	
    		else
    			i++;
    	}
    }
    
}
