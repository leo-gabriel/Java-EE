package com.Periferico.Extras;

public class DTCalificacion {
	int idHecho;
	com.laboratorio.Soap.EVeracidad veracidad;
	String justificacion;
	
	
	public DTCalificacion() {
		super();
	}
	public DTCalificacion(int idHecho, com.laboratorio.Soap.EVeracidad veracidad, String justificacion) {
		super();
		this.idHecho = idHecho;
		this.veracidad = veracidad;
		this.justificacion = justificacion;
	}
	public int getIdHecho() {
		return idHecho;
	}
	public void setIdHecho(int idHecho) {
		this.idHecho = idHecho;
	}
	public com.laboratorio.Soap.EVeracidad getVeracidad() {
		return veracidad;
	}
	public void setVeracidad(com.laboratorio.Soap.EVeracidad veracidad) {
		this.veracidad = veracidad;
	}
	public String getJustificacion() {
		return justificacion;
	}
	public void setJustificacion(String justificacion) {
		this.justificacion = justificacion;
	}
}
