package com.Periferico.SB;

import javax.ejb.Remote;

@Remote
public interface VerificacionAutomaticaSBRemote {

}
