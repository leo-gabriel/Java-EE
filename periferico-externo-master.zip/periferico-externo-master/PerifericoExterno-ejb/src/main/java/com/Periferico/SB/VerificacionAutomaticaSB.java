package com.Periferico.SB;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;
import java.util.regex.Pattern;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.Periferico.Extras.DTCalificacion;
import com.Periferico.Extras.DTHecho;
import com.laboratorio.Soap.EVeracidad;




/**
 * Session Bean implementation class verificacionAutomaticaSB
 */
@Stateless
@LocalBean
public class VerificacionAutomaticaSB implements VerificacionAutomaticaSBRemote, VerificacionAutomaticaSBLocal {

    /**
     * Default constructor. 
     */
    public VerificacionAutomaticaSB() {
        // TODO Auto-generated constructor stub
    }
    
    public DTCalificacion verificarHechoAutomatico(DTHecho hecho) {
    	Random rand = new Random();
		int cant = rand.nextInt(6) + 1;
    	DTCalificacion calificacion = new DTCalificacion();
    	calificacion.setIdHecho(hecho.getId());
    	calificacion.setJustificacion("Justificacion automatica");
		if(cant == 1)
			calificacion.setVeracidad(EVeracidad.RIDICULA);
		else if(cant == 2)
			calificacion.setVeracidad(EVeracidad.FALSA);
		else if(cant == 3)
			calificacion.setVeracidad(EVeracidad.ENGANIOSA);
		else if(cant == 4)
			calificacion.setVeracidad(EVeracidad.INFLADA);
		else if(cant == 5)
			calificacion.setVeracidad(EVeracidad.VERDAD_A_MEDIAS);
		else
			calificacion.setVeracidad(EVeracidad.VERDADERA);
		return calificacion;
    }
    
    @Override
    public DTCalificacion calificacionExterna(DTHecho hecho) {
    	System.out.println(hecho.getId());
    	String pagina = obtenerPagina("https://www.montevideo.com.uy/categoria/Noticias-310");
    	String titulo = ".*" + hecho.getTitulo() + ".*";
    	boolean encontre = Pattern.matches(titulo, pagina);
    	if(encontre)
    		return new DTCalificacion(hecho.getId(), EVeracidad.VERDADERA, "Verificado por Montevideo Portal");
    	else {
    		pagina = obtenerPagina("https://www.elobservador.com.uy");
    		encontre = Pattern.matches(titulo, pagina);
    		if(encontre)
    			return new DTCalificacion(hecho.getId(), EVeracidad.VERDADERA, "Verificado por El Observador");
    		else {
    			pagina = obtenerPagina("https://www.elpais.com.uy/informacion");
    			encontre = Pattern.matches(titulo, pagina);
    			if(encontre)
    				return new DTCalificacion(hecho.getId(), EVeracidad.VERDADERA, "Verificado por El Pais");
    			else {
    				pagina = obtenerPagina("https://ladiaria.com.uy/masleidos/");
        			encontre = Pattern.matches(titulo, pagina);
        			if(encontre)
        				return new DTCalificacion(hecho.getId(), EVeracidad.VERDADERA, "Verificado por La Diaria");
        			else 
        				return new DTCalificacion(hecho.getId(), EVeracidad.ENGANIOSA, "Verificado");
    			}
    		}
    	}
    }
    
    @Override
    public String obtenerPagina(String urlString){
        String result = "";
        try {
         URL url = new URL(urlString);
         BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
         String str;
         while ((str = in.readLine()) != null) 
             result += str;
         
         in.close();             
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }          
        return result;
    }
}
