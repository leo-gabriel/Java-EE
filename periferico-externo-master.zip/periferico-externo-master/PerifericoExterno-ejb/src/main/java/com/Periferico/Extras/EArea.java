package com.Periferico.Extras;

public enum EArea {

	POLITICA, SALUD, ECONOMIA;

}
