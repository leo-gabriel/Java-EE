@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.laboratorio.com/")
package com.laboratorio.Soap;
