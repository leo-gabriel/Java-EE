package com.Periferico.WebServices;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ejb.EJB;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;

import com.Periferico.Extras.DTCalificacion;
import com.Periferico.Extras.DTHecho;
import com.Periferico.SB.VerificacionAutomaticaSBLocal;
import com.Periferico.SB.VerificarHechosSBLocal;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC)
public class Soap {
	@EJB
	private VerificarHechosSBLocal vhsb;
	
	@EJB
	private VerificacionAutomaticaSBLocal vasb;
	
	@WebMethod
	public void agregarHecho(DTHecho hecho) {
		try {
			Context context;
			context = new InitialContext();
			Queue queue;
			queue = (Queue) context.lookup("java:/jms/queue/queue_ejercicio4");
			QueueConnectionFactory factory = (QueueConnectionFactory) context.lookup("ConnectionFactory");
			QueueConnection queueConnection = factory.createQueueConnection();
			QueueSession queueSession = queueConnection.createQueueSession(false, QueueSession.AUTO_ACKNOWLEDGE);
			TextMessage textMessage = queueSession.createTextMessage(hecho.getTitulo() + hecho.getId());
			QueueSender queueSender = queueSession.createSender(queue);
			queueSender.send(textMessage);
		} catch (NamingException | JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		vhsb.agregarHecho(hecho);
	}
	
	@WebMethod 
	public DTCalificacion verificarHechoAutomatico(DTHecho hecho) {
		return vasb.verificarHechoAutomatico(hecho);
	}
	
}
