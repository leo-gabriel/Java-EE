package com.Periferico.Json;


public class JsonCalificacion {
	int idHecho;
	String veracidad;
	String justificacion;
	public JsonCalificacion() {
		super();
	}
	public JsonCalificacion(int idHecho, String veracidad, String justificacion) {
		super();
		this.idHecho = idHecho;
		this.veracidad = veracidad;
		this.justificacion = justificacion;
	}
	public int getIdHecho() {
		return idHecho;
	}
	public void setIdHecho(int idHecho) {
		this.idHecho = idHecho;
	}
	public String getVeracidad() {
		return veracidad;
	}
	public void setVeracidad(String veracidad) {
		this.veracidad = veracidad;
	}
	public String getJustificacion() {
		return justificacion;
	}
	public void setJustificacion(String justificacion) {
		this.justificacion = justificacion;
	}
	
}
