package com.Periferico.Json;

public class JsonHecho {

	
String titulo;
private	int id;
private String link;
private	String fecha;
private	String medio;
private	String estado;
private	String area;
private	String veracidad;
private	String emailusuario;
private	String frase;
private	String autor;
private	String imagen;



public JsonHecho() {
	
}

public JsonHecho(String titulo,int id, String link, String fecha, String medio, String estado, String area, String veracidad,
		String emailusuario, String frase, String autor, String imagen) {
	this.titulo=titulo;
	this.id = id;
	this.link = link;
	this.fecha = fecha;
	this.medio = medio;
	this.estado = estado;
	this.area = area;
	this.veracidad = veracidad;
	this.emailusuario = emailusuario;
	this.frase = frase;
	this.autor = autor;
	this.imagen = imagen;
}


public String getTitulo() {
	return titulo;
}

public void setTitulo(String titulo) {
	this.titulo = titulo;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getLink() {
	return link;
}

public void setLink(String link) {
	this.link = link;
}

public String getFecha() {
	return fecha;
}

public void setFecha(String fecha) {
	this.fecha = fecha;
}

public String getMedio() {
	return medio;
}

public void setMedio(String medio) {
	this.medio = medio;
}

public String getEstado() {
	return estado;
}

public void setEstado(String estado) {
	this.estado = estado;
}

public String getArea() {
	return area;
}

public void setArea(String area) {
	this.area = area;
}

public String getVeracidad() {
	return veracidad;
}

public void setVeracidad(String veracidad) {
	this.veracidad = veracidad;
}

public String getEmailusuario() {
	return emailusuario;
}

public void setEmailusuario(String emailusuario) {
	this.emailusuario = emailusuario;
}

public String getFrase() {
	return frase;
}

public void setFrase(String frase) {
	this.frase = frase;
}

public String getAutor() {
	return autor;
}

public void setAutor(String autor) {
	this.autor = autor;
}

public String getImagen() {
	return imagen;
}

public void setImagen(String imagen) {
	this.imagen = imagen;
}









}
