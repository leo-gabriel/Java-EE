package com.Periferico.Rest;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.Periferico.Extras.DTCalificacion;
import com.Periferico.Extras.DTHecho;
import com.Periferico.Json.JsonCalificacion;
import com.Periferico.Json.JsonHecho;
import com.Periferico.SB.VerificacionAutomaticaSBLocal;

@Path("/wsPeriferico")
public class Rest {
	@EJB
	private VerificacionAutomaticaSBLocal vhsb;
	
	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	@Path("/verificarexterno")
	public JsonCalificacion calificarHecho(JsonHecho hecho) {
		DTHecho aux = new DTHecho(hecho.getTitulo(), hecho.getId(), null, null, null, null, null, null, null, null, null, null);
		DTCalificacion calificacion = vhsb.calificacionExterna(aux);
		System.out.println(calificacion.getIdHecho());
		return new JsonCalificacion(calificacion.getIdHecho(),calificacion.getVeracidad().toString(), calificacion.getJustificacion());
	}
}
