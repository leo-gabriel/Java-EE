package com.Periferico.Servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Periferico.Extras.DTHecho;
import com.Periferico.Extras.EVeracidad;
import com.Periferico.SB.VerificacionAutomaticaSBLocal;


/**
 * Servlet implementation class prueba
 */
public class prueba extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	VerificacionAutomaticaSBLocal coso;   
	
	
	
    public prueba() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(EVeracidad.VERDADERA.toString());
		System.out.println(coso.calificacionExterna(new DTHecho("Talvi denunciará a Sartori por repartir tarjetas que prometen medicamentos gratis", 0, null, null, null, null, null, null, null, null, null, null)).getJustificacion());
		System.out.println(coso.calificacionExterna(new DTHecho("Aníbal Lavandeira, el uruguayo que correrá 500 kilómetros", 0, null, null, null, null, null, null, null, null, null, null)).getJustificacion());
		System.out.println(coso.calificacionExterna(new DTHecho("Extienden alerta naranja para gran parte del país por tormentas y lluvias", 0, null, null, null, null, null, null, null, null, null, null)).getJustificacion());
		System.out.println(coso.calificacionExterna(new DTHecho("Lacalle Pou reconoció que Sartori lo financió en la interna de 2014", 0, null, null, null, null, null, null, null, null, null, null)).getJustificacion());
		System.out.println(coso.calificacionExterna(new DTHecho("asdasdasd", 0, null, null, null, null, null, null, null, null, null, null)).getJustificacion());
	}

}
