package com.laboratorio.mbperiferico;


import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.Periferico.Extras.DTHecho;
import com.Periferico.Extras.DTCalificacion;
import com.Periferico.SB.VerificarHechosSB;
import com.laboratorio.Soap.EVeracidad;



@ManagedBean(name = "periferico")
@SessionScoped

public class mbperiferico{
	
	private List<DTHecho> hechos;
	private DTHecho h;
	private DTCalificacion cal;
	private EVeracidad veracidad;
	private String justificacion;
	private int idHecho;
    public mbperiferico() {
    	this.justificacion = null;
    	this.veracidad = EVeracidad.VERDADERA;
    	this.h = new DTHecho(); 
    }
    
    @EJB    
    private VerificarHechosSB sb;
    
    
    
    public List<DTHecho> getHechos(){
    	
    	hechos = sb.getListaHechosCalificar();
    	return hechos;
    }    
    
    public void setHechos(List<DTHecho> hechos) {
		this.hechos = hechos;
	}

	public DTHecho getH() {
		return h;
	}

	public void setH(DTHecho hecho) {
		this.h = hecho;
	}
	
	public void buttonAction(){
        try {
        	h.setId(this.idHecho);
        	System.out.println(h.getId());
			sb.calificarHecho(h, veracidad,justificacion);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	public DTCalificacion getCal() {
		return cal;
	}

	public void setCal(DTCalificacion cal) {
		this.cal = cal;
	}

	public EVeracidad getVeracidad() {
		return veracidad;
	}

	public void setVeracidad(EVeracidad veracidad) {
		this.veracidad = veracidad;
	}

	public String getJustificacion() {
		return justificacion;
	}

	public void setJustificacion(String justificacion) {
		this.justificacion = justificacion;
	}

	public int getIdHecho() {
		return idHecho;
	}

	public void setIdHecho(int idHecho) {
		this.idHecho = idHecho;
	}
    
    
}