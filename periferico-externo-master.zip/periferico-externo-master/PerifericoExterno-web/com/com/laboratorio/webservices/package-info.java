@javax.xml.bind.annotation.XmlSchema(namespace = "http://WebServices.laboratorio.com/")
package com.laboratorio.webservices;
