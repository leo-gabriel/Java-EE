import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { Usuario } from '../clases/Usuario';
import { TokenDecoded } from '../clases/token';

import * as jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  usuario= new Usuario();
  username: string;
  passwd: string;
  resultado: boolean;
  mensaje: string;

  constructor( private cookieService: CookieService,private Auth :AuthService, private router: Router) { }

  
  ngOnInit( ) {
    if(this.cookieService.get("backoffice-cookie")){
      this.router.navigate(["home"]);
    }
  }



  loginUser(event){
    const target = event.target
    const usuario= target.querySelector('#usuario').value
    const password= target.querySelector('#password').value
 
    this.Auth.autenticar(usuario,password).subscribe(
      (response: any) => {
        let resp = response.JWT;
        let token: TokenDecoded = jwt_decode(resp);
        if (token != null) {
          this.Auth.setToken(resp);
          this.router.navigate(["home"]);
          
        } else {
          this.resultado = false;
          this.mensaje = 'no tienes permisos para ingresar aquí con tu usuario.';
          console.log("entre else");
        }
      },
      (err) => {
        this.resultado = false;
        if (err.status == 401)
          this.mensaje = 'usuario, email o contraseña incorrectos.';
        else
          this.mensaje = 'lo sentimos, parece que hubo un problema de nuestro lado.' +
            'Vuelve a intentarlo luego.';
      }
    );

   
  }

}
