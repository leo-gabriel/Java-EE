import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { UsuarioService } from '../services/usuario.service';
import { Usuario } from '../clases/usuario.model';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./login.component.css']
})
export class RegisterComponent implements OnInit {

  forma: FormGroup;

  constructor(private auth:AuthService, private _usuarioService: UsuarioService, private route:Router) { }

  ngOnInit() {
    if(this.auth.getToken() == null){
      this.route.navigate(["login"]);
      }
    this.forma = new FormGroup({
      username: new FormControl(null, Validators.required),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, Validators.required),
      ci: new FormControl(null, Validators.required),
      tipo: new FormControl(null, Validators.required),
    });
  }
    registrarUsuario(){
      console.log(this.forma.value);
  
        let usuario = new Usuario(
        this.forma.value.username, 
        this.forma.value.email, 
        this.forma.value.password, 
        this.forma.value.ci,
        this.forma.value.tipo
  
        
      );
      
  
      this._usuarioService.crearUsuario( usuario )
        .subscribe( resp => {
          console.log( resp );
          this.route.navigate(["dashboard"]);
          
        });
  
    }

 

}
