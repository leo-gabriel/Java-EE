import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { SelectMultipleControlValueAccessor } from '@angular/forms';
import { delay } from 'q';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styles: []
})
export class HeaderComponent implements OnInit {
  resp: import("../../clases/token").TokenDecoded;
  

  constructor(private auth:AuthService, private cookies:CookieService,private route:Router) { }

  ngOnInit() {
    this.resp = this.auth.getToken();
    if (this.resp != null && this.auth.isTokenExpired()){
      this.cookies.delete("backoffice-cookie");
      window.location.reload();
    }
    
   
  }

  logout(){
    this.cookies.delete("backoffice-cookie");
    window.location.reload();
  }
}
