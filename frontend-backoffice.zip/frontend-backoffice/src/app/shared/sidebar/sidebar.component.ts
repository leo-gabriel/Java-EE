import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styles: []
})
export class SidebarComponent implements OnInit {

  resp: any;

  constructor(private auth:AuthService) { }

  ngOnInit() {
    this.resp = this.auth.getToken();

  }

}
