import { Component, OnInit } from '@angular/core';
import { Hecho } from '../../clases/Hecho';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { Usuario } from '../../clases/Usuario';
import { HechosService } from '../../services/hechos.service';
import { AuthService } from '../../services/auth.service';
import { filtro } from '../../clases/filtro';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styles: []
})


export class DashboardComponent implements OnInit {

  num_pag: number = 1;
  hechos :Hecho;
  idHecho : number;
  hecho : Hecho;
  usuario:Usuario;
  resp: any;
  estadoPer: boolean;
  filtro: filtro;

  

  constructor(private cookieService:CookieService,private service:HechosService,private auth:AuthService, private route:Router) { }
  
  ngOnInit() {
    
    if(this.auth.getToken() == null){
     this.route.navigate(["login"]);
     }
    this.resp = this.auth.getToken();

     this.filtro = new filtro();
    if (this.resp.tipousuario == "DTChecker"){
      this.filtro.usuario = this.resp.sub;
      this.service.getHechos(this.filtro).subscribe((data:Hecho) => {this.hechos = data; console.log(data);});
    }else{
    this.service.getHechos(this.filtro).subscribe((data:Hecho) => {this.hechos = data; console.log(data);});
    }
    this.estadoPer = true;
  }

  datosHecho(numero:number){
    this.service.changeMessage(numero);   
  }
  verificarHecho(numero:number){
    this.service.changeMessage(numero);   
 }

 PUBLICARHecho(numero:number,area:string){
   
  this.service.PUBLICARHecho(numero,this.auth.getToken().sub,area).subscribe();
  window.location.reload();
 }

 tomarhechoVerificar(numero:number){
   this.service.changeMessage(numero);
   this.service.EN_PROCESOHecho(numero).subscribe();
   window.location.reload();
 }

 cambiarEstadoPeriferico(){

    this.estadoPer = !this.estadoPer;
 }



 

 
}
  
  

  

  
