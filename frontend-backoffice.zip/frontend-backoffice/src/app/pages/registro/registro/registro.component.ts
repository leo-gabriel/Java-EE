import { Component, OnInit } from '@angular/core';
import { Hecho1 } from '../../../clases/Hecho.1';
import { HechosService } from '../../../services/hechos.service';
import { AuthService } from '../../../services/auth.service';
import { FileUploader, FileUploaderOptions, ParsedResponseHeaders } from 'ng2-file-upload';
import { Router } from '@angular/router';


@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: []
})
export class RegistroComponent implements OnInit {

  hechoModel = new Hecho1();
  estado: String;
  veracidad: String;
  urlimagen: String;
  resp: any;  
  public uploader: FileUploader;
  constructor(private _hechoservice: HechosService, private auth:AuthService,private route:Router) { }

  ngOnInit() {

    if(this.auth.getToken() == null){
      this.route.navigate(["login"]);
      }
    this.estado = "NUEVO";
    this.veracidad = "VERACIDAD";
    this.urlimagen = null;
    this.resp = this.auth.getToken();

    const uploaderOptions: FileUploaderOptions = {
      url: `https://api.cloudinary.com/v1_1/cdnimages-hechosdraps/image/upload`,
      autoUpload: false, // Cargar archivos automáticamente al agregarlos a la cola de carga
      isHTML5: true, // Use xhrTransport a favor de iframeTransport
      removeAfterUpload: true, // Calcule el progreso de forma independiente para cada archivo cargado
      headers: [ // XHR request headers
        {
          name: 'X-Requested-With',
          value: 'XMLHttpRequest'
        }
      ]
    };

    const upsertResponse = fileItem => {
      // Check if HTTP request was successful
      if (fileItem.status !== 200) {
        console.log('Upload to cloudinary Failed');
        console.log(fileItem);
        return false;
      }
      console.log(fileItem);
      console.log(fileItem.data.url);
      this.urlimagen = fileItem.data.url;

    }

    this.uploader = new FileUploader(uploaderOptions);
    this.uploader.onBuildItemForm = (fileItem: any, form: FormData): any => {
      // Agregue el preajuste de carga sin firmar de Cloudinary al formulario de carga
      form.append('upload_preset', 'hechosdraps');
      // Usar el valor predeterminado "withCredentials" para las solicitudes CORS
      fileItem.withCredentials = false;
      return { fileItem, form };
    }

    this.uploader.onCompleteItem = (item: any, response: string, status: number, headers: ParsedResponseHeaders) =>
      upsertResponse(
        {
          file: item.file, status,
          data: JSON.parse(response),
        }
      );
    
  }

  guardar(){

    this.hechoModel.estado = this.estado;
    this.hechoModel.veracidad = this.veracidad;
    this.hechoModel.emailusuario = this.resp.sub;
    this.hechoModel.imagen = this.urlimagen;
    this._hechoservice.CrearHecho(this.hechoModel).subscribe();
    setTimeout(() => {this.route.navigate(["home"])},5000);
    
  }


}



