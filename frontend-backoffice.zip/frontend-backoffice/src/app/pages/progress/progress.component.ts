import { Component, OnInit, ViewChild } from '@angular/core';
import { Usuario } from '../../clases/Usuario';
import { Hecho } from '../../clases/Hecho';
import { Router } from '@angular/router';
import { HechosService } from '../../services/hechos.service';
import { CookieService } from 'ngx-cookie-service';
import { AuthService } from '../../services/auth.service';
import { EVeracidad } from '../../Enum/EVeracidad';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styles: []
})
export class ProgressComponent implements OnInit {

  idHecho: number;
  hecho: any;
  checkers: Usuario;
  checker:Usuario;
  email:String;
  calificacion:String;
  veracidad:EVeracidad;
  entre: boolean;
  token: any;
  opinion: any;
  resp: any;  
  carga : boolean;
  carga1 : boolean;
  mostrarVerificacion : boolean;
  noVerificado: boolean;
  isVerificado : boolean;
  carga2: boolean;
  borrar : boolean;
  
  constructor(private route:Router,private service:HechosService, private cookieService:CookieService, private auth:AuthService){ }

  ngOnInit() {
    
    if(this.auth.getToken() == null){
      this.route.navigate(["login"]);
      }

    this.token = this.auth.getToken();
    this.veracidad = null;
    this.calificacion = null;

    this.service.currentMessage.subscribe(data => {this.idHecho = data;});
    this.service.getHecho(this.idHecho).subscribe(data => {this.hecho = data;
      if ((this.hecho.estado == 'VERIFICADO')){
      this.service.ObtenerVerificacion(this.hecho.emailusuario,this.idHecho).subscribe(data => {this.opinion = data;console.log(data);
      });
      
      
    }
    });
 
    
    this.service.getCheckers().subscribe((data:Usuario) => {this.checkers = data});
    
    this.carga = true;  
    this.carga1 = true;
    this. mostrarVerificacion = false;  
    this.noVerificado = false;
    this.isVerificado = false;
    this.borrar=true;
  }

  
  a_comprobarHecho(numero:number){ 
    this.service.A_COMPROBARHecho(numero,this.email).subscribe();
    setTimeout(() => {this.route.navigate(["home"])},5000);
  }

  VERIFICARHecho(numero:number){    
    this.service.VERIFICARHecho(numero,this.veracidad,this.calificacion).subscribe();
    setTimeout(() => {this.route.navigate(["home"])},5000);
 }

 BorrarHecho(id:number,email:string){

  this.service.BorrarHecho(email,id).subscribe()
 }

 verificacionexterna(h:Hecho){
  this.carga = !this.carga;
   this.service.verificacionexterna(h).subscribe(response => {setTimeout(() => {},5000);
      this.resp = response;
      this.carga = !this.carga;
      this. mostrarVerificacion = !this.mostrarVerificacion;
      this.borrar=false;
      console.log(this.resp);
      
    }
    );
   
   
 }

 verificacionautomatizada(h:Hecho){
  this.carga1 = !this.carga1;
  this.service.verificacionautomatizada(h).subscribe(response => {setTimeout(() => {},5000);
  this.resp = response;
  this.carga1 = !this.carga1;
  this. mostrarVerificacion = !this.mostrarVerificacion;
  this.borrar=false;
  console.log(this.resp);
  
}
);
 }
verificacionprolongada(h:Hecho){
  this.carga = !this.carga;
  this.service.verificacionprolongada(h).subscribe(response => {setTimeout(() => {},15000);
  this.resp = response;  
  this.carga = !this.carga;
  this.carga2 = true;
  
}
);

 }

 isverificada(id:number){

  this.service.isverificada(id).subscribe(response => {
    this.resp = response;
    if (this.resp != null){       
      this.isVerificado = true;
      this.noVerificado = false; 
      this.carga2 = false;
      this.borrar=false;           
    }else{
      this.noVerificado = true;
      this.isVerificado = false;
      
    }
    
    console.log(response);
  }
  )


 }

}



  

  


