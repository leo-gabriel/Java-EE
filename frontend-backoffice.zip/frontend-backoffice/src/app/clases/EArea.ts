export enum EArea {

    POLITICA = 0,
    SALUD,
    ECONOMIA
}