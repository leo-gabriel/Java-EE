import {EArea} from '../Enum/EArea';
import {EVeracidad} from '../Enum/EVeracidad';
import {EEstado} from '../Enum/EEstado'; 

export class Hecho{

	id : Number;	
    link : String;
	fecha : Date;
	medio : String;    	
	veracidad :EVeracidad;
	estado : EEstado;
	area : EArea;
	emailusuario: String;
	usuario: String;
	frase: String;
	autor:String;
	imagen : String;
	titulo : String;
}