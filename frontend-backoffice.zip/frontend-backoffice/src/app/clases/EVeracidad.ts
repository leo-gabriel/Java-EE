export enum EVeracidad {

    VERDADERA = 0,
    VERDAD_A_MEDIAS,
    INFLADA,
    ENGANIOSA,
    FALSA,
    RIDICULA,
    VERACIDAD
	
}