import { EVeracidad } from "../Enum/EVeracidad";

export class BodyRequest{

    veracidad:EVeracidad;
    calificacion:String;
}