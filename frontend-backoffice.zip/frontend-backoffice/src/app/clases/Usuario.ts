import { TipoUsuario } from "./TipoUsuario";

export class Usuario{
    id:number;
    tipo:TipoUsuario;
    user_name:String;
    email: string;
    ci:number;
}