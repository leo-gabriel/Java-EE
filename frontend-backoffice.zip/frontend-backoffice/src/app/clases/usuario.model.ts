export class Usuario{

    constructor(
        public username: string,
        public email: string,
        public password: string,
        public ci: number,
        public tipo: String,
        public id?: number
    ){}
}
