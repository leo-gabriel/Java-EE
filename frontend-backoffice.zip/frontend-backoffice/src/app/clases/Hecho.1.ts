

export class Hecho1{

	id : Number;	
    link : String;
	fecha : Date;
	medio : String;    	
	veracidad :String;
	estado : String;
	area : String;
	emailusuario: String;
	usuario: String;
	frase: String;
	autor:String;
	imagen : String;
	titulo : String;
}