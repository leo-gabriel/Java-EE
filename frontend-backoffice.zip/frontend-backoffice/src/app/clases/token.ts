export class TokenDecoded {
    tipoUsuario: string;    
    sub: string;
    nbf: number;
    exp: number;
    iat: number;
    iss: string;
    aud: string;
  }