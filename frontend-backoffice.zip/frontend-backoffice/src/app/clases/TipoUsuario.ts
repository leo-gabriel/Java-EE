export enum TipoUsuario {

    Citizen,
    Checker,
    Submitter,
    Admin

}