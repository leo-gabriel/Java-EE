export enum EEstado {

    NUEVO = 0,
    A_COMPROBAR,
    EN_PROCESO,
    VERIFICADO,
    PUBLICADO,
    CANCELADO
	
}