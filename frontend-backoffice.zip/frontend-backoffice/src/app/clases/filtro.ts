export class filtro{

	estado: String;
	tipo: String;
	usuario:String;
	veracidad: String;
	area: String;
	
}