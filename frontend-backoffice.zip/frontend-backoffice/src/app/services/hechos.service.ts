import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient} from '@angular/common/http';
import { environment } from '../../environments/environment';
import { BehaviorSubject } from 'rxjs';
import { Hecho1 } from '../clases/Hecho.1';
import { AuthService } from './auth.service';
import { EEstado } from '../Enum/EEstado';
import { EArea } from '../Enum/EArea';
import { filtro } from '../clases/filtro';
import { EVeracidad } from '../Enum/EVeracidad';
import { Hecho } from '../clases/Hecho';

@Injectable({
  providedIn: 'root'
})
export class HechosService {

  private dominio = "http://" + environment.dominio_api;
  
  private messageSource = new BehaviorSubject<number>(null);
  currentMessage = this.messageSource.asObservable();

  constructor(private http: HttpClient, private auth:AuthService) { 
    
    }

  changeMessage(message:number){
      this.messageSource.next(message);
  }

  public getHechos(filtro:filtro) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'

      })
    }
    
    const url = this.dominio + '/laboratorio-web/rest/wsHecho/listadoDeHechos' ;
    return this.http.post(url,filtro, httpOptions);
  }

  public getHecho(idHecho:number) { 
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    const url = this.dominio + '/laboratorio-web/rest/RestServices/Hecho/'+ idHecho;    
    return this.http.get(url, httpOptions);
  }

  public getCheckers(){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    const url = this.dominio + '/laboratorio-web/rest/RestServices/Usuarios/Checkers';
    return this.http.get(url, httpOptions);
  }

  public  A_COMPROBARHecho(idHecho:number,email:String) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    
    const url = this.dominio + '/laboratorio-web/rest/RestServices/Hecho/UpdateA_COMPROBAR/'+ idHecho;
        
    return this.http.put(url,{email},httpOptions);
  }

  public EN_PROCESOHecho(idHecho:number){
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      }
      
      const url = this.dominio + '/laboratorio-web/rest/RestServices/Hecho/UpdateEN_PROCESO/'+ idHecho;
      return this.http.put(url,httpOptions);

    }

    public VERIFICARHecho(idHecho:number,veracidad:EVeracidad,calificacion:String){
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      }
      
      const url = this.dominio + '/laboratorio-web/rest/RestServices/Hecho/UpdateVERIFICADO/'+ idHecho;
      return this.http.put(url,{veracidad,calificacion},httpOptions);
      

    }

  public PUBLICARHecho(idHecho:number,email:String,area:String){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    
    
    const url = this.dominio + '/laboratorio-web/rest/RestServices/Hecho/UpdatePUBLICAR/'+ idHecho;
    return this.http.put(url,{email,area},httpOptions);

  }

  public CrearHecho(hecho:Hecho1){

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }

    const url = this.dominio + '/laboratorio-web/rest/wsHecho/addHecho';
    console.log(hecho);
    
    
    return this.http.post(url,hecho,httpOptions);
  }

  public ObtenerVerificacion(email:String, id:number ){

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }

    const url = this.dominio + '/laboratorio-web/rest/RestServices/Verificacion/' + id;    
    console.log("entre");

    return this.http.get(url,httpOptions);
  }

  public BorrarHecho(email:String, id:number){

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }

    const url = this.dominio + '/laboratorio-web/rest/RestServices/BorrarHecho/' + email + '/' + id ;    
    console.log("hola");
    
    return this.http.delete(url,httpOptions);

  }

  
  public verificacionexterna(h:Hecho) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }

    const url = this.dominio + '/PerifericoExterno-web/rest/wsPeriferico/verificarexterno'; 

    return this.http.post(url,h,httpOptions);
    
  }

  public verificacionautomatizada(h:Hecho) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }

    const url = this.dominio + '/laboratorio-web/rest/wsHecho/verificarautomatico'; 

    return this.http.post(url,h,httpOptions);
    
  }

  public verificacionprolongada(h:Hecho) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }

    const url = this.dominio + '/laboratorio-web/rest/wsHecho/verificarprolongado'; 

    return this.http.post(url,h,httpOptions);
    
  }

  public isverificada(id:number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }

    const url = this.dominio + '/laboratorio-web/rest/wsHecho/isVerificada/' + id; 

    return this.http.get(url,httpOptions);
    
  }
  

}
