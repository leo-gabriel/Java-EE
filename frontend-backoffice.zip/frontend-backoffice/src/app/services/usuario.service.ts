import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Usuario } from '../clases/usuario.model';
import { environment } from '../../../src/environments/environment';

@Injectable()
export class UsuarioService {

  private dominio = "http://" + environment.dominio_api;
  constructor(
    public http: HttpClient
  ) { 
    console.log("servicio del usuario listo");
  }

  crearUsuario( usuario: Usuario ) {
    
    const url = this.dominio + '/laboratorio-web/rest/wsUsuario/registro';
    
    return this.http.post( url ,usuario);

  }
}
