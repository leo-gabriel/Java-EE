import { Injectable } from '@angular/core';
import {HttpHeaders,HttpClient, HttpClientModule} from '@angular/common/http';
import { environment } from '../../environments/environment';
import { CookieService } from 'ngx-cookie-service';
import * as jwt_decode from 'jwt-decode';
import { TokenDecoded } from '../clases/token';




@Injectable({
  providedIn: 'root'
})
export class AuthService {



  
  private dominio = "http://" + environment.dominio_api;
  constructor(private http: HttpClient, private cookies:CookieService) { }

  public isTokenExpired(): boolean {
    let res: boolean = true;
    let token = this.cookies.get("backoffice-cookie");
    if (this.cookies.check("backoffice-cookie")) {
      let decoded: TokenDecoded = jwt_decode(token);
      const current_time = Date.now().valueOf() / 1000;
      if (decoded.exp > current_time) {
        res = false;
      }

    }
    return res;

  }

  public setToken(token: any): void {
    this.cookies.set("backoffice-cookie", token, 1, "/", "localhost", false);
  }
   
  
  public getToken(){
    if(this.cookies.get('backoffice-cookie')){
    let token: TokenDecoded = jwt_decode(this.cookies.get('backoffice-cookie'));
    return token;}
    else null;
  }

 
  autenticar(email, password){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    const url = this.dominio + '/laboratorio-web/rest/wsUsuario/LoginToken';
    return this.http.post(url,{email,password}, httpOptions)
  }
 

}
