export enum EArea {

    POLITICA = 1,
    SALUD,
    ECONOMIA
}