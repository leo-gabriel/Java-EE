export enum EVeracidad {

    VERDADERA = 1,
    VERDAD_A_MEDIAS,
    INFLADA,
    ENGANIOSA,
    FALSA,
    RIDICULA,
    VERACIDAD
	
}