import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; 
import { HttpModule } from '@angular/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import {NgxPaginationModule} from'ngx-pagination';
import { CloudinaryModule } from '@cloudinary/angular-5.x';
import * as  Cloudinary from 'cloudinary-core';
import { FileSelectDirective } from 'ng2-file-upload';
import { NgxSoapModule } from 'ngx-soap';
import { ModalModule } from 'ngb-modal';

// Rutas
import { APP_ROUTES } from './app.routes';


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NopagefoundComponent } from './shared/nopagefound/nopagefound.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProgressComponent } from './pages/progress/progress.component';
import { Graficas1Component } from './pages/graficas1/graficas1.component';
import { HeaderComponent } from './shared/header/header.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { BreadcrumbsComponent } from './shared/breadcrumbs/breadcrumbs.component';
import { PagesComponent } from './pages/pages.component';
import { RegisterComponent } from './login/register.component';
import { RegistroComponent } from './pages/registro/registro/registro.component';
import { UsuarioService } from './services/usuario.service';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NopagefoundComponent,
    DashboardComponent,
    ProgressComponent,
    Graficas1Component,
    HeaderComponent,
    SidebarComponent,
    BreadcrumbsComponent,
    PagesComponent,
    RegisterComponent,
    FileSelectDirective,
    RegistroComponent
    
  ],
  imports: [
    FormsModule,
    BrowserModule,
    APP_ROUTES,
    HttpClientModule,
    HttpModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    CloudinaryModule.forRoot(Cloudinary, { cloud_name: 'cdnimages-hechosdraps'}),
    NgxSoapModule,
    ModalModule,
    
    
  ],
  providers: [CookieService,UsuarioService],
  bootstrap: [AppComponent]
})
export class AppModule { }
